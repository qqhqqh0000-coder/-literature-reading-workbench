import { app, BrowserWindow, dialog, ipcMain, protocol, shell } from 'electron'
import { randomUUID } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { readFile, writeFile, access, stat } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { extractPdfText } from '../vendor/extractor/pdf.mjs'
import { createDeepSeekService } from './deepseek-service.js'
import { createMetadataLookupService } from './metadata-lookup-service.js'
import { createPdfService, normalizePdfFileName } from './pdf-service.js'
import { findPdfEvidencePage } from './pdf-evidence.js'
import { createStorageService } from './storage-service.js'
import { createLegacyMigrationService } from './legacy-migration-service.js'
import { createBaiduSyncService } from './baidu-sync-service.js'
import { createLocalRecoveryService } from './local-recovery-service.js'

const here = path.dirname(fileURLToPath(import.meta.url))
function readBuildEdition(): 'friends' | 'public' {
  try {
    const info = JSON.parse(readFileSync(path.join(here, 'build-info.json'), 'utf8')) as { edition?: unknown }
    return info.edition === 'friends' ? 'friends' : 'public'
  } catch {
    return app.isPackaged ? 'public' : 'friends'
  }
}
const buildEdition = readBuildEdition()
const publicBuild = buildEdition === 'public'
const dataDir = path.join(app.getPath('userData'), 'literature-reading')
const pdfDir = path.join(dataDir, 'pdfs')
const dataFile = path.join(dataDir, 'data.json')
const keyFile = path.join(dataDir, 'settings.json')
const packagedAssets = app.isPackaged ? path.join(process.resourcesPath, 'app.asar.unpacked') : app.getAppPath()
const pdfjsDir = path.join(packagedAssets, 'vendor', 'pdfjs')
const storage = createStorageService({ dataDir, pdfDir, dataFile })
const localRecovery = createLocalRecoveryService({ dataDir, pdfDir, dataFile, runExclusive: storage.runExclusive })
const deepseek = createDeepSeekService()
const metadataLookup = createMetadataLookupService()
const legacyMigration = createLegacyMigrationService({ dataFile, pdfDir, save: (text) => storage.save(text) })
const baiduSync = createBaiduSyncService({ dataDir, pdfDir, dataFile, appConfigFile: path.join(here, 'baidu-app.json'), enabled: !publicBuild })
let mainWindow: BrowserWindow | null = null
let legacyImportInProgress = false
let cloudSyncInProgress = false
let cloudRestoreInProgress = false
let localDataOperationsInProgress = 0
let localSnapshotInProgress = false
let localRestoreInProgress = false
let trashMutationInProgress = false

function sendTask(
  id: string,
  status: 'running' | 'success' | 'error' | 'cancelled',
  stage: string,
  progress: number | null = null,
  type = 'local-data',
  title = '本机数据保护',
  error?: string,
  quiet = false,
): void {
  mainWindow?.webContents.send('task:status', { id, type, title, status, stage, progress, error, canCancel: false, quiet })
}

function baiduErrorResult(error: unknown): { ok: false; error: string; code: string } {
  return {
    ok: false,
    error: error instanceof Error ? error.message : String(error),
    code: error && typeof error === 'object' && 'code' in error ? String((error as { code: unknown }).code) : 'unknown',
  }
}

protocol.registerSchemesAsPrivileged([
  { scheme: 'litpdf', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true } },
  { scheme: 'litasset', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } },
])

function createWindow() {
  const window = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 980,
    minHeight: 680,
    title: publicBuild ? '文献阅读工作台-公开版' : '文献阅读工作台',
    webPreferences: {
      preload: path.join(here, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  })
  mainWindow = window
  let closeAuthorized = false
  let closeRequested = false
  const handleCloseReady = (event: Electron.IpcMainEvent, saved: unknown) => {
    if (event.sender !== window.webContents || !closeRequested) return
    closeRequested = false
    if (saved !== true) return
    if (legacyImportInProgress) {
      void dialog.showMessageBox(window, {
        type: 'info',
        title: '正在导入旧数据',
        message: '请等待旧数据导入完成后再关闭应用。',
      })
      return
    }
    if (cloudSyncInProgress) {
      void dialog.showMessageBox(window, {
        type: 'info',
        title: '正在进行百度网盘操作',
        message: '请等待百度网盘操作完成后再关闭应用。',
      })
      return
    }
    if (localDataOperationsInProgress > 0) {
      void dialog.showMessageBox(window, {
        type: 'info',
        title: '正在处理本地文献数据',
        message: '请等待当前数据操作完成后再关闭应用。',
      })
      return
    }
    closeAuthorized = true
    window.close()
  }
  ipcMain.on('window:close-ready', handleCloseReady)
  window.on('close', (event) => {
    if (closeAuthorized) return
    event.preventDefault()
    if (closeRequested) return
    closeRequested = true
    window.webContents.send('window:prepare-close')
  })
  window.on('closed', () => {
    ipcMain.removeListener('window:close-ready', handleCloseReady)
    if (mainWindow === window) mainWindow = null
  })
  if (process.env.VITE_DEV_SERVER_URL) void window.loadURL(process.env.VITE_DEV_SERVER_URL)
  else void window.loadFile(path.join(here, '../dist/index.html'))
}

ipcMain.handle('settings:get', async () => {
  try {
    const parsed: unknown = JSON.parse(await readFile(keyFile, 'utf8'))
    const settings: { apiKey?: unknown; setupComplete?: unknown } = parsed && typeof parsed === 'object'
      ? parsed as { apiKey?: unknown; setupComplete?: unknown }
      : {}
    const hasLegacySettings = typeof settings.apiKey === 'string' && typeof settings.setupComplete !== 'boolean'
    return {
      apiKey: typeof settings.apiKey === 'string' ? settings.apiKey : '',
      setupComplete: settings.setupComplete === true || hasLegacySettings,
    }
  } catch {
    return { apiKey: '', setupComplete: false }
  }
})

ipcMain.handle('settings:save', async (_event, settings: { apiKey?: string; setupComplete?: boolean }) => {
  await storage.ensure()
  let previous: { apiKey?: unknown; setupComplete?: unknown } = {}
  try {
    const parsed: unknown = JSON.parse(await readFile(keyFile, 'utf8'))
    if (parsed && typeof parsed === 'object') previous = parsed as typeof previous
  } catch { /* first save or invalid prior settings */ }
  const apiKey = typeof settings.apiKey === 'string'
    ? settings.apiKey.trim()
    : typeof previous.apiKey === 'string' ? previous.apiKey : ''
  const hasLegacySettings = typeof previous.apiKey === 'string' && typeof previous.setupComplete !== 'boolean'
  const setupComplete = settings.setupComplete === true || previous.setupComplete === true || hasLegacySettings
  await writeFile(keyFile, JSON.stringify({ apiKey, setupComplete }), 'utf8')
  return { ok: true, setupComplete }
})

async function getSavedApiKey(): Promise<string> {
  try {
    const settings = JSON.parse(await readFile(keyFile, 'utf8')) as { apiKey?: unknown }
    return typeof settings.apiKey === 'string' ? settings.apiKey : ''
  } catch {
    return ''
  }
}

async function extractBetter(buffer: Buffer) {
  const extracted = extractPdfText(buffer)
  if (extracted.lowConfidence) {
    try {
      const pdfjs = await import(pathToFileURL(path.join(pdfjsDir, 'pdf.min.mjs')).href)
      pdfjs.GlobalWorkerOptions.workerSrc = pathToFileURL(path.join(pdfjsDir, 'pdf.worker.min.mjs')).href
      const document = await pdfjs.getDocument({ data: new Uint8Array(buffer), useSystemFonts: true }).promise
      const pages: string[] = []
      for (let i = 1; i <= document.numPages; i++) {
        const page = await document.getPage(i)
        const content = await page.getTextContent()
        pages.push(content.items.map((item: { str?: string }) => item.str || '').filter(Boolean).join(' '))
      }
      const text = pages.join('\n\n').trim()
      if (text.length > extracted.text.length) return { ...extracted, text, chars: text.length, pages: document.numPages, lowConfidence: false, confidence: Math.max(70, extracted.confidence) }
    } catch { /* Keep the built-in extractor result and let the reader show the original PDF. */ }
  }
  return extracted
}

const pdf = createPdfService({ pdfDir, extractBetter })

type PdfPageTextCacheEntry = { mtimeMs: number; size: number; pageTexts: string[] }
const pdfPageTextCache = new Map<string, PdfPageTextCacheEntry>()
let pdfjsModulePromise: Promise<any> | null = null

async function getPdfPageTexts(fileName: string): Promise<string[]> {
  const safeName = normalizePdfFileName(fileName)
  if (!safeName || safeName !== fileName) throw new Error('文献 PDF 文件名无效。')
  const filePath = path.join(pdfDir, safeName)
  let fileInfo
  try { fileInfo = await stat(filePath) }
  catch { throw new Error('找不到这篇文献的 PDF 文件，请确认尚未移动或删除原件。') }
  if (fileInfo.size > 32 * 1024 * 1024) throw new Error('PDF 文件超过约 32 MB 的处理上限。')
  const cached = pdfPageTextCache.get(safeName)
  if (cached && cached.mtimeMs === fileInfo.mtimeMs && cached.size === fileInfo.size) {
    pdfPageTextCache.delete(safeName)
    pdfPageTextCache.set(safeName, cached)
    return cached.pageTexts
  }

  if (!pdfjsModulePromise) {
    pdfjsModulePromise = import(pathToFileURL(path.join(pdfjsDir, 'pdf.min.mjs')).href).then((module) => {
      module.GlobalWorkerOptions.workerSrc = pathToFileURL(path.join(pdfjsDir, 'pdf.worker.min.mjs')).href
      return module
    }).catch((error) => {
      pdfjsModulePromise = null
      throw error
    })
  }
  const pdfjs = await pdfjsModulePromise
  let buffer: Buffer
  try { buffer = await readFile(filePath) }
  catch { throw new Error('读取这篇文献的 PDF 文件失败。') }
  let document: any
  try { document = await pdfjs.getDocument({ data: new Uint8Array(buffer), useSystemFonts: true }).promise }
  catch { throw new Error('无法解析这份 PDF 的文本层；文件可能损坏、加密或没有可检索文字。') }
  const pageTexts: string[] = []
  try {
    for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
      const page = await document.getPage(pageNumber)
      const content = await page.getTextContent()
      pageTexts.push(content.items
        .map((item: { str?: string }) => item.str || '')
        .filter(Boolean)
        .join(' '))
    }
  } finally {
    await document.destroy().catch(() => undefined)
  }

  const entry = { mtimeMs: fileInfo.mtimeMs, size: fileInfo.size, pageTexts }
  pdfPageTextCache.delete(safeName)
  pdfPageTextCache.set(safeName, entry)
  while (pdfPageTextCache.size > 3) {
    const oldest = pdfPageTextCache.keys().next().value
    if (oldest === undefined) break
    pdfPageTextCache.delete(oldest)
  }
  return pageTexts
}

async function dispatchRpc(op: string, args: Record<string, unknown> = {}) {
  try {
    if (op === 'load') {
      return await storage.load()
    }
    if (op === 'save') {
      if (cloudSyncInProgress || legacyImportInProgress) return { ok: false, error: '正在进行百度网盘操作或旧数据导入，请稍候。' }
      if (localRestoreInProgress || trashMutationInProgress) return { ok: false, error: '正在保护本机数据，请稍候再保存。' }
      const text = typeof args.text === 'string' ? args.text : ''
      if (!text) return { ok: false, error: '拒绝保存空文献列表。' }
      localDataOperationsInProgress += 1
      try { return await storage.save(text) }
      finally { localDataOperationsInProgress -= 1 }
    }
    if (op === 'movePaperToTrash' || op === 'restorePaperFromTrash' || op === 'permanentlyDeleteFromTrash') {
      if (cloudSyncInProgress || legacyImportInProgress || localSnapshotInProgress || localRestoreInProgress || trashMutationInProgress) return { ok: false, error: '另一个数据操作正在进行，请稍候。' }
      const changesPaperList = op !== 'permanentlyDeleteFromTrash'
      localDataOperationsInProgress += 1
      if (changesPaperList) trashMutationInProgress = true
      try {
        if (op === 'movePaperToTrash') return await storage.movePaperToTrash(String(args.paperId || ''))
        if (op === 'restorePaperFromTrash') return await storage.restorePaperFromTrash(String(args.paperId || ''))
        return await storage.permanentlyDeleteFromTrash(String(args.paperId || ''))
      } finally { if (changesPaperList) trashMutationInProgress = false; localDataOperationsInProgress -= 1 }
    }
    if (op === 'listTrash') return await storage.listTrash()
    if (op === 'listLocalSnapshots') return { ok: true, snapshots: await localRecovery.listSnapshots() }
    if (op === 'createLocalSnapshot') {
      if (cloudSyncInProgress || legacyImportInProgress || localDataOperationsInProgress > 0) return { ok: false, error: '另一个数据操作正在进行，请稍后重试。' }
      localDataOperationsInProgress += 1
      localSnapshotInProgress = true
      const taskId = `local-snapshot-${randomUUID()}`
      sendTask(taskId, 'running', '正在复制本机文献和 PDF')
      try {
        const snapshot = await localRecovery.createDailySnapshot((progress) => {
          sendTask(taskId, 'running', progress.phase === 'complete' ? '正在完成快照' : `正在复制 ${progress.completedFiles}/${progress.totalFiles} 个文件`, progress.totalBytes > 0 ? Math.round(progress.completedBytes / progress.totalBytes * 100) : null)
        })
        sendTask(taskId, 'success', `快照完成：${snapshot.papers} 篇文献、${snapshot.pdfs} 个 PDF`)
        return { ok: true, snapshot }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        sendTask(taskId, 'error', message)
        return { ok: false, error: message }
      } finally { localSnapshotInProgress = false; localDataOperationsInProgress -= 1 }
    }
    if (op === 'restoreLocalSnapshot') {
      if (cloudSyncInProgress || legacyImportInProgress || localDataOperationsInProgress > 0) return { ok: false, error: '另一个数据操作正在进行，请稍后重试。' }
      localDataOperationsInProgress += 1
      localRestoreInProgress = true
      const taskId = `local-restore-${randomUUID()}`
      sendTask(taskId, 'running', '正在校验本机快照')
      try {
        const snapshotId = String(args.snapshotId || '')
        const restored = await localRecovery.restoreSnapshot(snapshotId)
        sendTask(taskId, 'success', `已恢复快照：${restored.papers} 篇文献、${restored.pdfs} 个 PDF`)
        return { ok: true, ...restored }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        sendTask(taskId, 'error', message)
        return { ok: false, error: message }
      } finally { localRestoreInProgress = false; localDataOperationsInProgress -= 1 }
    }
    if (op === 'importPdf') {
      if (cloudSyncInProgress || legacyImportInProgress) return { ok: false, error: '正在进行百度网盘操作或旧数据导入，请稍候。' }
      if (localSnapshotInProgress || localRestoreInProgress || trashMutationInProgress) return { ok: false, error: '正在保护本机数据，请稍候后再导入 PDF。' }
      localDataOperationsInProgress += 1
      try { return await pdf.import(args) }
      finally { localDataOperationsInProgress -= 1 }
    }
    if (op === 'reextract') {
      if (cloudSyncInProgress || legacyImportInProgress) return { ok: false, error: '正在进行百度网盘操作或旧数据导入，请稍候。' }
      if (localSnapshotInProgress || localRestoreInProgress || trashMutationInProgress) return { ok: false, error: '正在保护本机数据，请稍候后再处理。' }
      localDataOperationsInProgress += 1
      try { return await pdf.reextract(args.name) }
      finally { localDataOperationsInProgress -= 1 }
    }
    if (op === 'findPdfEvidencePage') {
      if (cloudSyncInProgress || legacyImportInProgress) return { ok: false, error: '正在进行百度网盘操作或旧数据导入，请稍候。' }
      const name = typeof args.name === 'string' ? args.name : ''
      const quote = typeof args.quote === 'string' ? args.quote.trim() : ''
      if (!name) return { ok: false, error: '这篇文献没有关联的 PDF。' }
      if (quote.length < 8 || quote.length > 500) return { ok: false, error: '原文依据长度无效，无法定位。' }
      localDataOperationsInProgress += 1
      try {
        const pageTexts = await getPdfPageTexts(name)
        return { ok: true, page: findPdfEvidencePage(pageTexts, quote) }
      } finally {
        localDataOperationsInProgress -= 1
      }
    }
    if (op === 'exportTsv') {
      const name = path.basename(typeof args.name === 'string' ? args.name : '文献阅读表格.tsv').replace(/[\\/:*?"<>|]/g, '_')
      const target = path.join(dataDir, name)
      await writeFile(target, String(args.text || ''), 'utf8')
      return { ok: true, path: target }
    }
    if (op === 'openFolder') return { ok: true, path: dataDir }
    if (op === 'pdfjs') return { ok: true, ready: true, cached: true, present: true, dir: pdfjsDir, files: ['pdf.min.mjs', 'pdf.worker.min.mjs'] }
    if (op === 'translate') {
      const text = String(args.text || '')
      if (!text.trim()) return { ok: false, error: '原文是空的。' }
      const result = await deepseek.translate({
        apiKey: await getSavedApiKey(),
        text,
        context: String(args.context || ''),
        annotate: args.annotate !== false,
      })
      return { ok: true, ...result }
    }
    if (op === 'summarize') {
      const text = String(args.text || '')
      if (!text.trim()) return { ok: false, error: '先选择一段文字，再生成思维导图。' }
      const result = await deepseek.summarize({
        apiKey: await getSavedApiKey(),
        text,
        hint: String(args.hint || ''),
      })
      return { ok: true, ...result }
    }
    if (op === 'autoFillTable') {
      const text = String(args.text || '')
      if (!text.trim()) return { ok: false, error: '这份 PDF 没有可识别的正文文字。' }
      const result = await deepseek.extractPaperTable({
        apiKey: await getSavedApiKey(),
        text,
        context: String(args.title || ''),
      })
      return { ok: true, ...result }
    }
    if (op === 'lookupMetadata') {
      const metadata = await metadataLookup.lookup({
        pmid: typeof args.pmid === 'string' || typeof args.pmid === 'number' ? args.pmid : undefined,
        doi: typeof args.doi === 'string' ? args.doi : undefined,
      })
      return { ok: true, metadata }
    }
    return { ok: false, error: `未知操作：${op}` }
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) }
  }
}

ipcMain.handle('literature:rpc', (_event, op: string, args: Record<string, unknown>) => dispatchRpc(op, args))

function publicBaiduDisabledResult() {
  return { ok: false, error: '公开版未启用百度网盘同步，且不包含百度 SecretKey。', code: 'feature_disabled' }
}

ipcMain.handle('baidu:status', async () => {
  try { return { ok: true, ...(await baiduSync.status()) } }
  catch (error) { return baiduErrorResult(error) }
})
ipcMain.handle('baidu:open-auth', async () => {
  if (publicBuild) return publicBaiduDisabledResult()
  const url = await baiduSync.authorizationUrl()
  await shell.openExternal(url)
  return { ok: true }
})
ipcMain.handle('baidu:connect', async (_event, code: string) => {
  if (publicBuild) return publicBaiduDisabledResult()
  return { ok: true, ...(await baiduSync.connect(code)) }
})
ipcMain.handle('baidu:disconnect', async () => {
  if (publicBuild) return publicBaiduDisabledResult()
  await baiduSync.disconnect()
  return { ok: true }
})
ipcMain.handle('baidu:latest', async () => {
  if (publicBuild) return publicBaiduDisabledResult()
  try { return { ok: true, backup: await baiduSync.getLatestBackupSummary() } }
  catch (error) { return baiduErrorResult(error) }
})
ipcMain.handle('baidu:restore-preview', async () => {
  if (publicBuild) return publicBaiduDisabledResult()
  try { return { ok: true, ...(await baiduSync.getRestorePreview()) } }
  catch (error) { return baiduErrorResult(error) }
})
ipcMain.handle('baidu:upload', async (_event, requestedTaskId?: unknown) => {
  if (publicBuild) return publicBaiduDisabledResult()
  if (cloudSyncInProgress || legacyImportInProgress || localDataOperationsInProgress > 0) {
    return { ok: false, error: '另一个数据操作正在进行，请稍后重试。' }
  }
  const taskId = typeof requestedTaskId === 'string' && /^[a-zA-Z0-9_-]{1,100}$/.test(requestedTaskId) ? requestedTaskId : `baidu-upload-${randomUUID()}`
  cloudSyncInProgress = true
  sendTask(taskId, 'running', '正在准备备份', null, 'cloud-sync', '百度网盘备份')
  try {
    const result = await baiduSync.uploadSnapshot((progress) => {
      const percent = progress.totalBytes > 0 ? Math.round(progress.transferredBytes / progress.totalBytes * 100) : null
      const stage = progress.phase === 'preparing'
        ? '正在准备本机数据'
        : progress.phase === 'complete'
          ? '云端校验完成'
          : `正在上传第 ${progress.fileIndex}/${progress.filesTotal} 个文件${progress.file ? `：${progress.file}` : ''}`
      sendTask(taskId, 'running', stage, percent, 'cloud-sync', '百度网盘备份')
    })
    sendTask(taskId, 'success', `备份完成：${result.files} 个文件`, 100, 'cloud-sync', '百度网盘备份')
    return { ok: true, ...result }
  }
  catch (error) {
    const result = baiduErrorResult(error)
    sendTask(taskId, 'error', result.error, null, 'cloud-sync', '百度网盘备份', result.error)
    return result
  }
  finally { cloudSyncInProgress = false }
})
ipcMain.handle('baidu:restore', async (_event, requestedTaskId?: unknown) => {
  if (publicBuild) return publicBaiduDisabledResult()
  if (cloudSyncInProgress || legacyImportInProgress || localDataOperationsInProgress > 0) {
    return { ok: false, error: '另一个数据操作正在进行，请稍后重试。' }
  }
  const taskId = typeof requestedTaskId === 'string' && /^[a-zA-Z0-9_-]{1,100}$/.test(requestedTaskId) ? requestedTaskId : `baidu-restore-${randomUUID()}`
  cloudSyncInProgress = true
  cloudRestoreInProgress = true
  sendTask(taskId, 'running', '正在查找云端备份', null, 'cloud-sync', '百度网盘恢复')
  try {
    const result = await baiduSync.restoreLatestSnapshot((progress) => {
      const percent = progress.totalBytes > 0 ? Math.round(progress.transferredBytes / progress.totalBytes * 100) : null
      const stage = progress.phase === 'preparing'
        ? '正在准备恢复'
        : progress.phase === 'complete'
          ? '云端数据校验完成'
          : `正在下载第 ${progress.fileIndex}/${progress.filesTotal} 个文件${progress.file ? `：${progress.file}` : ''}`
      sendTask(taskId, 'running', stage, percent, 'cloud-sync', '百度网盘恢复')
    })
    sendTask(taskId, 'success', `恢复完成：${result.papers} 篇文献`, 100, 'cloud-sync', '百度网盘恢复')
    return { ok: true, ...result }
  }
  catch (error) {
    const result = baiduErrorResult(error)
    sendTask(taskId, 'error', result.error, null, 'cloud-sync', '百度网盘恢复', result.error)
    return result
  }
  finally { cloudRestoreInProgress = false; cloudSyncInProgress = false }
})
ipcMain.handle('assets:url', async (_event, fileName: string) => {
  if (!['pdf.min.mjs', 'pdf.worker.min.mjs'].includes(path.basename(fileName))) throw new Error('Invalid asset name')
  await access(path.join(pdfjsDir, fileName))
  return `litasset://pdfjs/${encodeURIComponent(fileName)}`
})

ipcMain.handle('storage:open', async () => { await shell.openPath(dataDir); return dataDir })

ipcMain.handle('storage:import-legacy', async () => {
  if (legacyImportInProgress || cloudSyncInProgress || localDataOperationsInProgress > 0) {
    return { ok: false, error: '另一个数据操作正在进行，请稍后重试。' }
  }
  const openOptions = {
    title: '选择旧版 DSH 文献数据文件',
    buttonLabel: '选择 data.json',
    properties: ['openFile'] as Array<'openFile'>,
    filters: [{ name: '旧版文献数据', extensions: ['json'] }],
  }
  const selected = mainWindow
    ? await dialog.showOpenDialog(mainWindow, openOptions)
    : await dialog.showOpenDialog(openOptions)
  if (selected.canceled || selected.filePaths.length === 0) return { ok: false, canceled: true }

  const confirmOptions = {
    type: 'warning' as const,
    title: '导入旧版文献数据',
    message: '导入会替换当前桌面版的文献列表。',
    detail: '当前 data.json 会自动备份为 data.json.bak。旧版 data.json 旁边的 pdfs 文件夹中，被文献引用的 PDF 会一并复制到桌面版。',
    buttons: ['取消', '导入并替换'],
    defaultId: 0,
    cancelId: 0,
  }
  const confirmation = mainWindow
    ? await dialog.showMessageBox(mainWindow, confirmOptions)
    : await dialog.showMessageBox(confirmOptions)
  if (confirmation.response !== 1) return { ok: false, canceled: true }

  // The file picker and confirmation are asynchronous. A cloud restore or
  // another local data operation may have started while either dialog was open.
  if (legacyImportInProgress || cloudSyncInProgress || localDataOperationsInProgress > 0) {
    return { ok: false, error: '另一个数据操作正在进行，请稍后重试。' }
  }

  legacyImportInProgress = true
  localDataOperationsInProgress += 1
  try {
    return await legacyMigration.importFrom(selected.filePaths[0])
  } finally {
    legacyImportInProgress = false
    localDataOperationsInProgress -= 1
  }
})

function scheduleDailySnapshotWhenIdle(delayMs = 1_500): void {
  setTimeout(() => {
    if (!mainWindow || mainWindow.isDestroyed()) return
    if (cloudSyncInProgress || legacyImportInProgress || localDataOperationsInProgress > 0) {
      scheduleDailySnapshotWhenIdle(10_000)
      return
    }
    const taskId = `local-daily-snapshot-${new Date().toISOString().slice(0, 10)}`
    localDataOperationsInProgress += 1
    localSnapshotInProgress = true
    sendTask(taskId, 'running', '正在创建今日本机快照', null, 'local-data', '本机每日快照', undefined, true)
    void localRecovery.createDailySnapshot((progress) => {
      const percent = progress.totalBytes > 0 ? Math.round(progress.completedBytes / progress.totalBytes * 100) : null
      sendTask(taskId, 'running', `正在复制 ${progress.completedFiles}/${progress.totalFiles} 个文件`, percent, 'local-data', '本机每日快照', undefined, true)
    }).then((snapshot) => {
      sendTask(taskId, 'success', `快照完成：${snapshot.papers} 篇文献、${snapshot.pdfs} 个 PDF`, 100, 'local-data', '本机每日快照', undefined, true)
    }).catch((error) => {
      const message = error instanceof Error ? error.message : String(error)
      sendTask(taskId, 'error', message, null, 'local-data', '本机每日快照', message, true)
    }).finally(() => { localSnapshotInProgress = false; localDataOperationsInProgress -= 1 })
  }, delayMs)
}

app.whenReady().then(async () => {
  await storage.ensure()
  protocol.handle('litpdf', async (request) => {
    let fileName = ''
    try { fileName = decodeURIComponent(new URL(request.url).pathname.slice(1)) } catch { return new Response('Bad PDF name', { status: 400 }) }
    const normalizedName = normalizePdfFileName(fileName)
    if (!normalizedName || normalizedName !== fileName) return new Response('Bad PDF name', { status: 400 })
    try {
      const data = await readFile(path.join(pdfDir, fileName))
      return new Response(data, { headers: { 'Content-Type': 'application/pdf' } })
    } catch { return new Response('PDF not found', { status: 404 }) }
  })
  protocol.handle('litasset', async (request) => {
    const url = new URL(request.url)
    const fileName = decodeURIComponent(url.pathname.slice(1) || url.searchParams.get('file') || '')
    if (!['pdf.min.mjs', 'pdf.worker.min.mjs'].includes(path.basename(fileName))) return new Response('Bad asset name', { status: 400 })
    try {
      const data = await readFile(path.join(pdfjsDir, fileName))
      return new Response(data, { headers: { 'Content-Type': 'text/javascript; charset=utf-8', 'Access-Control-Allow-Origin': '*' } })
    } catch { return new Response('Asset not found', { status: 404 }) }
  })
  createWindow()
  // Make one integrity-checked full snapshot per calendar day. Startup and the renderer stay responsive.
  scheduleDailySnapshotWhenIdle()
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow() })
})

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit() })
