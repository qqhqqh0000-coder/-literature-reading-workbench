const { contextBridge, ipcRenderer } = require('electron')

let prepareClose = null
ipcRenderer.on('window:prepare-close', async () => {
  if (typeof prepareClose !== 'function') {
    ipcRenderer.send('window:close-ready', true)
    return
  }

  try {
    ipcRenderer.send('window:close-ready', (await prepareClose()) === true)
  } catch {
    ipcRenderer.send('window:close-ready', false)
  }
})

ipcRenderer.on('task:status', (_event, detail) => {
  window.dispatchEvent(new CustomEvent('literature-reader:task', { detail }))
})

contextBridge.exposeInMainWorld('literatureApp', {
  rpc: (op, args) => ipcRenderer.invoke('literature:rpc', op, args),
  getAssetUrl: (fileName) => ipcRenderer.invoke('assets:url', fileName),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  saveSettings: (settings) => ipcRenderer.invoke('settings:save', settings),
  openDataFolder: () => ipcRenderer.invoke('storage:open'),
  importLegacyData: () => ipcRenderer.invoke('storage:import-legacy'),
  baiduStatus: () => ipcRenderer.invoke('baidu:status'),
  baiduOpenAuth: () => ipcRenderer.invoke('baidu:open-auth'),
  baiduConnect: (code) => ipcRenderer.invoke('baidu:connect', code),
  baiduDisconnect: () => ipcRenderer.invoke('baidu:disconnect'),
  baiduLatestBackup: () => ipcRenderer.invoke('baidu:latest'),
  baiduRestorePreview: () => ipcRenderer.invoke('baidu:restore-preview'),
  baiduUpload: (taskId) => ipcRenderer.invoke('baidu:upload', taskId),
  baiduRestore: (taskId) => ipcRenderer.invoke('baidu:restore', taskId),
  onPrepareClose: (callback) => {
    prepareClose = callback
    return () => { if (prepareClose === callback) prepareClose = null }
  },
})
