/**
 * Retrieve bibliographic metadata from public PubMed and Crossref APIs.
 * No identifier or response content is logged by this module.
 */

export interface MetadataLookupInput {
  pmid?: unknown
  doi?: unknown
}

/** Only identifiers and bibliographic values intended for display are returned. */
export interface MetadataLookupResult {
  title?: string
  journal?: string
  published?: string
  pmid?: string
  doi?: string
  url?: string
  kind?: string
}

export type MetadataLookupErrorCode =
  | 'invalid-input'
  | 'timeout'
  | 'network'
  | 'http-error'
  | 'invalid-response'

export class MetadataLookupError extends Error {
  readonly code: MetadataLookupErrorCode

  constructor(code: MetadataLookupErrorCode, message: string) {
    super(message)
    this.name = 'MetadataLookupError'
    this.code = code
  }
}

export interface MetadataLookupServiceOptions {
  /** Injectable for controlled embedding; defaults to the runtime fetch API. */
  fetcher?: typeof fetch
  /** Request timeout in milliseconds. Values are clamped to 1–30 seconds. */
  timeoutMs?: number
}

export interface MetadataLookupService {
  /** Returns null when neither PubMed nor Crossref has a matching record. */
  lookup(input: MetadataLookupInput): Promise<MetadataLookupResult | null>
}

const PUBMED_ESEARCH_URL = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi'
const PUBMED_EFETCH_URL = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi'
const CROSSREF_WORKS_URL = 'https://api.crossref.org/works/'
const DEFAULT_TIMEOUT_MS = 8_000
const MAX_RESPONSE_CHARS = 2_000_000
const MAX_DOI_CHARS = 300
const MAX_PUBMED_SEARCH_IDS = 3

function cleanDisplayValue(value: unknown, maxLength = 2_000): string | undefined {
  if (typeof value !== 'string') return undefined
  const cleaned = value
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength)
  return cleaned || undefined
}

function normalizePmid(value: unknown): string | undefined {
  if (typeof value !== 'string' && typeof value !== 'number') return undefined
  const normalized = String(value).trim().replace(/^PMID\s*:?\s*/i, '')
  return /^\d{1,12}$/.test(normalized) ? normalized : undefined
}

function normalizeDoi(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  let normalized = value.trim()
  normalized = normalized.replace(/^doi\s*:\s*/i, '')
  normalized = normalized.replace(/^https?:\/\/(?:dx\.)?doi\.org\//i, '')
  normalized = normalized.replace(/[\s.,;]+$/g, '')
  if (normalized.length > MAX_DOI_CHARS) return undefined
  if (!/^10\.\d{4,9}\/\S+$/i.test(normalized)) return undefined
  // Keep DOI suffixes usable as an identifier while rejecting markup and URL
  // delimiters that could turn it into a different kind of request.
  if (/[\u0000-\u0020<>"'{}|\\^`\[\]]/.test(normalized)) return undefined
  return normalized
}

function xmlTagRaw(xml: string, tagName: string): string | undefined {
  const match = new RegExp(`<${tagName}\\b[^>]*>([\\s\\S]*?)<\\/${tagName}\\s*>`, 'i').exec(xml)
  return match?.[1]
}

function decodeXmlText(value: string): string {
  return value
    .replace(/<[^>]*>/g, ' ')
    .replace(/&#x([\da-f]+);/gi, (_whole, hex: string) => {
      const codePoint = Number.parseInt(hex, 16)
      return Number.isFinite(codePoint) && codePoint <= 0x10ffff ? String.fromCodePoint(codePoint) : ' '
    })
    .replace(/&#(\d+);/g, (_whole, decimal: string) => {
      const codePoint = Number.parseInt(decimal, 10)
      return Number.isFinite(codePoint) && codePoint <= 0x10ffff ? String.fromCodePoint(codePoint) : ' '
    })
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&apos;/gi, "'")
    .replace(/\s+/g, ' ')
    .trim()
}

function xmlTagText(xml: string, tagName: string): string | undefined {
  const raw = xmlTagRaw(xml, tagName)
  return raw === undefined ? undefined : cleanDisplayValue(decodeXmlText(raw))
}

function safeDoiUrl(doi: string): string {
  const encodedDoi = encodeURIComponent(doi).replace(/%2F/gi, '/')
  return `https://doi.org/${encodedDoi}`
}

function normalizeMonth(value: string | undefined): string | undefined {
  if (!value) return undefined
  const numeric = Number(value)
  if (Number.isInteger(numeric) && numeric >= 1 && numeric <= 12) return String(numeric).padStart(2, '0')
  const months: Record<string, string> = {
    jan: '01', january: '01', feb: '02', february: '02', mar: '03', march: '03',
    apr: '04', april: '04', may: '05', jun: '06', june: '06', jul: '07', july: '07',
    aug: '08', august: '08', sep: '09', sept: '09', september: '09', oct: '10',
    october: '10', nov: '11', november: '11', dec: '12', december: '12',
  }
  return months[value.trim().toLowerCase()]
}

function formatPubmedDate(dateXml: string | undefined): string | undefined {
  if (!dateXml) return undefined
  const year = xmlTagText(dateXml, 'Year')
  const monthRaw = xmlTagText(dateXml, 'Month')
  const dayRaw = xmlTagText(dateXml, 'Day')
  if (year && /^\d{4}$/.test(year)) {
    const month = normalizeMonth(monthRaw)
    if (!month) return year
    const day = dayRaw && /^\d{1,2}$/.test(dayRaw) ? `-${dayRaw.padStart(2, '0')}` : ''
    return `${year}-${month}${day}`
  }
  return cleanDisplayValue(xmlTagText(dateXml, 'MedlineDate'), 100)
}

function parsePubmedRecord(xml: string): MetadataLookupResult | null {
  const articleMatch = /<PubmedArticle\b[^>]*>([\s\S]*?)<\/PubmedArticle\s*>/i.exec(xml)
  if (!articleMatch) return null
  const record = articleMatch[1]
  const citation = xmlTagRaw(record, 'MedlineCitation') ?? record
  const article = xmlTagRaw(citation, 'Article') ?? citation
  const title = xmlTagText(article, 'ArticleTitle')
  const journalXml = xmlTagRaw(article, 'Journal')
  const journal = journalXml ? xmlTagText(journalXml, 'Title') : undefined
  const pmid = xmlTagText(citation, 'PMID')

  const articleDate = xmlTagRaw(article, 'ArticleDate')
  const journalIssue = journalXml ? xmlTagRaw(journalXml, 'JournalIssue') : undefined
  const pubDate = journalIssue ? xmlTagRaw(journalIssue, 'PubDate') : undefined
  const published = formatPubmedDate(articleDate) ?? formatPubmedDate(pubDate)

  const articleIds = xmlTagRaw(record, 'ArticleIdList') ?? record
  const doiMatch = /<ArticleId\b(?=[^>]*\bIdType\s*=\s*["']doi["'])[^>]*>([\s\S]*?)<\/ArticleId\s*>/i.exec(articleIds)
  const doi = doiMatch ? normalizeDoi(decodeXmlText(doiMatch[1])) : undefined
  const publicationTypeXml = xmlTagRaw(article, 'PublicationTypeList')
  const kinds = publicationTypeXml
    ? Array.from(publicationTypeXml.matchAll(/<PublicationType\b[^>]*>([\s\S]*?)<\/PublicationType\s*>/gi))
      .map((match) => cleanDisplayValue(decodeXmlText(match[1]), 100))
      .filter((value): value is string => Boolean(value))
    : []
  const normalizedPmid = normalizePmid(pmid)

  const result: MetadataLookupResult = {}
  if (title) result.title = title
  if (journal) result.journal = journal
  if (published) result.published = published
  if (normalizedPmid) result.pmid = normalizedPmid
  if (doi) result.doi = doi
  if (normalizedPmid) result.url = `https://pubmed.ncbi.nlm.nih.gov/${normalizedPmid}/`
  else if (doi) result.url = safeDoiUrl(doi)
  if (kinds.length > 0) result.kind = cleanDisplayValue(kinds.join('、'), 300)
  return Object.keys(result).length > 0 ? result : null
}

function parseEsearchIds(xml: string): string[] {
  const idList = xmlTagRaw(xml, 'IdList')
  if (idList === undefined) {
    if (/<IdList\s*\/>/i.test(xml)) return []
    throw new MetadataLookupError('invalid-response', 'PubMed 返回了无法识别的查询结果。')
  }
  return Array.from(idList.matchAll(/<Id\b[^>]*>(\d+)<\/Id\s*>/gi))
    .map((match) => match[1])
    .filter((id) => Boolean(normalizePmid(id)))
    .slice(0, MAX_PUBMED_SEARCH_IDS)
}

function crossrefDateParts(value: unknown): string | undefined {
  if (!Array.isArray(value) || value.length < 1 || !Array.isArray(value[0])) return undefined
  const parts = value[0] as unknown[]
  const year = parts[0]
  if (typeof year !== 'number' || !Number.isInteger(year) || year < 1000 || year > 9999) return undefined
  const month = parts[1]
  if (typeof month !== 'number' || !Number.isInteger(month) || month < 1 || month > 12) return String(year)
  const day = parts[2]
  const dayPart = typeof day === 'number' && Number.isInteger(day) && day >= 1 && day <= 31
    ? `-${String(day).padStart(2, '0')}`
    : ''
  return `${year}-${String(month).padStart(2, '0')}${dayPart}`
}

function firstString(value: unknown): string | undefined {
  if (typeof value === 'string') return cleanDisplayValue(value)
  if (Array.isArray(value)) {
    const first = value.find((item) => typeof item === 'string')
    return typeof first === 'string' ? cleanDisplayValue(first) : undefined
  }
  return undefined
}

function parseCrossrefRecord(jsonText: string, requestedDoi: string): MetadataLookupResult | null {
  let parsed: unknown
  try {
    parsed = JSON.parse(jsonText)
  } catch {
    throw new MetadataLookupError('invalid-response', 'Crossref 返回了无法识别的元数据。')
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new MetadataLookupError('invalid-response', 'Crossref 返回了无法识别的元数据。')
  }
  const envelope = parsed as Record<string, unknown>
  if (envelope.status !== 'ok' || !envelope.message || typeof envelope.message !== 'object' || Array.isArray(envelope.message)) {
    throw new MetadataLookupError('invalid-response', 'Crossref 返回了无法识别的元数据。')
  }
  const work = envelope.message as Record<string, unknown>
  const doi = normalizeDoi(work.DOI) ?? requestedDoi
  const published = crossrefDateParts(work['published-print'])
    ?? crossrefDateParts(work['published-online'])
    ?? crossrefDateParts(work.issued)
    ?? crossrefDateParts(work.created)
  const result: MetadataLookupResult = {}
  const title = firstString(work.title)
  const journal = firstString(work['container-title'])
  const kind = cleanDisplayValue(work.type, 100)
  if (title) result.title = title
  if (journal) result.journal = journal
  if (published) result.published = published
  if (doi) result.doi = doi
  result.url = safeDoiUrl(doi)
  if (kind) result.kind = kind
  return Object.keys(result).length > 0 ? result : null
}

function errorForFetch(error: unknown, timedOut: boolean): MetadataLookupError {
  if (timedOut) return new MetadataLookupError('timeout', '查询文献元数据超时，请稍后重试。')
  if (error instanceof MetadataLookupError) return error
  return new MetadataLookupError('network', '暂时无法连接文献元数据服务，请检查网络后重试。')
}

export function createMetadataLookupService(options: MetadataLookupServiceOptions = {}): MetadataLookupService {
  const fetcher = options.fetcher ?? fetch
  const configuredTimeout = Number.isFinite(options.timeoutMs) ? Math.floor(options.timeoutMs as number) : DEFAULT_TIMEOUT_MS
  const timeoutMs = Math.min(30_000, Math.max(1, configuredTimeout))

  async function request(url: URL): Promise<string | null> {
    const controller = new AbortController()
    let timedOut = false
    const timeout = setTimeout(() => {
      timedOut = true
      controller.abort()
    }, timeoutMs)
    try {
      const response = await fetcher(url.toString(), {
        method: 'GET',
        headers: { accept: 'application/xml, application/json;q=0.9' },
        signal: controller.signal,
        redirect: 'error',
      })
      if (response.status === 404) return null
      if (!response.ok) throw new MetadataLookupError('http-error', '文献元数据服务暂时不可用。')
      const text = await response.text()
      if (text.length > MAX_RESPONSE_CHARS) {
        throw new MetadataLookupError('invalid-response', '文献元数据服务返回的数据超出处理范围。')
      }
      return text
    } catch (error) {
      throw errorForFetch(error, timedOut)
    } finally {
      clearTimeout(timeout)
    }
  }

  async function searchPubmedByDoi(doi: string): Promise<MetadataLookupResult | null> {
    const searchUrl = new URL(PUBMED_ESEARCH_URL)
    searchUrl.searchParams.set('db', 'pubmed')
    searchUrl.searchParams.set('term', `${doi}[DOI]`)
    searchUrl.searchParams.set('retmax', String(MAX_PUBMED_SEARCH_IDS))
    searchUrl.searchParams.set('retmode', 'xml')
    searchUrl.searchParams.set('tool', 'literature-reading-workbench')
    const searchXml = await request(searchUrl)
    if (!searchXml) return null
    const ids = parseEsearchIds(searchXml)
    for (const id of ids) {
      const articleUrl = new URL(PUBMED_EFETCH_URL)
      articleUrl.searchParams.set('db', 'pubmed')
      articleUrl.searchParams.set('id', id)
      articleUrl.searchParams.set('retmode', 'xml')
      articleUrl.searchParams.set('tool', 'literature-reading-workbench')
      const articleXml = await request(articleUrl)
      if (!articleXml) continue
      const result = parsePubmedRecord(articleXml)
      if (result) {
        if (!result.doi) result.doi = doi
        return result
      }
    }
    return null
  }

  async function lookup(input: MetadataLookupInput): Promise<MetadataLookupResult | null> {
    const pmid = normalizePmid(input.pmid)
    const doi = normalizeDoi(input.doi)
    const hasPmidInput = input.pmid !== undefined && input.pmid !== null && String(input.pmid).trim() !== ''
    const hasDoiInput = input.doi !== undefined && input.doi !== null && String(input.doi).trim() !== ''
    if ((!pmid && !doi) || (hasPmidInput && !pmid) || (hasDoiInput && !doi)) {
      throw new MetadataLookupError('invalid-input', '请输入有效的 PMID 或 DOI。')
    }

    let pubmedError: MetadataLookupError | undefined
    if (pmid) {
      try {
        const articleUrl = new URL(PUBMED_EFETCH_URL)
        articleUrl.searchParams.set('db', 'pubmed')
        articleUrl.searchParams.set('id', pmid)
        articleUrl.searchParams.set('retmode', 'xml')
        articleUrl.searchParams.set('tool', 'literature-reading-workbench')
        const articleXml = await request(articleUrl)
        const result = articleXml ? parsePubmedRecord(articleXml) : null
        if (result) return result
      } catch (error) {
        pubmedError = errorForFetch(error, false)
      }
    }

    if (doi) {
      try {
        const pubmedResult = await searchPubmedByDoi(doi)
        if (pubmedResult) return pubmedResult
      } catch (error) {
        pubmedError = errorForFetch(error, false)
      }

      try {
        const encodedDoi = encodeURIComponent(doi).replace(/%2F/gi, '/')
        const crossrefUrl = new URL(`${CROSSREF_WORKS_URL}${encodedDoi}`)
        const crossrefJson = await request(crossrefUrl)
        if (crossrefJson) return parseCrossrefRecord(crossrefJson, doi)
      } catch (error) {
        throw errorForFetch(error, false)
      }
    }

    if (pubmedError) throw pubmedError
    return null
  }

  return { lookup }
}

