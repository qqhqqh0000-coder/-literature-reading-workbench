import { createHash, randomUUID } from 'node:crypto'
import { cp, mkdir, open, readFile, readdir, rename, rm, stat, writeFile } from 'node:fs/promises'
import path from 'node:path'

interface BaiduAppConfig {
  clientId: string
  clientSecret: string
  appName: string
}

interface BaiduToken {
  accessToken: string
  refreshToken: string
  expiresAt: number
  openId: string
  username: string
}

interface BaiduFile {
  fs_id?: number
  server_filename?: string
  path?: string
  isdir?: number
  size?: number
  dlink?: string
}

interface SnapshotEntry {
  path: string
  size: number
  sha256: string
}

interface SnapshotManifest {
  format: 1
  createdAt: string
  files: SnapshotEntry[]
}

interface RemoteSnapshot {
  id: string
  path: string
  manifest: SnapshotManifest
  files: BaiduFile[]
}

interface ApiObject {
  errno?: number
  error?: string
  error_description?: string
  [key: string]: unknown
}

export type BaiduSyncErrorCode =
  | 'configuration'
  | 'feature_disabled'
  | 'authorization_required'
  | 'authorization_expired'
  | 'application_permission'
  | 'application_directory'
  | 'no_backup'
  | 'network'
  | 'rate_limited'
  | 'server'
  | 'not_found'
  | 'integrity'
  | 'pagination'
  | 'local_io'
  | 'api'

export class BaiduSyncError extends Error {
  constructor(
    readonly code: BaiduSyncErrorCode,
    message: string,
    readonly retryable = false,
    readonly retryAfterMs?: number,
  ) {
    super(message)
    this.name = 'BaiduSyncError'
  }
}

class BaiduApiError extends BaiduSyncError {
  constructor(readonly errno: number, context: string, requestId?: unknown) {
    const request = requestId === undefined || requestId === null ? '' : `；请求编号 ${String(requestId)}`
    super(errno === -9 ? 'not_found' : 'api', `${context}失败（百度错误码 ${errno}${request}）。`, Math.abs(errno) === 31034)
    this.name = 'BaiduApiError'
  }
}

export interface BaiduSyncProgress {
  direction: 'upload' | 'download'
  phase: 'preparing' | 'file' | 'complete'
  /** Snapshot-relative path only. This deliberately never contains the OAuth token or app path. */
  file?: string
  /** 1-based while transferring; 0 while preparing or complete. */
  fileIndex: number
  filesCompleted: number
  filesTotal: number
  transferredBytes: number
  totalBytes: number
}

export type BaiduSyncProgressCallback = (progress: BaiduSyncProgress) => void

export interface BaiduSyncServiceOptions {
  dataDir: string
  pdfDir: string
  dataFile: string
  appConfigFile: string
  enabled?: boolean
}

const API_ROOT = 'https://pan.baidu.com/rest/2.0/xpan'
const AUTH_ROOT = 'https://openapi.baidu.com/oauth/2.0'
const USER_INFO_URL = 'https://openapi.baidu.com/rest/2.0/passport/users/getInfo'
const UPLOAD_ROOT = 'https://d.pcs.baidu.com/rest/2.0/pcs/superfile2'
const PART_BYTES = 4 * 1024 * 1024
const MAX_RESTORE_FILES = 20_000
const MAX_RESTORE_BYTES = 8 * 1024 * 1024 * 1024
const MAX_MANIFEST_BYTES = 16 * 1024 * 1024
const MAX_DATA_JSON_BYTES = 128 * 1024 * 1024
const MAX_DIRECTORY_ENTRIES = 1_000_000
const MAX_RETRY_ATTEMPTS = 3
const RETRY_DELAYS_MS = [350, 900]

type JsonRecord = Record<string, unknown>

class SnapshotCorruptionError extends BaiduSyncError {
  constructor(message: string) {
    super('integrity', message)
    this.name = 'SnapshotCorruptionError'
  }
}

const isRecord = (value: unknown): value is JsonRecord =>
  value !== null && typeof value === 'object' && !Array.isArray(value)

function validatePaper(value: unknown, index: number): string | null {
  if (!isRecord(value)) return `papers[${index}] 必须是对象。`
  if (value.id !== undefined && typeof value.id !== 'string') return `papers[${index}].id 必须是字符串。`
  if (value.pdf !== undefined && value.pdf !== null && !isRecord(value.pdf)) return `papers[${index}].pdf 必须是对象或 null。`
  if (value.translation !== undefined) {
    if (!isRecord(value.translation)) return `papers[${index}].translation 必须是对象。`
    for (const field of ['segments', 'picked', 'batch']) {
      if (value.translation[field] !== undefined && !Array.isArray(value.translation[field])) {
        return `papers[${index}].translation.${field} 必须是数组。`
      }
    }
  }
  if (value.progress !== undefined && !isRecord(value.progress)) return `papers[${index}].progress 必须是对象。`
  if (value.mindmaps !== undefined && !Array.isArray(value.mindmaps)) return `papers[${index}].mindmaps 必须是数组。`
  return null
}

function validateData(text: string): string | null {
  let value: unknown
  try {
    value = JSON.parse(text.replace(/^\uFEFF/, ''))
  } catch {
    return '不是有效 JSON。'
  }
  if (!isRecord(value)) return '文献数据顶层必须是 JSON 对象。'
  if (!Array.isArray(value.papers)) return 'papers 必须是数组。'
  if (value.drafts !== undefined && !Array.isArray(value.drafts)) return 'drafts 必须是数组。'
  if (value.ui !== undefined && !isRecord(value.ui)) return 'ui 必须是对象。'
  if (value.version !== undefined && (!Number.isInteger(value.version) || Number(value.version) < 1)) return 'version 必须是正整数。'
  if (value.updatedAt !== undefined && (typeof value.updatedAt !== 'number' || !Number.isFinite(value.updatedAt))) return 'updatedAt 必须是有限数字。'
  for (let index = 0; index < value.papers.length; index++) {
    const issue = validatePaper(value.papers[index], index)
    if (issue) return issue
  }
  if (Array.isArray(value.drafts)) {
    for (let index = 0; index < value.drafts.length; index++) {
      if (!isRecord(value.drafts[index])) return `drafts[${index}] 必须是对象。`
    }
  }
  return null
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function emitProgress(callback: BaiduSyncProgressCallback | undefined, progress: BaiduSyncProgress): void {
  // A renderer that closes during a transfer must not abort a valid cloud request.
  try { callback?.(progress) } catch { /* progress reporting is best effort */ }
}

function sha256(buffer: Buffer): string {
  return createHash('sha256').update(buffer).digest('hex')
}

function md5(buffer: Buffer): string {
  return createHash('md5').update(buffer).digest('hex')
}

function parseJson(text: string, context: string): ApiObject {
  let value: unknown
  try {
    value = JSON.parse(text)
  } catch {
    throw new BaiduSyncError('api', `${context}返回了无法识别的数据。`)
  }
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new BaiduSyncError('api', `${context}返回了无效数据。`)
  return value as ApiObject
}

function checkedApiResult(value: ApiObject, context: string): ApiObject {
  if (value.error) {
    const errorCode = String(value.error).toLowerCase()
    const details = String(value.error_description || value.error)
    if (context === '刷新百度授权' && /invalid_grant|invalid_token|expired/i.test(errorCode)) {
      throw new BaiduSyncError('authorization_expired', `${context}失败：百度授权已过期，请重新连接网盘。`)
    }
    if (/permission|scope/i.test(`${errorCode} ${details}`)) {
      throw new BaiduSyncError('application_permission', `${context}失败：百度应用缺少所需权限，请检查开放平台的授权范围。`)
    }
    throw new BaiduSyncError('api', `${context}失败：${details}`)
  }
  if (typeof value.errno === 'number' && value.errno !== 0) {
    if (value.errno === 6) throw new BaiduSyncError('application_permission', `${context}失败：百度应用没有这项文件权限，请在开放平台检查应用授权。`)
    if (value.errno === 110 || value.errno === 111) throw new BaiduSyncError('authorization_expired', `${context}失败：百度授权已过期，请重新连接网盘。`)
    if (Math.abs(value.errno) === 31034) {
      throw new BaiduSyncError('rate_limited', `${context}失败：百度请求过于频繁，请稍后重试。`, true)
    }
    throw new BaiduApiError(value.errno, context, value.request_id)
  }
  if (typeof value.error_code === 'number' && value.error_code !== 0) {
    throw new BaiduSyncError('api', `${context}失败（百度错误码 ${value.error_code}）。`)
  }
  return value
}

function retryAfterMs(response: Response): number | undefined {
  const header = response.headers.get('retry-after')
  if (!header) return undefined
  const seconds = Number(header)
  const delay = Number.isFinite(seconds) ? seconds * 1000 : Date.parse(header) - Date.now()
  if (!Number.isFinite(delay) || delay <= 0) return undefined
  return Math.min(3000, Math.max(100, delay))
}

async function fetchResponse(url: URL, init: RequestInit, context: string): Promise<Response> {
  let response: Response
  try {
    response = await fetch(url, { ...init, signal: init.signal || AbortSignal.timeout(120_000) })
  } catch (error) {
    if (error instanceof Error && error.name === 'TimeoutError') {
      throw new BaiduSyncError('network', `${context}超时，百度网盘暂时没有响应。`, true)
    }
    throw new BaiduSyncError('network', `${context}未能连接百度网盘，请检查网络后重试。`, true)
  }
  if (!response.ok) {
    await response.body?.cancel().catch(() => undefined)
    if (response.status === 401) {
      throw new BaiduSyncError('authorization_expired', `${context}失败：百度授权已失效，请重新连接网盘。`)
    }
    if (response.status === 403) {
      throw new BaiduSyncError('application_permission', `${context}失败：百度应用或账号缺少所需权限。`)
    }
    const retryable = response.status === 408 || response.status === 425 || response.status === 429 || response.status >= 500
    const code: BaiduSyncErrorCode = response.status === 429 ? 'rate_limited' : response.status >= 500 ? 'server' : 'api'
    throw new BaiduSyncError(
      code,
      `${context}失败（HTTP ${response.status}）。${retryable ? '百度服务暂时繁忙，请稍后重试。' : ''}`,
      retryable,
      retryAfterMs(response),
    )
  }
  return response
}

async function withTransientRetry<T>(context: string, action: () => Promise<T>): Promise<T> {
  for (let attempt = 1; attempt <= MAX_RETRY_ATTEMPTS; attempt++) {
    try {
      return await action()
    } catch (error) {
      const retryable = error instanceof BaiduSyncError && error.retryable
      if (!retryable || attempt === MAX_RETRY_ATTEMPTS) throw error
      const delay = error instanceof BaiduSyncError && error.retryAfterMs !== undefined
        ? error.retryAfterMs
        : RETRY_DELAYS_MS[attempt - 1] || RETRY_DELAYS_MS[RETRY_DELAYS_MS.length - 1]
      await new Promise((resolve) => setTimeout(resolve, delay))
    }
  }
  throw new BaiduSyncError('api', `${context}失败。`)
}

async function requestJson(url: URL, init: RequestInit, context: string): Promise<ApiObject> {
  return withTransientRetry(context, async () => {
    const response = await fetchResponse(url, init, context)
    let text: string
    try {
      text = await response.text()
    } catch {
      throw new BaiduSyncError('network', `${context}读取响应时连接中断。`, true)
    }
    return checkedApiResult(parseJson(text, context), context)
  })
}

function isMissingRemotePath(error: unknown): boolean {
  return error instanceof BaiduApiError && error.errno === -9
}

function formData(values: Record<string, string | number>): URLSearchParams {
  const result = new URLSearchParams()
  for (const [key, value] of Object.entries(values)) result.set(key, String(value))
  return result
}

function safeTimestamp(): string {
  return new Date().toISOString().replace(/[-:.TZ]/g, '')
}

function parseManifest(value: unknown): SnapshotManifest {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new SnapshotCorruptionError('云端备份清单格式不正确。')
  const object = value as Record<string, unknown>
  if (object.format !== 1 || typeof object.createdAt !== 'string' || !Array.isArray(object.files)) {
    throw new SnapshotCorruptionError('云端备份版本不受支持。')
  }
  if (object.files.length > MAX_RESTORE_FILES) throw new SnapshotCorruptionError('云端备份包含过多文件，已停止恢复。')
  const files: SnapshotEntry[] = []
  let totalBytes = 0
  const seen = new Set<string>()
  for (const item of object.files) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) throw new SnapshotCorruptionError('云端备份清单中包含无效文件。')
    const record = item as Record<string, unknown>
    const name = record.path
    if (typeof name !== 'string' || !Number.isSafeInteger(record.size) || Number(record.size) < 0 || typeof record.sha256 !== 'string') {
      throw new SnapshotCorruptionError('云端备份清单中包含无效文件信息。')
    }
    const validPath = name === 'data.json' || (/^pdfs\/[^\\/:*?"<>|]+\.pdf$/i.test(name) && path.posix.basename(name) === name.slice('pdfs/'.length))
    if (!validPath || seen.has(name)) throw new SnapshotCorruptionError('云端备份包含不允许的文件路径。')
    const size = Number(record.size)
    totalBytes += size
    if (totalBytes > MAX_RESTORE_BYTES) throw new SnapshotCorruptionError('云端备份超过 8 GB，已停止恢复。')
    if (!/^[a-f0-9]{64}$/i.test(record.sha256)) throw new SnapshotCorruptionError('云端备份清单中的校验值无效。')
    seen.add(name)
    files.push({ path: name, size, sha256: record.sha256.toLowerCase() })
  }
  if (!seen.has('data.json')) throw new SnapshotCorruptionError('云端备份缺少文献数据文件。')
  return { format: 1, createdAt: object.createdAt, files }
}

export function createBaiduSyncService({ dataDir, pdfDir, dataFile, appConfigFile, enabled = true }: BaiduSyncServiceOptions) {
  const authFile = path.join(dataDir, 'baidu-auth.json')

  function ensureEnabled(): void {
    if (!enabled) throw new BaiduSyncError('feature_disabled', '公开版未启用百度网盘同步。')
  }

  async function readConfig(): Promise<BaiduAppConfig | null> {
    if (!enabled) return null
    try {
      const value = JSON.parse(await readFile(appConfigFile, 'utf8')) as Partial<BaiduAppConfig>
      if (typeof value.clientId !== 'string' || !value.clientId.trim()) return null
      if (typeof value.clientSecret !== 'string' || !value.clientSecret.trim()) return null
      if (typeof value.appName !== 'string' || !value.appName.trim() || /[\\/]/.test(value.appName)) return null
      return { clientId: value.clientId.trim(), clientSecret: value.clientSecret.trim(), appName: value.appName.trim() }
    } catch {
      return null
    }
  }

  async function readToken(): Promise<BaiduToken | null> {
    try {
      const value = JSON.parse(await readFile(authFile, 'utf8')) as Partial<BaiduToken>
      if (typeof value.accessToken !== 'string' || typeof value.refreshToken !== 'string' || typeof value.openId !== 'string') return null
      return {
        accessToken: value.accessToken,
        refreshToken: value.refreshToken,
        expiresAt: Number(value.expiresAt) || 0,
        openId: value.openId,
        username: typeof value.username === 'string' ? value.username : '',
      }
    } catch {
      return null
    }
  }

  async function saveToken(token: BaiduToken): Promise<void> {
    await mkdir(dataDir, { recursive: true })
    const temp = `${authFile}.${randomUUID()}.tmp`
    await writeFile(temp, JSON.stringify(token, null, 2), { encoding: 'utf8', mode: 0o600 })
    await rename(temp, authFile)
  }

  async function getAuthorizedToken(): Promise<{ config: BaiduAppConfig; token: BaiduToken }> {
    const config = await readConfig()
    if (!config) throw new BaiduSyncError('configuration', '百度网盘应用配置缺失或格式不正确，请检查本机的百度应用配置文件。')
    const token = await readToken()
    if (!token) throw new BaiduSyncError('authorization_required', '还没有连接百度网盘账号，请先完成账号授权。')
    if (token.expiresAt > Date.now() + 5 * 60_000) return { config, token }

    const url = new URL(`${AUTH_ROOT}/token`)
    url.search = new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: token.refreshToken,
      client_id: config.clientId,
      client_secret: config.clientSecret,
    }).toString()
    const result = await requestJson(url, { method: 'GET' }, '刷新百度授权')
    if (typeof result.access_token !== 'string' || typeof result.refresh_token !== 'string') {
      throw new BaiduSyncError('authorization_expired', '百度没有返回有效授权，请重新连接网盘。')
    }
    const refreshed = {
      ...token,
      accessToken: result.access_token,
      refreshToken: result.refresh_token,
      expiresAt: Date.now() + Math.max(0, Number(result.expires_in) || 0) * 1000,
    }
    await saveToken(refreshed)
    return { config, token: refreshed }
  }

  async function getUserInfo(accessToken: string): Promise<{ openId: string; username: string }> {
    const url = new URL(USER_INFO_URL)
    url.searchParams.set('access_token', accessToken)
    const result = await requestJson(url, { method: 'GET' }, '读取百度账号信息')
    if (typeof result.openid !== 'string' || !result.openid) throw new BaiduSyncError('api', '百度没有返回账号标识。')
    return { openId: result.openid, username: typeof result.username === 'string' ? result.username : '' }
  }

  async function requestXpan(endpoint: string, params: Record<string, string | number>, context: string, body?: URLSearchParams): Promise<ApiObject> {
    const { token } = await getAuthorizedToken()
    const url = new URL(`${API_ROOT}/${endpoint}`)
    url.searchParams.set('access_token', token.accessToken)
    for (const [key, value] of Object.entries(params)) url.searchParams.set(key, String(value))
    return requestJson(url, body
      ? { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() }
      : { method: 'GET' }, context)
  }

  async function listDirectory(remotePath: string): Promise<BaiduFile[]> {
    const all: BaiduFile[] = []
    const pageSize = 1000
    const seenFiles = new Set<string>()
    const seenPages = new Set<string>()
    const seenStarts = new Set<number>()
    let start = 0
    // Baidu's developer material identifies this direct REST endpoint as
    // `/rest/2.0/xpan/file?method=list` (developer.baidu.com/question/detail.html?id=178).
    // The endpoint-specific XPan schema cross-check (github.com/lfhy/xpan/file)
    // defines zero-based `start` + `limit`, with `has_more` and the next `cursor`.
    // The accessible Baidu overview does not print those pagination fields, so
    // this direct API contract is not inferred from the separate MCP `page`
    // wrapper. If a compatible response omits cursor, advance by the actual
    // number of returned items instead of assuming a full page.
    while (start < MAX_DIRECTORY_ENTRIES) {
      if (seenStarts.has(start)) throw new BaiduSyncError('pagination', `读取百度网盘目录 ${remotePath} 时分页位置重复，已停止读取。`)
      seenStarts.add(start)
      const result = await requestXpan('file', {
        method: 'list', dir: remotePath, start, limit: pageSize, order: 'name', desc: 0,
      }, `读取百度网盘目录 ${remotePath}`)
      if (!Array.isArray(result.list)) {
        throw new BaiduSyncError('pagination', `读取百度网盘目录 ${remotePath} 时，百度没有返回文件列表。`)
      }
      const page = result.list as BaiduFile[]
      const hasMore = Number(result.has_more)
      if (page.length === 0) {
        if (hasMore === 1) throw new BaiduSyncError('pagination', `读取百度网盘目录 ${remotePath} 时，分页仍报告有后续数据但返回空页。`)
        return all
      }

      const identityOf = (file: BaiduFile): string => {
        if (typeof file.fs_id === 'number' && Number.isFinite(file.fs_id)) return `fs:${file.fs_id}`
        if (typeof file.path === 'string' && file.path) return `path:${file.path}`
        return `name:${String(file.server_filename || '')}\0${Number(file.isdir) === 1 ? 'dir' : 'file'}\0${Number(file.size) || 0}`
      }
      const pageIdentities = page.map(identityOf)
      const pageSignature = pageIdentities.join('\n')
      if (seenPages.has(pageSignature)) {
        throw new BaiduSyncError('pagination', `读取百度网盘目录 ${remotePath} 时重复收到同一分页，已停止以免遗漏文件。`)
      }
      seenPages.add(pageSignature)
      let added = 0
      for (let index = 0; index < page.length; index++) {
        const file = page[index]
        const identity = pageIdentities[index]
        if (seenFiles.has(identity)) continue
        seenFiles.add(identity)
        all.push(file)
        added++
      }
      if (all.length > MAX_DIRECTORY_ENTRIES) {
        throw new BaiduSyncError('pagination', `百度网盘目录 ${remotePath} 超过 ${MAX_DIRECTORY_ENTRIES} 个条目，已停止读取。`)
      }
      if (hasMore !== 1) {
        // Some endpoint versions omit has_more. A short page is unambiguously
        // terminal; a full page is advanced and checked for a repeated cursor.
        if (hasMore === 0 || page.length < pageSize) return all
      }
      if (added === 0) {
        throw new BaiduSyncError('pagination', `读取百度网盘目录 ${remotePath} 的后续分页时没有新文件，已停止读取。`)
      }

      const hasCursor = result.cursor !== undefined && result.cursor !== null
      const cursor = Number(result.cursor)
      const nextStart = hasCursor ? cursor : start + page.length
      if (!Number.isSafeInteger(nextStart) || nextStart <= start) {
        throw new BaiduSyncError('pagination', `读取百度网盘目录 ${remotePath} 时百度返回了无效分页位置。`)
      }
      start = nextStart
    }
    throw new BaiduSyncError('pagination', `百度网盘目录 ${remotePath} 超过 ${MAX_DIRECTORY_ENTRIES} 个条目，已停止读取。`)
  }

  async function ensureCloudDirectory(config: BaiduAppConfig, remotePath: string): Promise<void> {
    const segments = remotePath.split('/').filter(Boolean)
    if (segments.length < 2 || segments[0] !== 'apps' || segments[1] !== config.appName) {
      throw new BaiduSyncError('application_directory', '百度网盘同步目录配置不正确。')
    }
    // `/apps` is a Baidu-managed root. Never try to create it or silently treat
    // a missing/mistyped app name as an empty backup folder.
    let appEntries: BaiduFile[]
    try {
      appEntries = await listDirectory('/apps')
    } catch (error) {
      if (isMissingRemotePath(error)) {
        throw new BaiduSyncError('application_permission', '无法读取百度网盘应用目录，请检查网盘文件权限和应用授权。')
      }
      throw error
    }
    const appRootExists = appEntries.some((entry) => entry.server_filename === config.appName && Number(entry.isdir) === 1)
    if (!appRootExists) {
      // Initialize the registered app's virtual root on the first explicit
      // backup. Baidu still validates that the path belongs to this OAuth app.
      const appRoot = `/apps/${config.appName}`
      try {
        await requestXpan('file', { method: 'create' }, '初始化百度网盘应用目录', formData({
          path: appRoot, size: 0, isdir: 1, block_list: '[]',
        }))
      } catch (error) {
        if (error instanceof BaiduSyncError && [
          'network', 'rate_limited', 'server', 'authorization_expired', 'application_permission',
        ].includes(error.code)) throw error
        throw new BaiduSyncError('application_directory', `无法初始化百度网盘应用目录。请核对应用名称是否与开放平台登记名称完全一致，并检查网盘文件权限。${messageOf(error)}`)
      }
      appEntries = await listDirectory('/apps')
      if (!appEntries.some((entry) => entry.server_filename === config.appName && Number(entry.isdir) === 1)) {
        throw new BaiduSyncError('application_directory', '百度网盘未显示刚初始化的应用目录，请检查应用名称和网盘文件权限。')
      }
    }

    let parent = `/apps/${config.appName}`
    for (const segment of segments.slice(2)) {
      const current = `${parent}/${segment}`
      let entries: BaiduFile[]
      try {
        entries = await listDirectory(parent)
      } catch (error) {
        if (isMissingRemotePath(error)) entries = []
        else throw error
      }
      if (!entries.some((entry) => entry.server_filename === segment && Number(entry.isdir) === 1)) {
        // A same-named file is a conflict, not an absent directory.
        if (entries.some((entry) => entry.server_filename === segment)) {
          throw new BaiduSyncError('application_directory', `百度网盘路径 ${current} 已存在同名文件，请在网盘中调整后重试。`)
        }
        try {
          await requestXpan('file', { method: 'create' }, '创建百度网盘同步目录', formData({ path: current, size: 0, isdir: 1, block_list: '[]' }))
        } catch (error) {
          // Another client may have created this folder between list and create.
          if (!isMissingRemotePath(error)) throw error
          const refreshed = await listDirectory(parent)
          if (!refreshed.some((entry) => entry.server_filename === segment && Number(entry.isdir) === 1)) throw error
        }
      }
      parent = current
    }
  }

  async function uploadBuffer(remotePath: string, buffer: Buffer, onUploadedBytes?: (bytes: number) => void): Promise<void> {
    const blockHashes: string[] = []
    for (let offset = 0; offset < buffer.length; offset += PART_BYTES) {
      blockHashes.push(md5(buffer.subarray(offset, Math.min(buffer.length, offset + PART_BYTES))))
    }
    if (blockHashes.length === 0) blockHashes.push(md5(Buffer.alloc(0)))
    const precreate = await requestXpan('file', { method: 'precreate' }, '准备上传到百度网盘', formData({
      path: remotePath,
      size: buffer.length,
      isdir: 0,
      autoinit: 1,
      block_list: JSON.stringify(blockHashes),
      rtype: 3,
    }))
    if (Number(precreate.return_type) === 2) {
      onUploadedBytes?.(buffer.length)
      return
    }
    if (typeof precreate.uploadid !== 'string') throw new BaiduSyncError('api', '百度没有创建上传任务。')
    const { token } = await getAuthorizedToken()
    let uploadedBytes = 0
    for (let sequence = 0, offset = 0; offset < buffer.length; sequence++, offset += PART_BYTES) {
      const chunk = buffer.subarray(offset, Math.min(buffer.length, offset + PART_BYTES))
      const url = new URL(UPLOAD_ROOT)
      url.search = new URLSearchParams({
        method: 'upload',
        access_token: token.accessToken,
        type: 'tmpfile',
        path: remotePath,
        uploadid: precreate.uploadid,
        partseq: String(sequence),
      }).toString()
      const form = new FormData()
      form.append('file', new Blob([chunk]), path.posix.basename(remotePath))
      await requestJson(url, { method: 'POST', body: form }, '上传百度网盘文件分片')
      uploadedBytes += chunk.length
      onUploadedBytes?.(uploadedBytes)
    }
    if (buffer.length === 0) onUploadedBytes?.(0)
    await requestXpan('file', { method: 'create' }, '完成百度网盘文件上传', formData({
      path: remotePath,
      size: buffer.length,
      isdir: 0,
      uploadid: precreate.uploadid,
      block_list: JSON.stringify(blockHashes),
      rtype: 3,
    }))
  }

  async function downloadBuffer(file: BaiduFile, expectedSize?: number, maxBytes = MAX_RESTORE_BYTES): Promise<Buffer> {
    if (typeof file.fs_id !== 'number') throw new SnapshotCorruptionError('百度网盘文件标识无效。')
    const { token } = await getAuthorizedToken()
    const url = new URL(`${API_ROOT}/multimedia`)
    url.search = new URLSearchParams({
      method: 'filemetas',
      access_token: token.accessToken,
      fsids: JSON.stringify([file.fs_id]),
      dlink: '1',
    }).toString()
    const meta = await requestJson(url, { method: 'GET' }, '读取百度网盘备份信息')
    const items = Array.isArray(meta.list) ? meta.list as BaiduFile[] : []
    if (!items[0]) throw new SnapshotCorruptionError('百度网盘中的备份文件已不存在。')
    if (typeof items[0].dlink !== 'string') throw new BaiduSyncError('application_permission', '百度网盘未提供备份下载地址，请检查文件权限。')
    const metadataSize = items[0].size
    if (!Number.isSafeInteger(metadataSize) || Number(metadataSize) < 0) {
      throw new SnapshotCorruptionError('百度网盘返回的备份文件大小无效。')
    }
    if (Number(metadataSize) > maxBytes || (expectedSize !== undefined && Number(metadataSize) !== expectedSize)) {
      throw new SnapshotCorruptionError('百度网盘文件大小与备份清单不符，已停止读取。')
    }
    const bodyLimit = expectedSize ?? Math.min(maxBytes, Number(metadataSize))
    const downloadUrl = new URL(items[0].dlink)
    downloadUrl.searchParams.set('access_token', token.accessToken)
    return withTransientRetry('下载百度网盘备份文件', async () => {
      const response = await fetchResponse(downloadUrl, {
        headers: { 'User-Agent': 'pan.baidu.com' },
        signal: AbortSignal.timeout(120_000),
      }, '下载百度网盘文件')
      const contentLength = Number(response.headers.get('content-length'))
      if (Number.isFinite(contentLength) && contentLength > bodyLimit) {
        await response.body?.cancel().catch(() => undefined)
        throw new SnapshotCorruptionError('百度网盘返回的文件超过备份清单声明大小，已停止读取。')
      }
      if (!response.body) throw new BaiduSyncError('network', '百度网盘下载响应为空。', true)
      const reader = response.body.getReader()
      const chunks: Buffer[] = []
      let received = 0
      try {
        while (true) {
          let result: ReadableStreamReadResult<Uint8Array>
          try {
            result = await reader.read()
          } catch {
            throw new BaiduSyncError('network', '下载百度网盘文件时连接中断。', true)
          }
          if (result.done) break
          received += result.value.byteLength
          if (received > bodyLimit) {
            await reader.cancel().catch(() => undefined)
            throw new SnapshotCorruptionError('百度网盘返回的文件超过备份清单声明大小，已停止读取。')
          }
          chunks.push(Buffer.from(result.value))
        }
      } finally {
        reader.releaseLock()
      }
      if (received !== Number(metadataSize) || (expectedSize !== undefined && received !== expectedSize)) {
        throw new BaiduSyncError('network', '百度网盘下载未完整，文件大小与服务端信息不符。', true)
      }
      return Buffer.concat(chunks, received)
    })
  }

  async function downloadToFile(
    file: BaiduFile,
    destination: string,
    expectedSize: number,
    onReceivedBytes?: (bytes: number) => void,
  ): Promise<string> {
    if (typeof file.fs_id !== 'number') throw new SnapshotCorruptionError('百度网盘文件标识无效。')
    const { token } = await getAuthorizedToken()
    const url = new URL(`${API_ROOT}/multimedia`)
    url.search = new URLSearchParams({
      method: 'filemetas', access_token: token.accessToken, fsids: JSON.stringify([file.fs_id]), dlink: '1',
    }).toString()
    const meta = await requestJson(url, { method: 'GET' }, '读取百度网盘备份信息')
    const items = Array.isArray(meta.list) ? meta.list as BaiduFile[] : []
    const item = items[0]
    if (!item) throw new SnapshotCorruptionError('百度网盘中的备份文件已不存在。')
    if (typeof item.dlink !== 'string') throw new BaiduSyncError('application_permission', '百度网盘未提供备份下载地址，请检查文件权限。')
    if (!Number.isSafeInteger(item.size) || Number(item.size) !== expectedSize || expectedSize > MAX_RESTORE_BYTES) {
      throw new SnapshotCorruptionError('百度网盘文件大小与备份清单不符，已停止恢复。')
    }
    const downloadUrl = new URL(item.dlink)
    downloadUrl.searchParams.set('access_token', token.accessToken)
    return withTransientRetry('下载百度网盘备份文件', async () => {
      await rm(destination, { force: true })
      onReceivedBytes?.(0)
      const response = await fetchResponse(downloadUrl, {
        headers: { 'User-Agent': 'pan.baidu.com' },
        signal: AbortSignal.timeout(120_000),
      }, '下载百度网盘文件')
      const contentLengthHeader = response.headers.get('content-length')
      const contentLength = contentLengthHeader === null ? undefined : Number(contentLengthHeader)
      if (contentLength !== undefined && Number.isFinite(contentLength) && contentLength > expectedSize) {
        await response.body?.cancel().catch(() => undefined)
        throw new SnapshotCorruptionError('百度网盘返回的文件超过备份清单声明大小，已停止恢复。')
      }
      if (!response.body) throw new BaiduSyncError('network', '百度网盘下载响应为空。', true)

      const fileHandle = await open(destination, 'wx').catch(() => {
        throw new BaiduSyncError('local_io', '无法创建临时恢复文件，请检查本机磁盘空间和文件权限。')
      })
      const hash = createHash('sha256')
      let received = 0
      try {
        const reader = response.body.getReader()
        try {
          while (true) {
            let result: ReadableStreamReadResult<Uint8Array>
            try {
              result = await reader.read()
            } catch {
              throw new BaiduSyncError('network', '下载百度网盘文件时连接中断。', true)
            }
            if (result.done) break
            if (received + result.value.byteLength > expectedSize) {
              await reader.cancel().catch(() => undefined)
              throw new SnapshotCorruptionError('百度网盘返回的文件超过备份清单声明大小，已停止恢复。')
            }
            const chunk = Buffer.from(result.value)
            let offset = 0
            while (offset < chunk.length) {
              let writeResult: { bytesWritten: number }
              try {
                writeResult = await fileHandle.write(chunk, offset, chunk.length - offset, received + offset)
              } catch {
                throw new BaiduSyncError('local_io', '写入临时恢复文件失败，请检查本机磁盘空间和文件权限。')
              }
              if (writeResult.bytesWritten === 0) throw new BaiduSyncError('local_io', '写入临时恢复文件失败。')
              offset += writeResult.bytesWritten
            }
            hash.update(chunk)
            received += chunk.length
            onReceivedBytes?.(received)
          }
        } finally {
          reader.releaseLock()
        }
        if (received !== expectedSize) throw new BaiduSyncError('network', '百度网盘下载未完整，文件大小与服务端信息不符。', true)
        try {
          await fileHandle.sync()
        } catch {
          throw new BaiduSyncError('local_io', '无法保存临时恢复文件，请检查本机磁盘空间和文件权限。')
        }
        return hash.digest('hex')
      } finally {
        await fileHandle.close().catch(() => undefined)
      }
    }).catch(async (error) => {
      await rm(destination, { force: true }).catch(() => undefined)
      throw error
    })
  }

  function getSnapshotRoot(config: BaiduAppConfig, openId: string): string {
    return `/apps/${config.appName}/文献阅读工作台/${openId}`
  }

  async function localSnapshotPaths(): Promise<Array<{ path: string; filePath: string }>> {
    const entries: Array<{ path: string; filePath: string }> = [{ path: 'data.json', filePath: dataFile }]
    let pdfEntries: Array<{ name: string; isFile(): boolean }>
    try {
      pdfEntries = await readdir(pdfDir, { withFileTypes: true })
    } catch (error) {
      if (error && typeof error === 'object' && (error as NodeJS.ErrnoException).code === 'ENOENT') pdfEntries = []
      else throw new BaiduSyncError('local_io', `无法读取本机 PDF 目录：${messageOf(error)}`)
    }
    for (const entry of pdfEntries) {
      if (!entry.isFile() || !/\.pdf$/i.test(entry.name) || path.basename(entry.name) !== entry.name) continue
      entries.push({ path: `pdfs/${entry.name}`, filePath: path.join(pdfDir, entry.name) })
    }
    return entries
  }

  async function uploadSnapshot(onProgress?: BaiduSyncProgressCallback): Promise<{ snapshotId: string; files: number; bytes: number }> {
    ensureEnabled()
    emitProgress(onProgress, {
      direction: 'upload', phase: 'preparing', fileIndex: 0, filesCompleted: 0, filesTotal: 0, transferredBytes: 0, totalBytes: 0,
    })
    const { config, token } = await getAuthorizedToken()
    const root = getSnapshotRoot(config, token.openId)
    const snapshotId = `${safeTimestamp()}-${randomUUID().slice(0, 8)}`
    const snapshotPath = `${root}/${snapshotId}`

    const localFiles = await localSnapshotPaths()
    const localSizes = await Promise.all(localFiles.map(async (file) => {
      try {
        const info = await stat(file.filePath)
        if (!info.isFile() || !Number.isSafeInteger(info.size) || info.size < 0) {
          throw new BaiduSyncError('local_io', `本机备份文件无效：${file.path}`)
        }
        return info.size
      } catch (error) {
        if (error instanceof BaiduSyncError) throw error
        throw new BaiduSyncError('local_io', `无法读取本机备份文件信息：${file.path}`)
      }
    }))
    const totalBytes = localSizes.reduce((total, size) => total + size, 0)
    if (localFiles.length > MAX_RESTORE_FILES || !Number.isSafeInteger(totalBytes) || totalBytes > MAX_RESTORE_BYTES) {
      throw new BaiduSyncError('integrity', '本机备份超过当前版本可恢复的文件数量或 8 GB 大小限制，未上传。')
    }
    if (localSizes[0] > MAX_DATA_JSON_BYTES) {
      throw new BaiduSyncError('integrity', '本机文献数据超过 128 MB，当前版本无法可靠恢复，未上传。')
    }
    await ensureCloudDirectory(config, `${snapshotPath}/pdfs`)
    emitProgress(onProgress, {
      direction: 'upload', phase: 'preparing', fileIndex: 0, filesCompleted: 0,
      filesTotal: localFiles.length, transferredBytes: 0, totalBytes,
    })
    const manifest: SnapshotManifest = { format: 1, createdAt: new Date().toISOString(), files: [] }
    let bytes = 0
    let transferredBytes = 0
    for (let index = 0; index < localFiles.length; index++) {
      const file = localFiles[index]
      const expectedSize = localSizes[index]
      emitProgress(onProgress, {
        direction: 'upload', phase: 'file', file: file.path, fileIndex: index + 1,
        filesCompleted: index, filesTotal: localFiles.length, transferredBytes, totalBytes,
      })
      let buffer: Buffer
      try {
        buffer = await readFile(file.filePath)
      } catch {
        throw new BaiduSyncError('local_io', `无法读取本机备份文件：${file.path}`)
      }
      if (buffer.length !== expectedSize) {
        throw new BaiduSyncError('local_io', `备份过程中本机文件发生了变化：${file.path}。请保存文件后重新备份。`)
      }
      const remotePath = `${snapshotPath}/${file.path}`
      await uploadBuffer(remotePath, buffer, (fileBytes) => emitProgress(onProgress, {
        direction: 'upload', phase: 'file', file: file.path, fileIndex: index + 1,
        filesCompleted: index, filesTotal: localFiles.length, transferredBytes: transferredBytes + fileBytes, totalBytes,
      }))
      manifest.files.push({ path: file.path, size: buffer.length, sha256: sha256(buffer) })
      bytes += buffer.length
      transferredBytes += buffer.length
      emitProgress(onProgress, {
        direction: 'upload', phase: 'file', file: file.path, fileIndex: index + 1,
        filesCompleted: index + 1, filesTotal: localFiles.length, transferredBytes, totalBytes,
      })
    }
    // The manifest is published last so incomplete snapshots stay unreadable.
    // Progress byte totals cover the data/PDF payload; completion is emitted only
    // after this final commit marker has uploaded successfully.
    emitProgress(onProgress, {
      direction: 'upload', phase: 'preparing', fileIndex: 0, filesCompleted: localFiles.length,
      filesTotal: localFiles.length, transferredBytes, totalBytes,
    })
    await uploadBuffer(`${snapshotPath}/manifest.json`, Buffer.from(JSON.stringify(manifest, null, 2), 'utf8'))
    emitProgress(onProgress, {
      direction: 'upload', phase: 'complete', fileIndex: 0, filesCompleted: localFiles.length,
      filesTotal: localFiles.length, transferredBytes: totalBytes, totalBytes,
    })
    return { snapshotId, files: localFiles.length, bytes }
  }

  async function readRemoteManifest(snapshotPath: string): Promise<{ manifest: SnapshotManifest; files: BaiduFile[] }> {
    const files = await listDirectory(snapshotPath)
    const manifestFile = files.find((file) => file.server_filename === 'manifest.json' && Number(file.isdir) !== 1)
    if (!manifestFile) throw new SnapshotCorruptionError('这个云端目录还没有完整备份清单。')
    let buffer: Buffer
    try {
      buffer = await downloadBuffer(manifestFile, undefined, MAX_MANIFEST_BYTES)
    } catch (error) {
      if (isMissingRemotePath(error)) throw new SnapshotCorruptionError('云端备份清单文件已不存在。')
      throw error
    }
    let parsed: unknown
    try {
      parsed = JSON.parse(buffer.toString('utf8'))
    } catch {
      throw new SnapshotCorruptionError('云端备份清单不是有效 JSON。')
    }
    return { manifest: parseManifest(parsed), files }
  }

  async function snapshotCandidates(maxSnapshots = Number.POSITIVE_INFINITY): Promise<RemoteSnapshot[]> {
    const { config, token } = await getAuthorizedToken()
    const root = getSnapshotRoot(config, token.openId)
    // Resolve the app root separately so errno -9 in a per-user backup path
    // means “no snapshots yet”, while a wrong app name remains actionable.
    let appEntries: BaiduFile[]
    try {
      appEntries = await listDirectory('/apps')
    } catch (error) {
      if (isMissingRemotePath(error)) throw new BaiduSyncError('application_permission', '无法读取百度网盘应用目录，请检查网盘文件权限和应用授权。')
      throw error
    }
    if (!appEntries.some((entry) => entry.server_filename === config.appName && Number(entry.isdir) === 1)) {
      throw new BaiduSyncError('application_directory', '百度网盘中还没有此应用的专属目录。首次备份时会初始化目录；若已备份过，请核对本机配置中的应用名称是否与开放平台登记名称完全一致。')
    }
    let rootEntries: BaiduFile[]
    try {
      rootEntries = await listDirectory(root)
    } catch (error) {
      if (isMissingRemotePath(error)) return []
      throw error
    }
    const candidates = rootEntries
      .filter((file) => Number(file.isdir) === 1 && typeof file.server_filename === 'string')
      .sort((a, b) => String(b.server_filename).localeCompare(String(a.server_filename)))
    const snapshots: RemoteSnapshot[] = []
    let unreadableSnapshots = 0
    for (const candidate of candidates) {
      const snapshotPath = `${root}/${candidate.server_filename}`
      try {
        const result = await readRemoteManifest(snapshotPath)
        snapshots.push({ id: candidate.server_filename!, path: snapshotPath, ...result })
        if (snapshots.length >= maxSnapshots) break
      } catch (error) {
        if (error instanceof SnapshotCorruptionError || isMissingRemotePath(error)) {
          unreadableSnapshots++
          continue
        }
        throw error
      }
    }
    if (snapshots.length === 0 && unreadableSnapshots > 0) {
      throw new BaiduSyncError('integrity', '百度网盘中发现备份目录，但没有可读取的完整快照；本机数据未更改。')
    }
    return snapshots
  }

  async function latestSnapshot(): Promise<RemoteSnapshot | null> {
    return (await snapshotCandidates(1))[0] || null
  }

  async function restoreLatestSnapshot(onProgress?: BaiduSyncProgressCallback): Promise<{ snapshotId: string; files: number; papers: number; localBackupPath: string }> {
    ensureEnabled()
    emitProgress(onProgress, {
      direction: 'download', phase: 'preparing', fileIndex: 0, filesCompleted: 0, filesTotal: 0, transferredBytes: 0, totalBytes: 0,
    })
    const snapshots = await snapshotCandidates()
    if (!snapshots.length) throw new BaiduSyncError('no_backup', '百度网盘中没有可读取的完整备份。')

    for (const snapshot of snapshots) {
      const filesTotal = snapshot.manifest.files.length
      const totalBytes = snapshot.manifest.files.reduce((total, file) => total + file.size, 0)
      let transferredBytes = 0
      emitProgress(onProgress, {
        direction: 'download', phase: 'preparing', fileIndex: 0, filesCompleted: 0,
        filesTotal, transferredBytes: 0, totalBytes,
      })
      const stage = path.join(path.dirname(dataDir), `.literature-reading-restore-${randomUUID()}`)
      try {
        await mkdir(path.join(stage, 'pdfs'), { recursive: true })
        const filesByPath = new Map(snapshot.files.map((file) => [file.server_filename || '', file]))
        if (snapshot.manifest.files.some((entry) => entry.path.startsWith('pdfs/'))) {
          let pdfEntries: BaiduFile[]
          try {
            pdfEntries = await listDirectory(`${snapshot.path}/pdfs`)
          } catch (error) {
            if (isMissingRemotePath(error)) throw new SnapshotCorruptionError('云端备份缺少 PDF 目录。')
            throw error
          }
          for (const file of pdfEntries) filesByPath.set(`pdfs/${file.server_filename || ''}`, file)
        }

        let currentEntries: Array<{ name: string }>
        try {
          currentEntries = await readdir(dataDir, { withFileTypes: true })
        } catch (error) {
          if (!error || typeof error !== 'object' || (error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
          currentEntries = []
        }
        for (const entry of currentEntries) {
          if (entry.name === 'data.json' || entry.name === 'pdfs') continue
          await cp(path.join(dataDir, entry.name), path.join(stage, entry.name), { recursive: true, errorOnExist: true })
        }

        let dataText = ''
        for (let index = 0; index < snapshot.manifest.files.length; index++) {
          const item = snapshot.manifest.files[index]
          const remoteName = item.path
          if (remoteName === 'data.json' && item.size > MAX_DATA_JSON_BYTES) {
            throw new SnapshotCorruptionError('云端文献数据文件超过 128 MB，已停止恢复。')
          }
          const key = remoteName === 'data.json' ? 'data.json' : `pdfs/${path.posix.basename(remoteName)}`
          const remoteFile = filesByPath.get(key)
          if (!remoteFile || Number(remoteFile.isdir) === 1) throw new SnapshotCorruptionError(`云端备份缺少文件：${remoteName}`)
          const destination = remoteName === 'data.json'
            ? path.join(stage, 'data.json')
            : path.join(stage, 'pdfs', path.posix.basename(remoteName))
          emitProgress(onProgress, {
            direction: 'download', phase: 'file', file: remoteName, fileIndex: index + 1,
            filesCompleted: index, filesTotal, transferredBytes, totalBytes,
          })
          let digest: string
          try {
            digest = await downloadToFile(remoteFile, destination, item.size, (fileBytes) => emitProgress(onProgress, {
              direction: 'download', phase: 'file', file: remoteName, fileIndex: index + 1,
              filesCompleted: index, filesTotal, transferredBytes: transferredBytes + fileBytes, totalBytes,
            }))
          } catch (error) {
            if (isMissingRemotePath(error)) throw new SnapshotCorruptionError(`云端备份缺少文件：${remoteName}`)
            throw error
          }
          if (digest !== item.sha256) throw new SnapshotCorruptionError(`云端文件校验失败：${remoteName}`)
          if (remoteName === 'data.json') {
            try {
              dataText = await readFile(destination, 'utf8')
            } catch {
              throw new BaiduSyncError('local_io', '无法读取已校验的临时文献数据文件，请检查本机磁盘和权限。')
            }
          }
          transferredBytes += item.size
          emitProgress(onProgress, {
            direction: 'download', phase: 'file', file: remoteName, fileIndex: index + 1,
            filesCompleted: index + 1, filesTotal, transferredBytes, totalBytes,
          })
        }

        const dataIssue = validateData(dataText)
        if (dataIssue) throw new SnapshotCorruptionError(`云端文献数据格式不正确：${dataIssue}未替换本机数据。`)
        const parsed = JSON.parse(dataText) as { papers: unknown[] }

        // Swap the local data only after this candidate is fully staged and validated.
        const backup = `${dataDir}.before-cloud-restore-${safeTimestamp()}-${randomUUID().slice(0, 8)}`
        await mkdir(path.dirname(dataDir), { recursive: true })
        await rename(dataDir, backup)
        try {
          await rename(stage, dataDir)
        } catch (error) {
          try {
            await rename(backup, dataDir)
          } catch {
            throw new BaiduSyncError('local_io', `云端数据未能放入本机目录，原数据仍保存在：${backup}。请勿删除该备份目录。`)
          }
          throw error
        }
        emitProgress(onProgress, {
          direction: 'download', phase: 'complete', fileIndex: 0, filesCompleted: filesTotal,
          filesTotal, transferredBytes: totalBytes, totalBytes,
        })
        return {
          snapshotId: snapshot.id,
          files: snapshot.manifest.files.length,
          papers: parsed.papers.length,
          localBackupPath: backup,
        }
      } catch (error) {
        try {
          await rm(stage, { recursive: true, force: true })
        } catch (cleanupError) {
          throw new BaiduSyncError('local_io', `清理临时恢复目录失败（${stage}）：${messageOf(cleanupError)}`)
        }
        if (error instanceof SnapshotCorruptionError) continue
        if (error instanceof BaiduSyncError) throw error
        throw new BaiduSyncError('local_io', `本机恢复操作失败：${messageOf(error)}`)
      }
    }
    throw new BaiduSyncError('integrity', '所有云端备份均已损坏或不完整，未替换本机数据。')
  }

  async function status(): Promise<{
    configured: boolean
    connected: boolean
    publicBuild: boolean
    account?: string
    expiresAt?: number
    error?: string
  }> {
    if (!enabled) return { configured: false, connected: false, publicBuild: true }
    if (!(await readConfig())) return { configured: false, connected: false, publicBuild: false }
    const token = await readToken()
    if (!token) return { configured: true, connected: false, publicBuild: false }
    return { configured: true, connected: true, publicBuild: false, account: token.username || '已连接', expiresAt: token.expiresAt }
  }

  async function authorizationUrl(): Promise<string> {
    ensureEnabled()
    const config = await readConfig()
    if (!config) throw new BaiduSyncError('configuration', '百度网盘应用配置缺失或格式不正确。')
    const url = new URL(`${AUTH_ROOT}/authorize`)
    url.search = new URLSearchParams({
      response_type: 'code',
      client_id: config.clientId,
      redirect_uri: 'oob',
      scope: 'basic,netdisk',
      display: 'popup',
      qrcode: '1',
      force_login: '1',
    }).toString()
    return url.toString()
  }

  async function connect(code: string): Promise<{ account: string }> {
    ensureEnabled()
    const config = await readConfig()
    if (!config) throw new BaiduSyncError('configuration', '百度网盘应用配置缺失或格式不正确。')
    const cleanCode = code.trim()
    if (!cleanCode || cleanCode.length > 512 || /\s/.test(cleanCode)) throw new BaiduSyncError('authorization_required', '请粘贴百度授权页面显示的授权码。')
    const url = new URL(`${AUTH_ROOT}/token`)
    url.search = new URLSearchParams({
      grant_type: 'authorization_code',
      code: cleanCode,
      client_id: config.clientId,
      client_secret: config.clientSecret,
      redirect_uri: 'oob',
    }).toString()
    const result = await requestJson(url, { method: 'GET' }, '获取百度网盘授权')
    if (typeof result.access_token !== 'string' || typeof result.refresh_token !== 'string') throw new BaiduSyncError('authorization_expired', '百度没有返回有效授权。')
    const account = await getUserInfo(result.access_token)
    await saveToken({
      accessToken: result.access_token,
      refreshToken: result.refresh_token,
      expiresAt: Date.now() + Math.max(0, Number(result.expires_in) || 0) * 1000,
      openId: account.openId,
      username: account.username,
    })
    return { account: account.username || '百度网盘账号' }
  }

  async function disconnect(): Promise<void> {
    ensureEnabled()
    await rm(authFile, { force: true })
  }

  async function getLatestBackupSummary(): Promise<{ snapshotId: string; createdAt: string; files: number; bytes: number } | null> {
    ensureEnabled()
    const snapshot = await latestSnapshot()
    if (!snapshot) return null
    return {
      snapshotId: snapshot.id,
      createdAt: snapshot.manifest.createdAt,
      files: snapshot.manifest.files.length,
      bytes: snapshot.manifest.files.reduce((total, entry) => total + entry.size, 0),
    }
  }

  async function getRestorePreview(): Promise<{
    backup: null | { snapshotId: string; createdAt: string; files: number; bytes: number; papers: number | null; pdfs: number }
    local: { papers: number | null; pdfs: number | null }
  }> {
    ensureEnabled()
    const snapshot = await latestSnapshot()

    let localPapers: number | null = 0
    try {
      const localData = JSON.parse((await readFile(dataFile, 'utf8')).replace(/^\uFEFF/, '')) as unknown
      localPapers = isRecord(localData) && Array.isArray(localData.papers) ? localData.papers.length : null
    } catch (error) {
      if (error && typeof error === 'object' && (error as NodeJS.ErrnoException).code !== 'ENOENT') localPapers = null
    }

    let localPdfs: number | null = 0
    try {
      const entries = await readdir(pdfDir, { withFileTypes: true })
      localPdfs = entries.filter((entry) => entry.isFile() && /\.pdf$/i.test(entry.name)).length
    } catch (error) {
      if (error && typeof error === 'object' && (error as NodeJS.ErrnoException).code !== 'ENOENT') localPdfs = null
    }

    if (!snapshot) return { backup: null, local: { papers: localPapers, pdfs: localPdfs } }

    const dataEntry = snapshot.manifest.files.find((entry) => entry.path === 'data.json')
    const remoteDataFile = snapshot.files.find((file) => file.server_filename === 'data.json' && Number(file.isdir) !== 1)
    let remotePapers: number | null = null
    if (dataEntry && dataEntry.size <= MAX_DATA_JSON_BYTES && remoteDataFile) {
      try {
        const text = (await downloadBuffer(remoteDataFile, dataEntry.size, MAX_DATA_JSON_BYTES)).toString('utf8')
        if (!validateData(text)) {
          const remoteData = JSON.parse(text) as { papers: unknown[] }
          remotePapers = remoteData.papers.length
        }
      } catch {
        // Keep the metadata preview available when the cloud data file cannot be read;
        // the restore path will perform its normal full validation before replacing local files.
      }
    }

    return {
      backup: {
        snapshotId: snapshot.id,
        createdAt: snapshot.manifest.createdAt,
        files: snapshot.manifest.files.length,
        bytes: snapshot.manifest.files.reduce((total, entry) => total + entry.size, 0),
        papers: remotePapers,
        pdfs: snapshot.manifest.files.filter((entry) => entry.path.startsWith('pdfs/')).length,
      },
      local: { papers: localPapers, pdfs: localPdfs },
    }
  }

  return { status, authorizationUrl, connect, disconnect, uploadSnapshot, restoreLatestSnapshot, getLatestBackupSummary, getRestorePreview }
}
