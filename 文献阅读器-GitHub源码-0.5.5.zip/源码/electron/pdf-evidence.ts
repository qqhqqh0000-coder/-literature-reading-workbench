/**
 * Locate a quoted PDF passage in the page text returned by the PDF extractor.
 *
 * The returned page number is 1-based. Matching is exact after normalizing
 * Unicode compatibility forms, case, whitespace, and discretionary hyphens at
 * PDF line endings. Each page is matched independently, so evidence can never
 * be assembled across a page boundary.
 */
export function findPdfEvidencePage(pageTexts: readonly string[], quote: string): number | null {
  const normalizedQuote = normalizePdfEvidence(quote)
  if (!normalizedQuote) return null

  for (let index = 0; index < pageTexts.length; index++) {
    const pageText = pageTexts[index]
    if (typeof pageText !== 'string') continue
    if (normalizePdfEvidence(pageText).includes(normalizedQuote)) return index + 1
  }

  return null
}

function normalizePdfEvidence(value: string): string {
  return value
    .normalize('NFKC')
    .toLocaleLowerCase('en-US')
    // A soft hyphen is discretionary even when the extractor omits its line break.
    .replace(/\u00ad/gu, '')
    // Join words split by a visible hyphen/dash at an extracted line ending.
    .replace(/([\p{L}\p{N}])[\u2010-\u2015-][ \t]*\r?\n[ \t]*([\p{L}\p{N}])/gu, '$1$2')
    // Some PDF extractors flatten line endings to spaces while retaining the hyphen.
    .replace(/([\p{L}\p{N}])[\u2010-\u2015-][ \t]+([\p{L}\p{N}])/gu, '$1$2')
    // Treat all remaining whitespace (including PDF line wrapping) consistently.
    .replace(/\s+/gu, ' ')
    .trim()
}
