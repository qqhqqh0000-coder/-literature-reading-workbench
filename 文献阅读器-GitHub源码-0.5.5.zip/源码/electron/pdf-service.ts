import { open, mkdir, readFile, unlink } from 'node:fs/promises'
import path from 'node:path'

const MAX_PDF_BYTES = 32 * 1024 * 1024
const MAX_BASE64_LENGTH = Math.ceil(MAX_PDF_BYTES / 3) * 4
const MAX_FILE_NAME_LENGTH = 110
const BASE64_PATTERN = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/

export type PdfServiceOptions = {
  pdfDir: string
  extractBetter: (buffer: Buffer) => Promise<unknown> | unknown
}

export type PdfServiceResponse = Record<string, unknown> & { ok: boolean; error?: string }

/**
 * Return a single safe PDF file name, or null when the input contains path
 * components or cannot be represented as a Windows file name.
 *
 * Protocol handlers should also require the returned name to equal the
 * decoded request name. That rejects non-canonical aliases (for example a
 * trailing dot) as well as path traversal attempts.
 */
export function normalizePdfFileName(raw: unknown): string | null {
  if (typeof raw !== 'string') return null
  const input = raw.trim()
  if (!input || /[\\/]/.test(input) || /[\u0000-\u001f\u007f]/.test(input)) return null

  let name = input.replace(/[:*?"<>|]/g, '_').replace(/[. ]+$/g, '')
  if (!name || name === '.' || name === '..') return null

  const hasPdfExtension = name.toLowerCase().endsWith('.pdf')
  let stem = hasPdfExtension ? name.slice(0, -4) : name
  const extension = hasPdfExtension ? name.slice(-4) : '.pdf'
  stem = stem.replace(/[. ]+$/g, '')
  if (!stem) stem = 'paper'

  if (/^(?:con|prn|aux|nul|conin\$|conout\$|com[1-9]|lpt[1-9])$/i.test(stem)) stem = '_' + stem

  const maxStemLength = MAX_FILE_NAME_LENGTH - extension.length
  stem = stem.slice(-maxStemLength)
  if (!stem || stem === '.' || stem === '..') return null
  return stem + extension
}

function responseError(error: string): PdfServiceResponse {
  return { ok: false, error }
}

function errorCode(error: unknown): string | undefined {
  if (typeof error === 'object' && error !== null && 'code' in error) {
    const code = (error as { code?: unknown }).code
    return typeof code === 'string' ? code : undefined
  }
  return undefined
}

function extractionFields(value: unknown): Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {}
}

function makeUniqueName(baseName: string, index: number): string {
  if (index === 1) return baseName
  const extension = baseName.slice(-4)
  const stem = baseName.slice(0, -4)
  const suffix = ' (' + index + ')'
  const maxStemLength = MAX_FILE_NAME_LENGTH - extension.length - suffix.length
  return stem.slice(-maxStemLength) + suffix + extension
}

function validatePdf(buffer: Buffer): string | null {
  if (buffer.length > MAX_PDF_BYTES) return 'PDF 文件超过约 32 MB 的导入上限。'
  if (buffer.length < 5 || buffer.toString('latin1', 0, 5) !== '%PDF-') return '这不是有效的 PDF 文件。'
  return null
}

export function createPdfService({ pdfDir, extractBetter }: PdfServiceOptions) {
  async function writeWithoutOverwrite(baseName: string, buffer: Buffer): Promise<{ name: string; filePath: string } | PdfServiceResponse> {
    try {
      await mkdir(pdfDir, { recursive: true })
    } catch {
      return responseError('无法创建本地文献目录，请检查磁盘空间和文件夹权限。')
    }

    for (let index = 1; index <= 10000; index += 1) {
      const name = makeUniqueName(baseName, index)
      const filePath = path.join(pdfDir, name)
      let handle: Awaited<ReturnType<typeof open>> | null = null
      try {
        handle = await open(filePath, 'wx')
      } catch (error) {
        if (errorCode(error) === 'EEXIST') continue
        return responseError('无法保存 PDF 到本地文献目录，请检查磁盘空间和文件夹权限。')
      }

      try {
        await handle.writeFile(buffer)
        await handle.close()
        handle = null
        return { name, filePath }
      } catch {
        if (handle) await handle.close().catch(() => undefined)
        await unlink(filePath).catch(() => undefined)
        return responseError('PDF 保存过程中发生错误，未能完成导入。')
      }
    }

    return responseError('无法为这份 PDF 生成不冲突的文件名，请整理文献目录后重试。')
  }

  async function importPdf(args: unknown): Promise<PdfServiceResponse> {
    const values = typeof args === 'object' && args !== null ? args as Record<string, unknown> : {}
    const base64 = typeof values.base64 === 'string' ? values.base64 : ''
    if (!base64) return responseError('PDF 文件内容为空，请重新选择文件。')
    if (base64.length > MAX_BASE64_LENGTH) return responseError('PDF 文件超过约 32 MB 的导入上限。')
    if (base64.length % 4 !== 0 || !BASE64_PATTERN.test(base64)) return responseError('PDF 文件数据格式无效，请重新选择文件。')

    const buffer = Buffer.from(base64, 'base64')
    const validationError = validatePdf(buffer)
    if (validationError) return responseError(validationError)

    const rawName = typeof values.name === 'string' && values.name.trim() ? values.name : 'paper.pdf'
    const baseName = normalizePdfFileName(rawName)
    if (!baseName) return responseError('PDF 文件名无效，请重新选择文件。')

    const created = await writeWithoutOverwrite(baseName, buffer)
    if ('ok' in created) return created

    try {
      const extraction = extractionFields(await extractBetter(buffer))
      return {
        ...extraction,
        ok: true,
        name: created.name,
        path: created.filePath,
        bytes: buffer.length,
      }
    } catch {
      try {
        await unlink(created.filePath)
        return responseError('PDF 文本抽取失败，已清理未完成的导入文件。请确认文件未损坏或加密后重试。')
      } catch (error) {
        if (errorCode(error) === 'ENOENT') return responseError('PDF 文本抽取失败，未留下导入文件。请确认文件未损坏或加密后重试。')
        return responseError('PDF 文本抽取失败，且未能清理导入文件。请检查本地文献目录后重试。')
      }
    }
  }

  async function reextract(name: unknown): Promise<PdfServiceResponse> {
    if (typeof name !== 'string') return responseError('文献 PDF 文件名无效。')
    const safeName = normalizePdfFileName(name)
    if (!safeName || safeName !== name) return responseError('文献 PDF 文件名无效，已拒绝访问该路径。')

    const filePath = path.join(pdfDir, safeName)
    let buffer: Buffer
    try {
      buffer = await readFile(filePath)
    } catch (error) {
      return errorCode(error) === 'ENOENT'
        ? responseError('找不到这篇文献的 PDF 文件，请重新导入。')
        : responseError('无法读取这篇文献的 PDF 文件，请检查本地文献目录。')
    }

    const validationError = validatePdf(buffer)
    if (validationError) return responseError(validationError)

    try {
      const extraction = extractionFields(await extractBetter(buffer))
      return {
        ...extraction,
        ok: true,
        name: safeName,
        path: filePath,
        bytes: buffer.length,
      }
    } catch {
      return responseError('PDF 文本抽取失败，请确认文件未损坏或加密后重试。')
    }
  }

  return { import: importPdf, reextract }
}
