import { createHash, randomUUID } from 'node:crypto'
import { createReadStream } from 'node:fs'
import { copyFile, lstat, mkdir, open, readFile, readdir, rename, rm } from 'node:fs/promises'
import path from 'node:path'

type JsonRecord = Record<string, unknown>

interface SnapshotFile {
  path: string
  size: number
  sha256: string
}

interface SnapshotManifest {
  format: 1
  id: string
  createdAt: string
  papers: number
  pdfs: number
  bytes: number
  files: SnapshotFile[]
}

export interface LocalSnapshotSummary {
  id: string
  createdAt: string
  papers: number
  pdfs: number
  files: number
  bytes: number
  valid: boolean
  error?: string
}

export interface LocalSnapshotProgress {
  phase: 'copying' | 'complete'
  completedFiles: number
  totalFiles: number
  completedBytes: number
  totalBytes: number
}

export interface LocalRecoveryServiceOptions {
  dataDir: string
  pdfDir: string
  dataFile: string
  /** Use storage.runExclusive so snapshots and directory swaps cannot race autosave or trash mutations. */
  runExclusive?: <T>(operation: () => Promise<T>) => Promise<T>
}

export interface RestoreSnapshotResult {
  snapshotId: string
  papers: number
  pdfs: number
  files: number
  bytes: number
  rollbackSnapshotId?: string
  localRollbackDirectory: string
  warning?: string
}

const MAX_MANIFEST_BYTES = 16 * 1024 * 1024
const MAX_DATA_BYTES = 512 * 1024 * 1024
const MAX_SNAPSHOT_FILES = 100_000
const MAX_RETAINED_SNAPSHOTS = 10

const isRecord = (value: unknown): value is JsonRecord =>
  value !== null && typeof value === 'object' && !Array.isArray(value)

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function errorCode(error: unknown): string | undefined {
  if (!isRecord(error) || typeof error.code !== 'string') return undefined
  return error.code
}

function isContained(parent: string, child: string): boolean {
  const relative = path.relative(parent, child)
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative))
}

function isSafeSnapshotId(value: unknown): value is string {
  return typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,119}$/.test(value)
}

function isSafeFileName(value: string): boolean {
  return value.length > 0 && value !== '.' && value !== '..' &&
    !/[\\/:*?"<>|\u0000-\u001f\u007f]/.test(value) && path.basename(value) === value
}

function snapshotIdForNow(prefix: string, date: Date): string {
  const stamp = date.toISOString().replace(/[-:.]/g, '')
  return `${prefix}-${stamp}-${randomUUID().replace(/-/g, '')}`
}

function localDayStamp(date: Date): string {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

async function sha256File(filePath: string): Promise<string> {
  const hash = createHash('sha256')
  for await (const chunk of createReadStream(filePath)) hash.update(chunk as Buffer)
  return hash.digest('hex')
}

async function writeSyncedFile(filePath: string, contents: string): Promise<void> {
  const handle = await open(filePath, 'wx')
  try {
    await handle.writeFile(contents, 'utf8')
    await handle.sync()
  } finally {
    await handle.close()
  }
}

async function assertPlainDirectory(directoryPath: string, description: string, allowMissing = false): Promise<boolean> {
  try {
    const entry = await lstat(directoryPath)
    if (entry.isSymbolicLink() || !entry.isDirectory()) throw new Error(`${description}不是普通目录，已停止操作。`)
    return true
  } catch (error) {
    if (allowMissing && errorCode(error) === 'ENOENT') return false
    throw error
  }
}

async function copyTreeWithoutLinks(source: string, destination: string): Promise<void> {
  const sourceStat = await lstat(source)
  if (sourceStat.isSymbolicLink()) throw new Error(`发现符号链接，拒绝复制：${source}`)
  if (sourceStat.isDirectory()) {
    await mkdir(destination, { recursive: false })
    for (const entry of await readdir(source, { withFileTypes: true })) {
      if (!isSafeFileName(entry.name)) throw new Error(`目录中包含不安全的文件名，拒绝复制：${entry.name}`)
      await copyTreeWithoutLinks(path.join(source, entry.name), path.join(destination, entry.name))
    }
    return
  }
  if (!sourceStat.isFile()) throw new Error(`发现非普通文件，拒绝复制：${source}`)
  await copyFile(source, destination)
}

function parseManifest(value: unknown, expectedId: string): SnapshotManifest {
  if (!isRecord(value) || value.format !== 1 || value.id !== expectedId || typeof value.createdAt !== 'string' || !Number.isFinite(Date.parse(value.createdAt))) {
    throw new Error('本机快照清单格式无效。')
  }
  if (!Number.isSafeInteger(value.papers) || Number(value.papers) < 0 ||
      !Number.isSafeInteger(value.pdfs) || Number(value.pdfs) < 0 ||
      !Number.isSafeInteger(value.bytes) || Number(value.bytes) < 0 ||
      !Array.isArray(value.files) || value.files.length > MAX_SNAPSHOT_FILES) {
    throw new Error('本机快照清单中的数量信息无效。')
  }
  const seen = new Set<string>()
  const files: SnapshotFile[] = []
  let bytes = 0
  let pdfs = 0
  for (const item of value.files) {
    if (!isRecord(item) || typeof item.path !== 'string' || !Number.isSafeInteger(item.size) || Number(item.size) < 0 ||
        typeof item.sha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(item.sha256)) {
      throw new Error('本机快照清单包含无效文件记录。')
    }
    const itemPath = item.path
    const isData = itemPath === 'data.json'
    const isPdf = itemPath.startsWith('pdfs/') && isSafeFileName(itemPath.slice('pdfs/'.length))
    if ((!isData && !isPdf) || seen.has(itemPath)) throw new Error('本机快照包含不允许或重复的文件路径。')
    if (isData && Number(item.size) > MAX_DATA_BYTES) throw new Error('快照中的文献数据超过 512 MB。')
    seen.add(itemPath)
    bytes += Number(item.size)
    if (!Number.isSafeInteger(bytes)) throw new Error('本机快照总大小超出安全范围。')
    if (isPdf) pdfs += 1
    files.push({ path: itemPath, size: Number(item.size), sha256: item.sha256.toLowerCase() })
  }
  if (!seen.has('data.json') || pdfs !== value.pdfs || bytes !== value.bytes) throw new Error('本机快照文件清单与摘要不一致。')
  return {
    format: 1,
    id: expectedId,
    createdAt: value.createdAt,
    papers: Number(value.papers),
    pdfs,
    bytes,
    files,
  }
}

export function createLocalRecoveryService(options: LocalRecoveryServiceOptions) {
  const dataDir = path.resolve(options.dataDir)
  const pdfDir = path.resolve(options.pdfDir)
  const dataFile = path.resolve(options.dataFile)
  const recoveryDir = path.join(path.dirname(dataDir), `.${path.basename(dataDir)}-recovery`)
  const snapshotsDir = path.join(recoveryDir, 'snapshots')
  const dataRelative = path.relative(dataDir, dataFile)
  const pdfRelative = path.relative(dataDir, pdfDir)
  const enqueue = options.runExclusive || (<T>(operation: () => Promise<T>) => operation())

  if (!isContained(dataDir, dataFile) || dataRelative === '' || dataRelative.startsWith('..') || path.isAbsolute(dataRelative)) {
    throw new Error('dataFile 必须位于 dataDir 内。')
  }
  if (!isContained(dataDir, pdfDir) || pdfRelative === '' || pdfRelative.startsWith('..') || path.isAbsolute(pdfRelative)) {
    throw new Error('pdfDir 必须位于 dataDir 内。')
  }
  if (path.dirname(dataFile) !== dataDir || path.basename(dataFile) !== 'data.json' || pdfRelative !== 'pdfs') {
    throw new Error('本地恢复服务要求 data.json 与 pdfs 目录直接位于 dataDir 下。')
  }
  if (isContained(dataDir, recoveryDir) || isContained(recoveryDir, dataDir)) {
    throw new Error('本地恢复目录必须与 dataDir 位于同一父目录，不能互相包含。')
  }

  async function ensureRecoveryDirectories(): Promise<void> {
    await mkdir(path.dirname(dataDir), { recursive: true })
    await mkdir(recoveryDir, { recursive: true })
    await assertPlainDirectory(recoveryDir, '恢复根目录')
    await mkdir(snapshotsDir, { recursive: true })
    await assertPlainDirectory(snapshotsDir, '快照目录')
  }

  async function snapshotPath(snapshotId: string): Promise<string> {
    if (!isSafeSnapshotId(snapshotId)) throw new Error('快照编号无效，已拒绝访问该路径。')
    await ensureRecoveryDirectories()
    const destination = path.resolve(snapshotsDir, snapshotId)
    if (!isContained(snapshotsDir, destination) || destination === snapshotsDir) throw new Error('快照路径无效，已拒绝访问。')
    return destination
  }

  async function readSnapshotManifest(snapshotId: string): Promise<{ directory: string; manifest: SnapshotManifest }> {
    const directory = await snapshotPath(snapshotId)
    await assertPlainDirectory(directory, '快照目录')
    const manifestPath = path.join(directory, 'manifest.json')
    const manifestStat = await lstat(manifestPath)
    if (manifestStat.isSymbolicLink() || !manifestStat.isFile() || manifestStat.size > MAX_MANIFEST_BYTES) {
      throw new Error('本机快照清单文件无效。')
    }
    const text = await readFile(manifestPath, 'utf8')
    let value: unknown
    try {
      value = JSON.parse(text.replace(/^\uFEFF/, ''))
    } catch {
      throw new Error('本机快照清单不是有效 JSON。')
    }
    return { directory, manifest: parseManifest(value, snapshotId) }
  }

  async function buildSnapshot(
    snapshotId: string,
    createdAt: Date,
    onProgress?: (progress: LocalSnapshotProgress) => void,
  ): Promise<LocalSnapshotSummary> {
    if (!isSafeSnapshotId(snapshotId)) throw new Error('快照编号无效。')
    await ensureRecoveryDirectories()
    await assertPlainDirectory(dataDir, '本机数据目录')
    await assertPlainDirectory(pdfDir, 'PDF 目录', true)
    const destination = await snapshotPath(snapshotId)
    if (await assertPlainDirectory(destination, '本机快照目录', true)) {
      const existing = await readSnapshotManifest(snapshotId)
      return summaryOf(existing.manifest)
    }

    const temporary = path.join(snapshotsDir, `.tmp-${randomUUID()}`)
    await mkdir(temporary, { recursive: false })
    try {
      const dataStat = await lstat(dataFile)
      if (dataStat.isSymbolicLink() || !dataStat.isFile()) throw new Error('data.json 不是普通文件，未创建本机快照。')
      if (dataStat.size > MAX_DATA_BYTES) throw new Error('文献数据超过 512 MB，未创建本机快照。')
      const dataDestination = path.join(temporary, 'data.json')
      const files: SnapshotFile[] = []
      let pdfSources: Array<{ name: string; source: string; size: number }> = []
      if (await assertPlainDirectory(pdfDir, 'PDF 目录', true)) {
        for (const entry of await readdir(pdfDir, { withFileTypes: true })) {
          if (!isSafeFileName(entry.name)) throw new Error(`PDF 目录中包含不安全的文件名：${entry.name}`)
          const source = path.join(pdfDir, entry.name)
          const sourceStat = await lstat(source)
          if (sourceStat.isSymbolicLink() || !sourceStat.isFile()) throw new Error(`PDF 目录包含非普通文件，未创建快照：${entry.name}`)
          pdfSources.push({ name: entry.name, source, size: sourceStat.size })
          if (pdfSources.length + 1 > MAX_SNAPSHOT_FILES) throw new Error('本机文件数量超过快照限制。')
        }
      }
      const totalBytes = dataStat.size + pdfSources.reduce((sum, item) => sum + item.size, 0)
      if (!Number.isSafeInteger(totalBytes)) throw new Error('本机快照总大小超出安全范围。')
      let completedFiles = 0
      let completedBytes = 0
      const report = (phase: LocalSnapshotProgress['phase']) => {
        try { onProgress?.({ phase, completedFiles, totalFiles: pdfSources.length + 1, completedBytes, totalBytes }) } catch { /* UI progress must not interrupt recovery. */ }
      }
      report('copying')
      await copyFile(dataFile, dataDestination)
      const copiedDataStat = await lstat(dataDestination)
      if (!copiedDataStat.isFile() || copiedDataStat.size !== dataStat.size) throw new Error('创建快照时 data.json 发生变化，请稍后重试。')
      files.push({
        path: 'data.json',
        size: copiedDataStat.size,
        sha256: await sha256File(dataDestination),
      })
      completedFiles += 1
      completedBytes += copiedDataStat.size
      report('copying')
      const dataText = await readFile(dataDestination, 'utf8')
      let data: unknown
      try { data = JSON.parse(dataText.replace(/^\uFEFF/, '')) } catch { throw new Error('本机 data.json 已损坏，未创建快照。') }
      if (!isRecord(data) || !Array.isArray(data.papers)) throw new Error('本机 data.json 结构不正确，未创建快照。')
      let pdfCount = 0
      try {
        await mkdir(path.join(temporary, 'pdfs'), { recursive: false })
      } catch (error) {
        if (errorCode(error) !== 'EEXIST') throw error
      }
      for (const item of pdfSources) {
        const target = path.join(temporary, 'pdfs', item.name)
        await copyFile(item.source, target)
        const copiedStat = await lstat(target)
        if (!copiedStat.isFile() || copiedStat.size !== item.size) throw new Error(`创建快照时 PDF 发生变化，请稍后重试：${item.name}`)
        files.push({ path: `pdfs/${item.name}`, size: copiedStat.size, sha256: await sha256File(target) })
        pdfCount += 1
        completedFiles += 1
        completedBytes += copiedStat.size
        report('copying')
      }
      const bytes = files.reduce((total, file) => total + file.size, 0)
      if (!Number.isSafeInteger(bytes)) throw new Error('本机快照总大小超出安全范围。')
      const manifest: SnapshotManifest = {
        format: 1,
        id: snapshotId,
        createdAt: createdAt.toISOString(),
        papers: data.papers.length,
        pdfs: pdfCount,
        bytes,
        files,
      }
      await writeSyncedFile(path.join(temporary, 'manifest.json'), JSON.stringify(manifest, null, 2))
      await rename(temporary, destination)
      report('complete')
      return summaryOf(manifest)
    } catch (error) {
      await rm(temporary, { recursive: true, force: true }).catch(() => undefined)
      throw error
    }
  }

  function summaryOf(manifest: SnapshotManifest): LocalSnapshotSummary {
    return {
      id: manifest.id,
      createdAt: manifest.createdAt,
      papers: manifest.papers,
      pdfs: manifest.pdfs,
      files: manifest.files.length,
      bytes: manifest.bytes,
      valid: true,
    }
  }

  async function pruneSnapshots(): Promise<void> {
    const entries = await readdir(snapshotsDir, { withFileTypes: true })
    const snapshots: Array<{ id: string; createdAt: number }> = []
    for (const entry of entries) {
      if (!entry.isDirectory() || !isSafeSnapshotId(entry.name)) continue
      try {
        const { manifest } = await readSnapshotManifest(entry.name)
        snapshots.push({ id: entry.name, createdAt: Date.parse(manifest.createdAt) })
      } catch {
        // Keep unrecognized/corrupt data for manual inspection; never delete it automatically.
      }
    }
    snapshots.sort((a, b) => b.createdAt - a.createdAt || b.id.localeCompare(a.id))
    for (const item of snapshots.slice(MAX_RETAINED_SNAPSHOTS)) {
      const target = path.resolve(snapshotsDir, item.id)
      if (!isContained(snapshotsDir, target) || target === snapshotsDir) continue
      if (!(await assertPlainDirectory(target, '待清理快照目录', true))) continue
      await rm(target, { recursive: true, force: false })
    }
  }

  async function createDailySnapshotInternal(onProgress?: (progress: LocalSnapshotProgress) => void): Promise<LocalSnapshotSummary> {
    const now = new Date()
    const id = `daily-${localDayStamp(now)}`
    const result = await buildSnapshot(id, now, onProgress)
    await pruneSnapshots()
    return result
  }

  async function createDailySnapshot(onProgress?: (progress: LocalSnapshotProgress) => void): Promise<LocalSnapshotSummary> {
    return enqueue(() => createDailySnapshotInternal(onProgress))
  }

  async function listSnapshots(): Promise<LocalSnapshotSummary[]> {
    return enqueue(async () => {
      await ensureRecoveryDirectories()
      const entries = await readdir(snapshotsDir, { withFileTypes: true })
      const results: LocalSnapshotSummary[] = []
      for (const entry of entries) {
        if (!entry.isDirectory() || !isSafeSnapshotId(entry.name)) continue
        try {
          const { manifest } = await readSnapshotManifest(entry.name)
          results.push(summaryOf(manifest))
        } catch (error) {
          results.push({ id: entry.name, createdAt: '', papers: 0, pdfs: 0, files: 0, bytes: 0, valid: false, error: messageOf(error) })
        }
      }
      return results.sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id))
    })
  }

  async function verifySnapshot(directory: string, manifest: SnapshotManifest, allowPreservedEntries = false): Promise<void> {
    const rootEntries = await readdir(directory, { withFileTypes: true })
    const rootNames = new Set(rootEntries.map((entry) => entry.name))
    if (!rootNames.has('data.json') || !rootNames.has('pdfs') ||
        (!allowPreservedEntries && (rootNames.size !== 3 || !rootNames.has('manifest.json')))) {
      throw new Error('快照目录结构与清单不一致，已拒绝恢复。')
    }
    for (const file of manifest.files) {
      const target = path.resolve(directory, ...file.path.split('/'))
      if (!isContained(directory, target) || target === directory) throw new Error('快照文件路径无效，已拒绝恢复。')
      const fileStat = await lstat(target)
      if (fileStat.isSymbolicLink() || !fileStat.isFile() || fileStat.size !== file.size) throw new Error(`快照文件缺失或大小不一致：${file.path}`)
      if (await sha256File(target) !== file.sha256) throw new Error(`快照文件校验失败：${file.path}`)
    }
    const pdfDirectory = path.join(directory, 'pdfs')
    await assertPlainDirectory(pdfDirectory, '快照 PDF 目录')
    const pdfEntries = await readdir(pdfDirectory, { withFileTypes: true })
    const expectedPdfs = new Set(manifest.files.filter((item) => item.path.startsWith('pdfs/')).map((item) => item.path.slice('pdfs/'.length)))
    if (pdfEntries.length !== expectedPdfs.size || pdfEntries.some((entry) => !expectedPdfs.has(entry.name) || !entry.isFile())) {
      throw new Error('快照 PDF 目录与清单不一致，已拒绝恢复。')
    }
    const dataText = await readFile(path.join(directory, 'data.json'), 'utf8')
    let data: unknown
    try { data = JSON.parse(dataText.replace(/^\uFEFF/, '')) } catch { throw new Error('快照 data.json 无法解析，已拒绝恢复。') }
    if (!isRecord(data) || !Array.isArray(data.papers) || data.papers.length !== manifest.papers) throw new Error('快照文献数据与摘要不一致，已拒绝恢复。')
  }

  async function copyActiveExtrasToStage(stage: string): Promise<void> {
    if (!(await assertPlainDirectory(dataDir, '本机数据目录', true))) return
    const excluded = new Set([dataRelative, pdfRelative])
    for (const entry of await readdir(dataDir, { withFileTypes: true })) {
      if (excluded.has(entry.name)) continue
      if (!isSafeFileName(entry.name)) throw new Error(`本机数据目录包含不安全的文件名：${entry.name}`)
      await copyTreeWithoutLinks(path.join(dataDir, entry.name), path.join(stage, entry.name))
    }
  }

  async function restoreSnapshotInternal(snapshotId: string): Promise<RestoreSnapshotResult> {
    const { directory, manifest } = await readSnapshotManifest(snapshotId)
    await verifySnapshot(directory, manifest)
    await mkdir(path.dirname(dataDir), { recursive: true })

    let rollbackSnapshotId = snapshotIdForNow('before-restore', new Date())
    let rollbackSnapshotError = ''
    try {
      await buildSnapshot(rollbackSnapshotId, new Date())
    } catch (error) {
      rollbackSnapshotError = messageOf(error)
      rollbackSnapshotId = ''
    }
    const stage = path.join(path.dirname(dataDir), `.${path.basename(dataDir)}-restore-${randomUUID()}`)
    const displaced = path.join(path.dirname(dataDir), `.${path.basename(dataDir)}-displaced-${randomUUID()}`)
    await mkdir(stage, { recursive: false })
    let displacedActiveData = false
    try {
      await copyActiveExtrasToStage(stage)
      const stagedDataFile = path.join(stage, dataRelative)
      await mkdir(path.dirname(stagedDataFile), { recursive: true })
      await copyFile(path.join(directory, 'data.json'), stagedDataFile)

      const stagedPdfDir = path.join(stage, pdfRelative)
      await mkdir(stagedPdfDir, { recursive: true })
      for (const file of manifest.files) {
        if (!file.path.startsWith('pdfs/')) continue
        const name = file.path.slice('pdfs/'.length)
        await copyFile(path.join(directory, 'pdfs', name), path.join(stagedPdfDir, name))
      }
      await verifySnapshot(stage, manifest, true)

      if (await assertPlainDirectory(dataDir, '本机数据目录', true)) {
        await rename(dataDir, displaced)
        displacedActiveData = true
      }
      try {
        await rename(stage, dataDir)
      } catch (error) {
        if (displacedActiveData) {
          try {
            await rename(displaced, dataDir)
            displacedActiveData = false
          } catch (rollbackError) {
            throw new Error(`快照未能替换本机数据，原数据仍保存在 ${displaced}；自动回滚失败：${messageOf(rollbackError)}`)
          }
        }
        throw error
      }

      let warning: string | undefined
      if (displacedActiveData) {
        if (rollbackSnapshotError) {
          warning = `当前数据无法生成有效快照（${rollbackSnapshotError}）；恢复前的完整目录保留在 ${displaced}。`
        } else {
          try {
            await rm(displaced, { recursive: true, force: false })
            displacedActiveData = false
          } catch (error) {
            warning = `恢复已完成，但旧数据目录仍保存在 ${displaced}，可在确认新数据正常后手动清理。原因：${messageOf(error)}`
          }
        }
      }
      try {
        await pruneSnapshots()
      } catch (error) {
        warning = [warning, `恢复已完成，但旧快照清理未完成：${messageOf(error)}`].filter(Boolean).join(' ')
      }
      return {
        snapshotId,
        papers: manifest.papers,
        pdfs: manifest.pdfs,
        files: manifest.files.length,
        bytes: manifest.bytes,
        ...(rollbackSnapshotId ? { rollbackSnapshotId } : {}),
        localRollbackDirectory: displacedActiveData ? displaced : '',
        ...(warning ? { warning } : {}),
      }
    } catch (error) {
      await rm(stage, { recursive: true, force: true }).catch(() => undefined)
      if (displacedActiveData) {
        try {
          await rename(displaced, dataDir)
        } catch (rollbackError) {
          throw new Error(`快照恢复失败（${messageOf(error)}），原数据仍在 ${displaced}；自动回滚失败（${messageOf(rollbackError)}）。`)
        }
      }
      throw error
    }
  }

  async function restoreSnapshot(snapshotId: string): Promise<RestoreSnapshotResult> {
    if (!isSafeSnapshotId(snapshotId)) throw new Error('快照编号无效，已拒绝恢复。')
    return enqueue(() => restoreSnapshotInternal(snapshotId))
  }

  return { createDailySnapshot, listSnapshots, restoreSnapshot }
}
