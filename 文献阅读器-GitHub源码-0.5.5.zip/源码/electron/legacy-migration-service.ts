import { lstat, mkdir, open, readFile, realpath, unlink } from 'node:fs/promises'
import path from 'node:path'
import { pipeline } from 'node:stream/promises'
import { normalizePdfFileName } from './pdf-service.js'

type JsonRecord = Record<string, unknown>
type SaveResult = { ok: boolean; error?: string; path?: string }

export interface LegacyMigrationServiceOptions {
  dataFile: string
  pdfDir: string
  save: (text: string) => Promise<SaveResult> | SaveResult
}

export type LegacyMigrationResult =
  | { ok: true; papersImported: number; pdfsCopied: number; pdfsMissing: number; path: string }
  | { ok: false; error: string }

const isRecord = (value: unknown): value is JsonRecord =>
  value !== null && typeof value === 'object' && !Array.isArray(value)

function errorCode(error: unknown): string | undefined {
  if (!isRecord(error) || typeof error.code !== 'string') return undefined
  return error.code
}

function samePath(left: string, right: string): boolean {
  const leftPath = path.resolve(left)
  const rightPath = path.resolve(right)
  return process.platform === 'win32'
    ? leftPath.toLocaleLowerCase('en-US') === rightPath.toLocaleLowerCase('en-US')
    : leftPath === rightPath
}

async function sameRealFile(left: string, right: string): Promise<boolean> {
  if (samePath(left, right)) return true
  try {
    const [leftReal, rightReal] = await Promise.all([realpath(left), realpath(right)])
    return samePath(leftReal, rightReal)
  } catch {
    return false
  }
}

function fileLeaf(value: string): string | null {
  let pathLike = value.trim()
  if (!pathLike) return null
  try {
    if (/^(?:litpdf:|file:)/i.test(pathLike)) pathLike = new URL(pathLike).pathname
  } catch {
    // Treat malformed URL-like paths as ordinary paths and only use their final component.
  }
  const leaf = pathLike.split(/[\\/]/).pop() || ''
  if (!leaf) return null
  let decoded = leaf
  try { decoded = decodeURIComponent(leaf) } catch { /* Keep a literal percent sign in ordinary file names. */ }
  return normalizePdfFileName(decoded)
}

function pdfCandidates(reference: JsonRecord): string[] {
  const candidates: string[] = []
  for (const field of ['name', 'path']) {
    const value = reference[field]
    if (typeof value !== 'string') continue
    const candidate = fileLeaf(value)
    if (candidate && !candidates.includes(candidate)) candidates.push(candidate)
  }
  return candidates
}

function uniqueName(baseName: string, index: number): string {
  if (index === 1) return baseName
  const extension = baseName.slice(-4)
  const stem = baseName.slice(0, -4)
  const suffix = ' (' + index + ')'
  const maxStemLength = 110 - extension.length - suffix.length
  const normalizedStem = stem.slice(-maxStemLength)
  return normalizePdfFileName(normalizedStem + suffix + extension) || baseName
}

async function cleanupFiles(filePaths: string[]): Promise<boolean> {
  const outcomes = await Promise.all(filePaths.map(async (filePath) => {
    try {
      await unlink(filePath)
      return true
    } catch (error) {
      return errorCode(error) === 'ENOENT'
    }
  }))
  return outcomes.every(Boolean)
}

export function createLegacyMigrationService({ dataFile, pdfDir, save }: LegacyMigrationServiceOptions) {
  async function findSourcePdf(sourcePdfDir: string, candidates: string[]): Promise<{ name: string; path: string } | null> {
    for (const name of candidates) {
      const sourcePath = path.join(sourcePdfDir, name)
      try {
        const details = await lstat(sourcePath)
        if (details.isFile()) return { name, path: sourcePath }
      } catch (error) {
        if (errorCode(error) === 'ENOENT' || errorCode(error) === 'ENOTDIR') continue
        throw error
      }
    }
    return null
  }

  async function copyWithoutOverwrite(sourcePath: string, baseName: string): Promise<{ name: string; path: string } | null> {
    for (let index = 1; index <= 10000; index += 1) {
      const name = uniqueName(baseName, index)
      const destinationPath = path.join(pdfDir, name)
      let sourceHandle: Awaited<ReturnType<typeof open>>
      try {
        sourceHandle = await open(sourcePath, 'r')
      } catch (error) {
        if (errorCode(error) === 'ENOENT' || errorCode(error) === 'ENOTDIR') {
          return null
        }
        throw new Error('复制旧 PDF 失败，请检查源文件和本地文献目录。')
      }

      let destinationHandle: Awaited<ReturnType<typeof open>>
      try {
        destinationHandle = await open(destinationPath, 'wx')
      } catch (error) {
        await sourceHandle.close().catch(() => undefined)
        if (errorCode(error) === 'EEXIST') continue
        throw new Error('无法在桌面版 PDF 目录中创建文件，请检查磁盘空间和文件夹权限。')
      }

      try {
        await pipeline(
          sourceHandle.createReadStream({ autoClose: false }),
          destinationHandle.createWriteStream({ autoClose: false }),
        )
        await destinationHandle.sync()
        await Promise.all([sourceHandle.close(), destinationHandle.close()])
        return { name, path: destinationPath }
      } catch {
        await Promise.all([
          sourceHandle.close().catch(() => undefined),
          destinationHandle.close().catch(() => undefined),
        ])
        await unlink(destinationPath).catch(() => undefined)
        throw new Error('复制旧 PDF 失败，请检查源文件和本地文献目录。')
      }
    }
    throw new Error('无法为旧 PDF 生成不冲突的文件名，请整理本地文献目录后重试。')
  }

  async function importFrom(sourceDataFilePath: string): Promise<LegacyMigrationResult> {
    if (typeof sourceDataFilePath !== 'string' || !sourceDataFilePath.trim() || /[\u0000-\u001f]/.test(sourceDataFilePath)) {
      return { ok: false, error: '旧数据文件路径无效。' }
    }
    if (await sameRealFile(sourceDataFilePath, dataFile)) {
      return { ok: false, error: '所选文件已经是当前桌面版的数据文件，无需再次导入。' }
    }

    let text: string
    try {
      text = await readFile(sourceDataFilePath, 'utf8')
    } catch {
      return { ok: false, error: '无法读取所选旧数据文件，请确认文件存在且可访问。' }
    }

    let data: unknown
    try {
      data = JSON.parse(text.replace(/^\uFEFF/, ''))
    } catch {
      return { ok: false, error: '旧数据文件不是有效的 JSON，未导入任何内容。' }
    }
    if (!isRecord(data)) return { ok: false, error: '旧数据文件的顶层内容必须是 JSON 对象。' }
    if (!Array.isArray(data.papers)) return { ok: false, error: '旧数据文件缺少有效的 papers 文献列表。' }
    for (let index = 0; index < data.papers.length; index += 1) {
      if (!isRecord(data.papers[index])) {
        return { ok: false, error: '旧数据文件中的第 ' + (index + 1) + ' 篇文献不是对象，未导入任何内容。' }
      }
    }

    const sourcePdfDir = path.join(path.dirname(path.resolve(sourceDataFilePath)), 'pdfs')
    const copiedFiles: string[] = []
    const copiedBySource = new Map<string, { name: string; path: string }>()
    let pdfsMissing = 0

    try {
      await mkdir(pdfDir, { recursive: true })
    } catch {
      return { ok: false, error: '无法创建桌面版 PDF 目录，请检查磁盘空间和文件夹权限。' }
    }

    for (const value of data.papers) {
      const paper = value as JsonRecord
      const referenceValue = paper.pdf
      if (referenceValue === undefined || referenceValue === null) continue
      if (!isRecord(referenceValue)) {
        paper.pdf = null
        pdfsMissing += 1
        continue
      }

      const candidates = pdfCandidates(referenceValue)
      let source: { name: string; path: string } | null
      try {
        source = await findSourcePdf(sourcePdfDir, candidates)
      } catch {
        const cleaned = await cleanupFiles(copiedFiles)
        return {
          ok: false,
          error: cleaned
            ? '无法检查旧 PDF 目录，请确认文件夹权限后重试。'
            : '无法检查旧 PDF 目录，且本次已复制文件未能全部清理，请检查桌面版 PDF 目录。',
        }
      }
      if (!source) {
        paper.pdf = { ...referenceValue, name: '', path: '' }
        pdfsMissing += 1
        continue
      }

      const sourceKey = process.platform === 'win32'
        ? path.resolve(source.path).toLocaleLowerCase('en-US')
        : path.resolve(source.path)
      let destination = copiedBySource.get(sourceKey)
      if (!destination) {
        try {
          destination = await copyWithoutOverwrite(source.path, source.name) || undefined
        } catch (error) {
          const cleaned = await cleanupFiles(copiedFiles)
          const detail = error instanceof Error ? error.message : '复制 PDF 时发生未知错误。'
          return {
            ok: false,
            error: cleaned ? detail : detail + ' 本次已复制文件未能全部清理，请检查桌面版 PDF 目录。',
          }
        }
        if (!destination) {
          paper.pdf = { ...referenceValue, name: '', path: '' }
          pdfsMissing += 1
          continue
        }
        copiedBySource.set(sourceKey, destination)
        copiedFiles.push(destination.path)
      }

      paper.pdf = { ...referenceValue, name: destination.name, path: destination.path }
    }

    const saveText = JSON.stringify(data, null, 2)
    try {
      const result = await save(saveText)
      if (result && result.ok === true) {
        return {
          ok: true,
          papersImported: data.papers.length,
          pdfsCopied: copiedFiles.length,
          pdfsMissing,
          path: typeof result.path === 'string' ? result.path : dataFile,
        }
      }
      const cleaned = await cleanupFiles(copiedFiles)
      const reason = result && typeof result.error === 'string' ? result.error : '文献数据保存失败。'
      return {
        ok: false,
        error: cleaned ? '导入失败：' + reason : '导入失败：' + reason + ' 本次已复制 PDF 未能全部清理，请检查桌面版 PDF 目录。',
      }
    } catch (error) {
      const cleaned = await cleanupFiles(copiedFiles)
      const reason = error instanceof Error ? error.message : '文献数据保存失败。'
      return {
        ok: false,
        error: cleaned ? '导入失败：' + reason : '导入失败：' + reason + ' 本次已复制 PDF 未能全部清理，请检查桌面版 PDF 目录。',
      }
    }
  }

  return { importFrom }
}
