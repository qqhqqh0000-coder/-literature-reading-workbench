import { randomUUID } from 'node:crypto'
import { constants as fsConstants } from 'node:fs'
import { copyFile, lstat, mkdir, open, readFile, rename, unlink } from 'node:fs/promises'
import path from 'node:path'

export interface StorageServiceOptions {
  dataDir: string
  pdfDir: string
  dataFile: string
}

type StorageResult =
  | { ok: true; exists: true; text: string; path: string }
  | { ok: true; path: string }
  | { ok: false; error: string }

type JsonRecord = Record<string, unknown>

export interface TrashedPaper {
  paperId: string
  deletedAt: number
  paper: JsonRecord
}

export type TrashResult =
  | { ok: true; path: string; records?: TrashedPaper[]; paper?: JsonRecord; text?: string; warning?: string }
  | { ok: false; error: string }

const isRecord = (value: unknown): value is JsonRecord =>
  value !== null && typeof value === 'object' && !Array.isArray(value)

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function errorCode(error: unknown): string | undefined {
  if (!isRecord(error) || typeof error.code !== 'string') return undefined
  return error.code
}

function emptyData(): string {
  return JSON.stringify({
    version: 4,
    updatedAt: Date.now(),
    papers: [],
    drafts: [],
    ui: {},
  }, null, 2)
}

function validatePaper(value: unknown, index: number): string | null {
  if (!isRecord(value)) return `papers[${index}] 必须是对象。`
  if (value.id !== undefined && typeof value.id !== 'string') return `papers[${index}].id 必须是字符串。`
  if (value.pdf !== undefined && value.pdf !== null && !isRecord(value.pdf)) return `papers[${index}].pdf 必须是对象或 null。`
  if (value.translation !== undefined) {
    if (!isRecord(value.translation)) return `papers[${index}].translation 必须是对象。`
    for (const field of ['segments', 'picked', 'batch']) {
      if (value.translation[field] !== undefined && !Array.isArray(value.translation[field])) {
        return `papers[${index}].translation.${field} 必须是数组。`
      }
    }
  }
  if (value.progress !== undefined && !isRecord(value.progress)) return `papers[${index}].progress 必须是对象。`
  if (value.mindmaps !== undefined && !Array.isArray(value.mindmaps)) return `papers[${index}].mindmaps 必须是数组。`
  return null
}

function validateDraft(value: unknown, index: number): string | null {
  return isRecord(value) ? null : `drafts[${index}] 必须是对象。`
}

function validateData(text: string): string | null {
  let value: unknown
  try {
    value = JSON.parse(text.replace(/^\uFEFF/, ''))
  } catch (error) {
    return `拒绝保存：内容不是有效 JSON（${errorMessage(error)}）。`
  }

  if (!isRecord(value)) return '拒绝保存：文献数据顶层必须是 JSON 对象。'
  if (!Array.isArray(value.papers)) return '拒绝保存：papers 必须是数组。'
  if (value.drafts !== undefined && !Array.isArray(value.drafts)) return '拒绝保存：drafts 必须是数组。'
  if (value.ui !== undefined && !isRecord(value.ui)) return '拒绝保存：ui 必须是对象。'
  if (value.version !== undefined && (!Number.isInteger(value.version) || Number(value.version) < 1)) {
    return '拒绝保存：version 必须是正整数。'
  }
  if (value.updatedAt !== undefined && (typeof value.updatedAt !== 'number' || !Number.isFinite(value.updatedAt))) {
    return '拒绝保存：updatedAt 必须是有限数字。'
  }

  for (let index = 0; index < value.papers.length; index++) {
    const issue = validatePaper(value.papers[index], index)
    if (issue) return `拒绝保存：${issue}`
  }
  if (Array.isArray(value.drafts)) {
    for (let index = 0; index < value.drafts.length; index++) {
      const issue = validateDraft(value.drafts[index], index)
      if (issue) return `拒绝保存：${issue}`
    }
  }
  return null
}

async function writeSyncedFile(filePath: string, contents: string): Promise<void> {
  const handle = await open(filePath, 'wx')
  try {
    await handle.writeFile(contents, 'utf8')
    await handle.sync()
  } finally {
    await handle.close()
  }
}

async function removeIfPresent(filePath: string): Promise<void> {
  try {
    await unlink(filePath)
  } catch (error) {
    if (errorCode(error) !== 'ENOENT') throw error
  }
}

export function createStorageService({ dataDir, pdfDir, dataFile }: StorageServiceOptions) {
  const backupFile = `${dataFile}.bak`
  const trashFile = path.join(dataDir, 'trash.json')

  async function ensureDirectories(): Promise<void> {
    await Promise.all([
      mkdir(dataDir, { recursive: true }),
      mkdir(pdfDir, { recursive: true }),
      mkdir(path.dirname(dataFile), { recursive: true }),
    ])
  }

  async function ensure(): Promise<void> {
    await ensureDirectories()
    try {
      await readFile(dataFile, 'utf8')
      return
    } catch (error) {
      if (errorCode(error) !== 'ENOENT') throw error
    }

    // wx makes first-run initialization safe when two app instances race to create the file.
    let handle
    try {
      handle = await open(dataFile, 'wx')
    } catch (error) {
      if (errorCode(error) === 'EEXIST') return
      throw error
    }

    try {
      await handle.writeFile(emptyData(), 'utf8')
      await handle.sync()
    } catch (error) {
      await handle.close()
      await removeIfPresent(dataFile)
      throw error
    }
    await handle.close()
  }

  async function load(): Promise<StorageResult> {
    try {
      await ensure()
      // Do not parse or normalize here: the renderer must see corrupt text and pause autosave.
      const text = await readFile(dataFile, 'utf8')
      return { ok: true, exists: true, text, path: dataFile }
    } catch (error) {
      return { ok: false, error: errorMessage(error) }
    }
  }

  async function saveOnce(text: string): Promise<StorageResult> {
    const validationError = validateData(text)
    if (validationError) return { ok: false, error: validationError }

    const tempFile = `${dataFile}.${randomUUID()}.tmp`
    const backupTemp = `${backupFile}.${randomUUID()}.tmp`
    try {
      await ensureDirectories()
      await writeSyncedFile(tempFile, text)

      let hasPreviousFile = true
      try {
        await lstat(dataFile)
      } catch (error) {
        if (errorCode(error) === 'ENOENT') hasPreviousFile = false
        else throw error
      }

      if (hasPreviousFile) {
        // Require a complete backup before replacing the current data file.
        await copyFile(dataFile, backupTemp, fsConstants.COPYFILE_EXCL)
        await rename(backupTemp, backupFile)
      }

      await rename(tempFile, dataFile)
      return { ok: true, path: dataFile }
    } catch (error) {
      return { ok: false, error: errorMessage(error) }
    } finally {
      await Promise.all([
        removeIfPresent(tempFile).catch(() => undefined),
        removeIfPresent(backupTemp).catch(() => undefined),
      ])
    }
  }

  // Serialize saves, trash mutations, and directory swaps through one queue.
  let operationQueue: Promise<void> = Promise.resolve()
  function runExclusive<T>(operation: () => Promise<T>): Promise<T> {
    const result = operationQueue.then(operation)
    operationQueue = result.then(() => undefined, () => undefined)
    return result
  }

  function save(text: string): Promise<StorageResult> {
    return runExclusive(() => saveOnce(text))
  }

  function validPaperId(value: unknown): value is string {
    return typeof value === 'string' && value.trim().length > 0 && value.length <= 256 && !/[\u0000-\u001f\u007f]/.test(value)
  }

  async function readTrash(): Promise<{ records: TrashedPaper[] }> {
    try {
      const trashStat = await lstat(trashFile)
      if (trashStat.isSymbolicLink() || !trashStat.isFile()) throw new Error('回收站文件不是普通文件，已停止访问。')
      const text = await readFile(trashFile, 'utf8')
      let value: unknown
      try {
        value = JSON.parse(text.replace(/^\uFEFF/, ''))
      } catch {
        throw new Error('回收站数据损坏，已停止修改以免覆盖其中的文献。')
      }
      if (!Array.isArray(value)) throw new Error('回收站数据格式无效，已停止修改以免丢失文献。')
      const records: TrashedPaper[] = []
      for (const [index, item] of value.entries()) {
        if (!isRecord(item) || !validPaperId(item.paperId) || typeof item.deletedAt !== 'number' || !Number.isFinite(item.deletedAt) || !isRecord(item.paper) || item.paper.id !== item.paperId) {
          throw new Error(`回收站第 ${index + 1} 条记录格式无效，已停止修改。`)
        }
        records.push({ paperId: item.paperId, deletedAt: item.deletedAt, paper: item.paper })
      }
      return { records }
    } catch (error) {
      if (errorCode(error) === 'ENOENT') return { records: [] }
      throw error
    }
  }

  async function writeTrash(records: TrashedPaper[]): Promise<void> {
    await ensureDirectories()
    if (records.length === 0) {
      await removeIfPresent(trashFile)
      return
    }
    try {
      const existing = await lstat(trashFile)
      if (existing.isSymbolicLink() || !existing.isFile()) throw new Error('回收站文件不是普通文件，已停止修改。')
    } catch (error) {
      if (errorCode(error) !== 'ENOENT') throw error
    }
    const tempFile = `${trashFile}.${randomUUID()}.tmp`
    try {
      await writeSyncedFile(tempFile, JSON.stringify(records, null, 2))
      await rename(tempFile, trashFile)
    } finally {
      await removeIfPresent(tempFile).catch(() => undefined)
    }
  }

  async function readValidatedData(): Promise<{ text: string; data: JsonRecord; papers: JsonRecord[] }> {
    await ensure()
    const text = await readFile(dataFile, 'utf8')
    const validationError = validateData(text)
    if (validationError) throw new Error(validationError)
    const data = JSON.parse(text.replace(/^\uFEFF/, '')) as JsonRecord
    return { text, data, papers: data.papers as JsonRecord[] }
  }

  async function listTrash(): Promise<TrashResult> {
    return runExclusive(async () => {
      try {
        const { records } = await readTrash()
        return { ok: true, path: trashFile, records }
      } catch (error) {
        return { ok: false, error: errorMessage(error) }
      }
    })
  }

  async function movePaperToTrash(paperId: string): Promise<TrashResult> {
    return runExclusive(async () => {
      try {
        if (!validPaperId(paperId)) throw new Error('文献编号无效，未修改本机数据。')
        const current = await readValidatedData()
        const matchingIndexes = current.papers.map((paper, index) => paper.id === paperId ? index : -1).filter((index) => index >= 0)
        if (matchingIndexes.length !== 1) throw new Error(matchingIndexes.length ? '文献编号重复，已停止移入回收站。' : '找不到要移入回收站的文献。')
        const trash = await readTrash()
        if (trash.records.some((item) => item.paperId === paperId)) throw new Error('回收站中已有这篇文献，请先处理已有记录。')

        const paper = current.papers[matchingIndexes[0]]
        const records = trash.records.concat([{ paperId, deletedAt: Date.now(), paper }])
        // Store a recoverable copy first. If updating data.json fails, revert the trash write.
        await writeTrash(records)
        const nextData = { ...current.data, papers: current.papers.filter((_, index) => index !== matchingIndexes[0]) }
        const nextText = JSON.stringify(nextData, null, 2)
        const saved = await saveOnce(nextText)
        if (!saved.ok) {
          try {
            await writeTrash(trash.records)
          } catch (rollbackError) {
            throw new Error(`移入回收站时保存本机数据失败：${saved.error}；回收站回滚也失败：${errorMessage(rollbackError)}。原文献副本仍在回收站，请勿清空。`)
          }
          throw new Error(`移入回收站失败：${saved.error}`)
        }
        return { ok: true, path: dataFile, paper, text: nextText }
      } catch (error) {
        return { ok: false, error: errorMessage(error) }
      }
    })
  }

  async function restorePaperFromTrash(paperId: string): Promise<TrashResult> {
    return runExclusive(async () => {
      try {
        if (!validPaperId(paperId)) throw new Error('文献编号无效，未修改本机数据。')
        const trash = await readTrash()
        const matchingIndexes = trash.records.map((item, index) => item.paperId === paperId ? index : -1).filter((index) => index >= 0)
        if (matchingIndexes.length !== 1) throw new Error(matchingIndexes.length ? '回收站中存在重复编号，已停止恢复。' : '回收站中找不到这篇文献。')
        const current = await readValidatedData()
        if (current.papers.some((paper) => paper.id === paperId)) throw new Error('本机文献库已存在相同编号，未恢复回收站记录。')
        const record = trash.records[matchingIndexes[0]]
        const nextText = JSON.stringify({ ...current.data, papers: [record.paper, ...current.papers] }, null, 2)
        const saved = await saveOnce(nextText)
        if (!saved.ok) throw new Error(`恢复文献失败：${saved.error}`)

        const nextRecords = trash.records.filter((_, index) => index !== matchingIndexes[0])
        try {
          await writeTrash(nextRecords)
        } catch (error) {
          const rollback = await saveOnce(current.text)
          if (rollback.ok) throw new Error(`移除回收站记录失败，已撤销本次恢复：${errorMessage(error)}`)
          return {
            ok: true,
            path: dataFile,
            paper: record.paper,
            text: nextText,
            warning: `文献已恢复到本机，但回收站记录未能清除（${errorMessage(error)}）；再次恢复前请刷新列表。`,
          }
        }
        return { ok: true, path: dataFile, paper: record.paper, text: nextText }
      } catch (error) {
        return { ok: false, error: errorMessage(error) }
      }
    })
  }

  async function permanentlyDeleteFromTrash(paperId: string): Promise<TrashResult> {
    return runExclusive(async () => {
      try {
        if (!validPaperId(paperId)) throw new Error('文献编号无效，回收站未修改。')
        const trash = await readTrash()
        const matching = trash.records.filter((item) => item.paperId === paperId)
        if (matching.length !== 1) throw new Error(matching.length ? '回收站中存在重复编号，已停止永久清除。' : '回收站中找不到这篇文献。')
        await writeTrash(trash.records.filter((item) => item.paperId !== paperId))
        // The referenced PDF intentionally remains in pdfDir; it may be shared by another paper.
        return { ok: true, path: trashFile }
      } catch (error) {
        return { ok: false, error: errorMessage(error) }
      }
    })
  }

  return {
    ensure,
    load,
    save,
    runExclusive,
    movePaperToTrash,
    listTrash,
    restorePaperFromTrash,
    permanentlyDeleteFromTrash,
  }
}
