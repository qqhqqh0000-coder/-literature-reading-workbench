declare module '*.mjs' {
  export function extractPdfText(buffer: Buffer): {
    text: string
    pages: number
    chars: number
    bytes?: number
    confidence: number
    lowConfidence: boolean
    truncated?: boolean
  }
}
