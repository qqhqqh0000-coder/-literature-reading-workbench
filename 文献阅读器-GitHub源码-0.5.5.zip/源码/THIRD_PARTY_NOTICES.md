# Third-party notices

The repository-level MIT license applies only to project code owned by
`qqhqqhh0000-coder`. It does not replace or change the separate licenses for
third-party components. Keep the relevant license and notice files when
redistributing source or application builds.

The components below are included in the application or its packaged runtime;
their versions and license identifiers are confirmed by `package-lock.json`
or the checked-in vendor license files.

| Component | Version | License | License and notice source |
| --- | --- | --- | --- |
| React | 19.3.0 | MIT | `package-lock.json`; package source `node_modules/react/LICENSE`; packaged copy `dist/licenses/react-MIT.txt` |
| React DOM | 19.3.0 | MIT | `package-lock.json`; package source `node_modules/react-dom/LICENSE`; packaged copy `dist/licenses/react-dom-MIT.txt` |
| Scheduler (React DOM dependency) | 0.28.0 | MIT | `package-lock.json`; package source `node_modules/scheduler/LICENSE`; packaged copy `dist/licenses/scheduler-MIT.txt` |
| Electron | 35.7.5 | MIT | `package-lock.json`; packaged runtime license `LICENSE.electron.txt` beside the main executable |
| Chromium components distributed with Electron | As supplied by Electron 35.7.5 | See bundled notices | Packaged runtime notice `LICENSES.chromium.html` beside the main executable |
| PDF.js (`pdfjs-dist`) | 4.6.82 | Apache-2.0 | `vendor/pdfjs/NOTICE.txt` and `vendor/pdfjs/LICENSE` |

The build copies the repository `LICENSE` and this notice to `dist/LICENSE` and
`dist/THIRD_PARTY_NOTICES.md`, and copies the React license texts to
`dist/licenses/`. `package.json` includes `dist/**/*`, so these files are
included in the application package under `dist/`. Electron's license files
are retained by the Electron runtime distribution beside the main executable
in the packaged application's top-level directory.

The PDF.js files in `vendor/pdfjs/` are the bundled `pdf.min.mjs` and
`pdf.worker.min.mjs` identified in `vendor/pdfjs/NOTICE.txt`. The full Apache
2.0 license text remains in `vendor/pdfjs/LICENSE`.

The lockfile also records development and build dependencies. They retain the
licenses stated by their respective packages; this notice does not claim to
relicense those packages or list build-only packages as application runtime
components.
