import { readFile } from 'node:fs/promises'

const file = 'baidu-app.local.json'
let config
try {
  config = JSON.parse(await readFile(file, 'utf8'))
} catch {
  throw new Error(`缺少 ${file}。请从 baidu-app.example.json 复制并填写后再打包。`)
}

if (![config.clientId, config.clientSecret, config.appName].every((value) => typeof value === 'string' && value.trim())) {
  throw new Error(`${file} 必须填写 clientId、clientSecret 和 appName。`)
}

if (/[\\/]/.test(config.appName)) {
  throw new Error('baidu-app.local.json 中的 appName 不能包含斜杠。')
}
