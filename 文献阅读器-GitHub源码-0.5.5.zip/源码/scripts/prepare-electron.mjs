import { copyFile, mkdir, readFile, rm, writeFile } from 'node:fs/promises'

await mkdir('dist-electron', { recursive: true })
await copyFile('electron/preload.cjs', 'dist-electron/preload.cjs')

// Keep project and React runtime license texts inside the packaged app.
const appLicenseDir = 'dist/licenses'
await mkdir(appLicenseDir, { recursive: true })
await Promise.all([
  copyFile('LICENSE', 'dist/LICENSE'),
  copyFile('THIRD_PARTY_NOTICES.md', 'dist/THIRD_PARTY_NOTICES.md'),
  copyFile('node_modules/react/LICENSE', `${appLicenseDir}/react-MIT.txt`),
  copyFile('node_modules/react-dom/LICENSE', `${appLicenseDir}/react-dom-MIT.txt`),
  copyFile('node_modules/scheduler/LICENSE', `${appLicenseDir}/scheduler-MIT.txt`),
])

const localBaiduConfig = 'baidu-app.local.json'
const preparedBaiduConfig = 'dist-electron/baidu-app.json'
const buildInfoFile = 'dist-electron/build-info.json'
const publicBuild = process.argv.includes('--public')

if (publicBuild) {
  // Do not even read the machine-local secret file for a public build.
  await rm(preparedBaiduConfig, { force: true })
} else {
  try {
    const config = JSON.parse(await readFile(localBaiduConfig, 'utf8'))
    if (![config.clientId, config.clientSecret, config.appName].every((value) => typeof value === 'string' && value.trim())) {
      throw new Error(`${localBaiduConfig} must contain clientId, clientSecret, and appName.`)
    }
    await copyFile(localBaiduConfig, preparedBaiduConfig)
  } catch (error) {
    if (error?.code === 'ENOENT') {
      await rm(preparedBaiduConfig, { force: true })
    } else {
      throw error
    }
  }
}

await writeFile(buildInfoFile, JSON.stringify({ edition: publicBuild ? 'public' : 'friends' }) + '\n', 'utf8')
