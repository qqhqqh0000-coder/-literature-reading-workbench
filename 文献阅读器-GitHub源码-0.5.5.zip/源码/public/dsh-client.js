// dsh-literature-reading —— 浏览器半（手写的 DSH client 模块 bundle）
//
// 模块协议：window.__ModuleLoader__.load({ id, factory })，
// factory 内用 require("react") 取 React，导出 apply / inject。
//
// 与 host 半的通信走同源 HTTP：POST /dsh-litread/rpc { op, args }。
window.__ModuleLoader__.load({
	id: "dsh-literature-reading",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });

		const React = require("react");
		const h = React.createElement;
		const RPC_ROUTE = "/dsh-litread/rpc";
		const PDF_ROUTE = "litpdf://document";
		const PDFJS_ROUTE = "litasset://pdfjs";
		/** 实际的数据文件路径，由桌面版 load 回传。 */
		let shownDataPath = "正在读取本地数据位置…";

		/** 阅读模板 13 栏，顺序与用户给的 xlsx 一致。 */
		const COLUMNS = [
			{ id: "title", label: "文章标题", long: false, wide: true, ph: "文章标题" },
			{ id: "rank", label: "分区（影响因子）", long: false, wide: false, ph: "JCR Q1 / 中科院 1 区 · IF 12.3" },
			{ id: "journal", label: "期刊", long: false, wide: false, ph: "Lancet / BMJ / …" },
			{ id: "published", label: "发表时间", long: false, wide: false, ph: "2024-05" },
			{ id: "purpose", label: "研究目的", long: true, wide: true, ph: "这篇文章在分析什么内容？想解决什么问题？" },
			{ id: "sampleSize", label: "纳入人数", long: false, wide: false, ph: "452,361 人 / 随访 12.5 年" },
			{ id: "methods", label: "主要方法", long: true, wide: true, ph: "用了什么分析方法？适用场景是什么？（回归 / MR / 倾向评分…）" },
			{ id: "exposure", label: "暴露", long: true, wide: true, ph: "谁与谁的关系？暴露与结局怎么定义？" },
			{ id: "results", label: "主要结果", long: true, wide: true, ph: "效应量 HR/OR/β、95%CI、P 分别代表什么？纳入排除标准？" },
			{ id: "features", label: "特点", long: true, wide: true, ph: "这篇新在哪里？和已有文献的差别？设计 / 样本 / 方法上的亮点" },
			{ id: "thoughts", label: "思考", long: true, wide: true, ph: "批判思考：假设、方法、证据是否成立？我自己的见解？" },
			{ id: "dataSource", label: "使用数据", long: false, wide: false, ph: "UK Biobank / NHANES / 单中心队列" },
			{ id: "extra", label: "其他", long: true, wide: true, ph: "根据你想背调的方向加入的特殊内容" },
		];
		const COL_IDS = COLUMNS.map((c) => c.id);
		const COLUMN_GROUPS = [
			{ id: "basic", label: "基本信息", hint: "先记录文章身份与样本", columns: ["title", "rank", "journal", "published", "sampleSize", "dataSource"] },
			{ id: "design", label: "研究设计", hint: "研究问题、方法与变量", columns: ["purpose", "methods", "exposure"] },
			{ id: "findings", label: "结果与评价", hint: "主要发现、创新点与个人判断", columns: ["results", "features", "thoughts"] },
			{ id: "extra", label: "其他补充", hint: "按自己的阅读方向补充", columns: ["extra"] },
		].map((group) => Object.assign({}, group, { fields: group.columns.map((id) => COLUMNS.find((column) => column.id === id)).filter(Boolean) }));

		const SOURCES = ["公共数据库与孟德尔随机化", "iNature", "柳叶刀TheLancet", "生物世界", "StatHub", "生信人", "小Lin爱科研", "云生信学生物信息学", "奇点网", "bio生物信息", "NEJM医学前沿", "医学新视点"];
		const SOURCE_OPTIONS = SOURCES.concat(["其他"]);
		const STATUSES = ["未读", "精读中", "已完成", "泛读"];
		const KINDS = ["原始研究", "综述", "Meta 分析", "孟德尔随机化", "队列研究", "RCT", "其他"];

		const CSS = [
			".lit-page{display:flex;flex-direction:column;height:100%;min-height:420px;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font-size:13px}",
			".lit-head{display:flex;align-items:center;gap:8px;padding:10px 14px;border-bottom:1px solid var(--dsw-alias-border-l1);flex:none;flex-wrap:wrap}",
			".lit-h1{font-size:15px;font-weight:600;line-height:1.3}",
			".lit-h2{font-size:11px;color:var(--dsw-alias-label-secondary);margin-top:2px}",
			".lit-grow{flex:1;min-width:0}",
			".lit-small{font-size:11.5px;color:var(--dsw-alias-label-secondary);line-height:1.75}",
			".lit-btn{cursor:pointer;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);border-radius:6px;padding:4px 10px;font:inherit;line-height:1.6;white-space:nowrap;display:inline-block}",
			".lit-btn:hover{background:var(--dsw-alias-bg-layer-2)}",
			".lit-btn[disabled]{opacity:.5;cursor:default}",
			".lit-btn-primary{background:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary);color:#fff}",
			".lit-mini{cursor:pointer;border:1px solid var(--dsw-alias-border-l1);background:transparent;color:var(--dsw-alias-label-secondary);border-radius:5px;padding:1px 6px;font-size:11px;font-family:inherit;margin-top:4px}",
			".lit-mini:hover{color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-border-l2)}",
			".lit-mini[disabled]{opacity:.5;cursor:default}",
			".lit-save{font-size:11px;color:var(--dsw-alias-label-secondary);min-width:56px;text-align:right}",
			".lit-err{color:var(--dsw-alias-state-error-primary);font-size:11.5px}",
			".lit-ok{color:var(--dsw-alias-state-success-primary);font-size:11.5px}",
			".lit-warn{color:var(--dsw-alias-state-warn-primary);font-size:11.5px}",
			".lit-body{display:flex;flex:1;min-height:0;overflow-x:auto}",
			".lit-col-list{width:266px;flex:none;border-right:1px solid var(--dsw-alias-border-l1);display:flex;flex-direction:column;min-height:0}",
			".lit-tabs{display:flex;gap:6px;padding:8px 10px 6px;flex:none;flex-wrap:wrap}",
			".lit-tab{cursor:pointer;font-size:12px;padding:3px 9px;border-radius:999px;border:1px solid transparent;color:var(--dsw-alias-label-secondary)}",
			".lit-tab.is-on{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-border-l1)}",
			".lit-search{padding:0 10px 6px;flex:none}",
			".lit-list{overflow:auto;flex:1;min-height:0;padding:0 8px 12px}",
			".lit-item{cursor:pointer;border:1px solid transparent;border-radius:8px;padding:7px 8px;margin-bottom:4px}",
			".lit-item:hover{background:var(--dsw-alias-bg-layer-1)}",
			".lit-item.is-active{background:var(--dsw-alias-bg-layer-1);border-color:var(--dsw-alias-border-l2)}",
			".lit-item-title{font-size:12.5px;line-height:1.45;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}",
			".lit-item-meta{font-size:11px;color:var(--dsw-alias-label-secondary);margin-top:3px;line-height:1.4}",
			".lit-pill{display:inline-block;font-size:10.5px;padding:1px 6px;border-radius:999px;border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);margin-top:5px}",
			".lit-pill-done{color:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}",
			".lit-pill-doing{color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary)}",
			".lit-pill-skim{color:var(--dsw-alias-state-warn-primary);border-color:var(--dsw-alias-state-warn-primary)}",
			".lit-mini-bar{height:4px;border-radius:999px;background:var(--dsw-alias-bg-layer-2);overflow:hidden;margin-top:5px}",
			".lit-mini-bar-fill{height:100%;background:var(--dsw-alias-brand-primary)}",
			".lit-col-main{flex:1;min-width:320px;overflow:auto;padding:12px 16px 48px}",
			".lit-col-side{width:272px;flex:none;border-left:1px solid var(--dsw-alias-border-l1);overflow:auto;padding:10px}",
			".lit-rail{width:30px;flex:none;display:flex;flex-direction:column;align-items:center;padding-top:8px;border-right:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-1)}",
			".lit-rail.is-right{border-right:none;border-left:1px solid var(--dsw-alias-border-l1)}",
			".lit-collapse{cursor:pointer;border:1px solid var(--dsw-alias-border-l1);background:transparent;color:var(--dsw-alias-label-secondary);border-radius:6px;font:inherit;font-size:11px;line-height:1;padding:4px 5px}",
			".lit-collapse:hover{color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-border-l2)}",
			".lit-side-h{display:flex;align-items:center;gap:6px;margin:0 0 6px 0}",
			".lit-reader{flex:1;min-width:320px;min-height:0;display:flex;overflow:hidden}",
			".lit-reader-pane{flex:1 1 0;min-width:0;min-height:0;display:flex;flex-direction:column;overflow:hidden}",
			".lit-reader-pane + .lit-reader-pane{border-left:1px solid var(--dsw-alias-border-l1)}",
			// 中间栏内部的分隔条：拖着改左右占比
			".lit-split{flex:0 0 7px;align-self:stretch;cursor:col-resize;background:var(--dsw-alias-border-l1);position:relative;display:flex;align-items:center;justify-content:center}",
			".lit-split::after{content:'';width:2px;height:28px;border-radius:1px;background:var(--dsw-alias-label-secondary);opacity:.45}",
			".lit-split:hover::after{opacity:.95;height:44px}",
			".lit-split:active::after{opacity:.95}",
			".lit-reader.is-splitting{user-select:none;cursor:col-resize}",
			".lit-reader.is-splitting .lit-split::after{opacity:.95;height:44px}",
			// 思维导图
			".lit-mind-wrap{border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:var(--dsw-alias-bg-layer-1);padding:6px;overflow:auto}",
			".lit-mind{display:block}",
			".lit-mind-edge{fill:none;stroke:var(--dsw-alias-border-l1);stroke-width:1.4}",
			".lit-mind-node rect{fill:var(--dsw-alias-bg-layer-2);stroke:var(--dsw-alias-border-l1)}",
			".lit-mind-node text{font-size:11.5px;fill:var(--dsw-alias-label-primary)}",
			".lit-mind-node.d0 rect{fill:var(--dsw-alias-brand-primary);fill-opacity:.16;stroke:var(--dsw-alias-brand-primary)}",
			".lit-mind-node.d0 text{font-weight:600}",
			".lit-mind-node.d1 text{fill:var(--dsw-alias-label-primary)}",
			".lit-mind-node.d2 text{fill:var(--dsw-alias-label-secondary)}",
			".lit-mind-text{width:100%;min-height:120px;margin-top:4px;padding:6px 8px;border:1px solid var(--dsw-alias-border-l1);border-radius:6px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:11.5px;line-height:1.6;white-space:pre;resize:vertical}",
			".lit-backend-down{margin:0 0 8px;padding:6px 10px;border-radius:8px;font-size:12px;line-height:1.6;color:var(--dsw-alias-state-warn-primary);background:color-mix(in srgb, var(--dsw-alias-state-warn-primary) 12%, transparent);border:1px solid color-mix(in srgb, var(--dsw-alias-state-warn-primary) 40%, transparent)}",
			// 勾划篮：攒几段勾划再一起翻
			".lit-basket{position:relative;margin:6px 10px 0;padding:8px;border:1px solid var(--dsw-alias-brand-primary);border-radius:8px;background:var(--dsw-alias-bg-layer-1);flex:none;max-height:34vh;overflow:auto}",
			".lit-basket.is-shut{padding:4px 8px;background:var(--dsw-alias-bg-layer-1)}",
			".lit-basket-h{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:6px}",
			".lit-basket.is-shut .lit-basket-h{margin-bottom:0}",
			".lit-basket-acts{display:flex;align-items:center;gap:6px;flex-wrap:wrap;flex:1;min-width:0}",
			".lit-basket-toggle{cursor:pointer;border:1px solid var(--dsw-alias-border-l1);background:transparent;color:var(--dsw-alias-label-secondary);border-radius:5px;padding:2px 5px;line-height:1;display:inline-flex;align-items:center;flex:none}",
			".lit-basket-toggle:hover{color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary)}",
			".lit-basket-title{cursor:pointer}",
			// 左侧列表里的移除按钮：平时低调，鼠标移到该条才明显；上膛后变红
			".lit-item{position:relative}",
			".lit-item-x{position:absolute;right:6px;top:6px;cursor:pointer;border:1px solid transparent;background:transparent;color:var(--dsw-alias-label-secondary);border-radius:5px;font:inherit;font-size:12px;line-height:1;padding:2px 6px;opacity:.45}",
			".lit-item:hover .lit-item-x{opacity:1}",
			".lit-item-x:hover{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}",
			".lit-item-x.is-armed{opacity:1;color:#fff;background:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary);font-size:11px}",
			".lit-mini-armed{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}",
			".lit-basket-item{display:flex;align-items:center;gap:6px;padding:3px 4px;border-radius:5px;font-size:11.5px;line-height:1.5}",
			".lit-basket-item:hover{background:var(--dsw-alias-bg-layer-2)}",
			".lit-basket-no{color:var(--dsw-alias-label-secondary);flex:none}",
			".lit-basket-text{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
			".lit-basket-preview-button{border:0;background:transparent;color:inherit;font:inherit;text-align:left;padding:0;cursor:pointer}",
			".lit-basket-preview-button:hover{color:var(--dsw-alias-brand-primary)}",
			".lit-basket-item .lit-mini{flex:none;margin:0;white-space:nowrap}",
			".lit-selection-mode{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--dsw-alias-label-secondary)}",
			".lit-selection-mode select{width:auto;min-width:128px;margin:0}",
			".lit-selection-preview{display:flex;align-items:flex-start;gap:8px;margin:6px 10px 0;padding:8px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;flex:none;background:var(--dsw-alias-bg-layer-1)}",
			".lit-selection-preview details{flex:1;min-width:0;font-size:12px}",
			".lit-selection-preview summary{cursor:pointer;color:var(--dsw-alias-brand-primary);overflow-wrap:anywhere}",
			".lit-selection-text{max-height:100px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.7;margin-top:6px;user-select:text}",
			".lit-selection-preview .lit-mini{margin:0;flex:none;white-space:nowrap}",
			".lit-reader-head{display:flex;align-items:center;gap:6px;padding:6px 10px;border-bottom:1px solid var(--dsw-alias-border-l1);flex:none;flex-wrap:wrap}",
			".lit-reader-title{font-weight:600;font-size:13px}",
			".lit-reader-progress{padding:6px 10px 2px;flex:none}",
			".lit-reader-actions{display:flex;gap:6px;flex-wrap:wrap;padding:6px 10px;flex:none;border-bottom:1px solid var(--dsw-alias-border-l1)}",
			".lit-reader-text{flex:1;min-height:0;overflow:auto;padding:8px 12px 40px}",
			".lit-reader-body{flex:1;min-height:0;overflow:auto;padding:8px 12px 40px}",
			// 对照阅读：默认收起设置，把剩余高度用于当前原文和译文。
			".lit-reader-right .lit-reader-head{padding:5px 10px;gap:7px}",
			".lit-reader-right .lit-reader-head .lit-btn{padding:3px 9px;font-size:12px}",
			".lit-reader-summary{display:flex;align-items:center;gap:8px;padding:4px 10px;border-bottom:1px solid var(--dsw-alias-border-l1);flex:none;min-height:29px;font-size:11.5px}",
			".lit-reader-stat{color:var(--dsw-alias-label-secondary);white-space:nowrap;flex:none}",
			".lit-reader-summary .lit-mini{margin:0;white-space:nowrap;flex:none}",
			".lit-reader-status{flex:1;min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;color:var(--dsw-alias-state-success-primary)}",
			".lit-reader-status.is-merged{flex-basis:0}",
			".lit-reader-merged-status{flex:none;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:3px 8px;border:1px solid var(--dsw-alias-border-l1);border-radius:999px;color:var(--dsw-alias-state-success-primary);font-size:11.5px}",
			".lit-reader-tools{flex:none;max-height:34%;overflow:auto;border-bottom:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-1)}",
			".lit-reader-tool-options{display:flex;align-items:center;gap:12px;padding:6px 10px;flex-wrap:wrap}",
			".lit-reader-right .lit-reader-actions{border-bottom:0;padding:4px 10px 8px}",
			".lit-reader-right .lit-selection-preview{padding:6px 8px;margin-top:4px;max-height:24%;overflow:auto}",
			".lit-reader-right .lit-basket{margin:4px 10px 0;max-height:23%;padding:6px 8px}",
			".lit-reader-right .lit-basket.is-shut{padding:3px 8px}",
			".lit-reading-content{display:flex;flex-direction:column;gap:8px;padding:8px 10px 10px}",
			".lit-reading-content>.lit-empty{flex:1;display:flex;align-items:center;justify-content:center;padding:20px;line-height:1.9}",
			".lit-current-translation{display:flex;flex-direction:column;flex:1 0 230px;min-height:230px;gap:8px;overflow:hidden}",
			".lit-current-source{display:flex;flex-direction:column;flex:0 1 28%;min-height:30px;overflow:hidden;border:1px solid var(--dsw-alias-border-l1);border-radius:7px;background:var(--dsw-alias-bg-layer-2)}",
			".lit-current-source.is-shut{flex:none}",
			".lit-source-head{display:flex;align-items:center;gap:8px;padding:4px 8px;flex:none}",
			".lit-source-head .lit-small{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
			".lit-source-head .lit-mini{margin:0;flex:none;white-space:nowrap}",
			".lit-source-head .lit-source-merge{min-height:28px;padding:3px 9px;font-size:11.5px;flex:none;white-space:nowrap}",
			".lit-source-original{flex:1;min-height:0;overflow:auto;padding:4px 10px 8px;font-size:13px;line-height:1.8;white-space:pre-wrap;overflow-wrap:anywhere}",
			".lit-translation-editor{display:flex;flex-direction:column;flex:1;min-height:100px;gap:4px}",
			".lit-translation-editor .lit-textarea{font-size:14px;line-height:1.85;padding:10px 12px}",
			".lit-current-translation.is-fixed{flex:none;min-height:0}",
			".lit-current-translation.is-fixed .lit-current-source{flex:none;max-height:140px}",
			".lit-current-translation.is-fixed .lit-translation-editor{flex:none}",
			".lit-translation-history{display:flex;flex-direction:column;flex:none;max-height:28%;min-height:32px;border-top:1px solid var(--dsw-alias-border-l1);padding-top:4px;overflow:hidden}",
			".lit-history-toggle{display:flex;align-items:center;gap:6px;border:0;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;padding:4px 0;cursor:pointer;text-align:left;flex:none}",
			".lit-history-content{min-height:0;overflow:auto;padding-right:3px}",
			".lit-history-toggle:focus-visible,.lit-basket-preview-button:focus-visible{outline:3px solid #6e9c73;outline-offset:2px}",
			"@media(max-width:1100px){.lit-reader-summary{gap:5px;flex-wrap:wrap}.lit-reader-status{flex-basis:100%;font-size:11px}.lit-reader-right .lit-reader-head{gap:5px}}",
			// ── 版式模式：自己画的真实 PDF 页面 ──
			".lit-reader-layout{display:flex;flex-direction:column;overflow:hidden;padding:0}",
			".lit-pdfbar{display:flex;align-items:center;gap:6px;padding:5px 8px;border-bottom:1px solid var(--dsw-alias-border-l1);flex-wrap:wrap;flex:none}",
			".lit-pdfgate{margin:10px;padding:12px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:var(--dsw-alias-bg-layer-1)}",
			".lit-pdfstack{flex:1;min-width:0;min-height:0;overflow:auto;padding:10px;display:block;background:var(--dsw-alias-bg-layer-2)}",
			".lit-pdfpage{display:block;margin:0 auto 12px;position:relative;background:#fff;box-shadow:0 2px 10px rgba(0,0,0,.18);border-radius:2px;overflow:hidden}",
			".lit-pdfpage canvas{display:block;width:100%;height:100%}",
			".lit-pdfpage.is-loading::after{content:'渲染中…';position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);font-size:12px;color:#999}",
			".lit-pdfpage.is-bad::after{content:'这一页渲染失败';position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);font-size:12px;color:#c0392b}",
			".lit-pdfpage-no{position:absolute;right:4px;bottom:4px;font-size:10px;color:#666;background:rgba(255,255,255,.75);border-radius:3px;padding:0 4px;pointer-events:none}",
			".lit-pdftext{position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;line-height:1;font-family:sans-serif}",
			".lit-pdftext span{position:absolute;color:transparent;white-space:pre;transform-origin:0 0;cursor:text}",
			".lit-pdftext span::selection{background:rgba(70,130,255,.35)}",
			// 每行包一层：必须是 static（absolutely 定位的 span 才会继续相对页面容器定位），
			// 高度 0 也不参与布局；作用只是让 DOM 顺序 = 行顺序，拖选不会跨行乱串
			".lit-reader-seg{padding:5px 8px;border-radius:6px;margin-bottom:4px;cursor:pointer;border:1px solid transparent}",
			".lit-reader-seg:hover{background:var(--dsw-alias-bg-layer-1)}",
			".lit-reader-seg.is-current{border-color:var(--dsw-alias-brand-primary);background:var(--dsw-alias-bg-layer-1)}",
			".lit-reader-seg.is-done{background:var(--dsw-alias-bg-layer-1)}",
			".lit-reader-seg-no{font-size:10.5px;color:var(--dsw-alias-label-secondary);margin-bottom:2px}",
			".lit-reader-seg-text{font-size:12.5px;line-height:1.75;white-space:pre-wrap;overflow-wrap:anywhere}",
			".lit-pdf{flex:1;min-height:0;width:100%;border:0;background:var(--dsw-alias-bg-layer-2)}",
			".lit-picked{font-size:11.5px;line-height:1.6;padding:4px 6px;border-radius:6px;cursor:pointer;border:1px solid var(--dsw-alias-border-l1);margin-bottom:4px}",
			".lit-picked.is-current{border-color:var(--dsw-alias-brand-primary)}",
			".lit-picked-row{display:flex;align-items:center;gap:8px}",
			".lit-picked-row .lit-picked-text{flex:1;min-width:0;overflow-wrap:anywhere}",
			".lit-picked-row .lit-mini{float:none;flex:none;margin:0;white-space:nowrap}",
			".lit-crash{margin:12px;padding:12px;border:1px solid var(--dsw-alias-state-error-primary);border-radius:10px;background:var(--dsw-alias-bg-layer-1)}",
			".lit-crash-h{font-weight:600;font-size:13px;color:var(--dsw-alias-state-error-primary);margin-bottom:6px}",
			".lit-crash-body{white-space:pre-wrap;word-break:break-all;font-size:11.5px;line-height:1.6;max-height:320px;overflow:auto;background:var(--dsw-alias-bg-layer-2);border-radius:6px;padding:8px;margin:0 0 6px 0}",
			".lit-hset{display:inline-flex;gap:4px;align-items:center}",
			".lit-hset button{cursor:pointer;border:1px solid var(--dsw-alias-border-l1);background:transparent;color:var(--dsw-alias-label-secondary);border-radius:5px;font:inherit;font-size:11px;line-height:1;padding:4px 6px}",
			".lit-hset button.is-on{color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary)}",
			".lit-empty{padding:24px 6px;color:var(--dsw-alias-label-secondary);font-size:12px;text-align:center;line-height:1.9}",
			".lit-paperhead{display:flex;align-items:flex-start;gap:8px;margin-bottom:8px}",
			".lit-papertitle{font-size:15px;font-weight:600;line-height:1.5;flex:1;min-width:0}",
			".lit-card{background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:10px;padding:10px 12px;margin-bottom:10px}",
			".lit-card-h{display:flex;align-items:center;gap:8px;font-weight:600;font-size:13px;margin-bottom:6px;flex-wrap:wrap}",
			".lit-form{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(190px,100%),1fr));gap:9px}",
			".lit-autofill-status{margin:0 0 8px}",
			".lit-autofill-note{margin:0 0 8px}",
			".lit-autofill-preview{margin-top:10px;padding:10px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:var(--dsw-alias-bg-base)}",
			".lit-autofill-heading{display:flex;flex-direction:column;gap:3px;margin-bottom:8px}",
			".lit-autofill-list{display:grid;gap:8px;max-height:420px;overflow:auto;padding-right:3px}",
			".lit-autofill-item{border:1px solid var(--dsw-alias-border-l1);border-radius:7px;background:var(--dsw-alias-bg-layer-1);padding:8px}",
			".lit-autofill-choice{display:flex;align-items:center;gap:6px;font-size:11.5px;margin-bottom:5px}",
			".lit-autofill-value{width:100%;min-height:54px;resize:vertical;border:1px solid var(--dsw-alias-border-l1);border-radius:5px;padding:6px;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px;line-height:1.6}",
			".lit-autofill-evidence{margin-top:5px;color:var(--dsw-alias-label-secondary);font-size:10.5px;line-height:1.6;white-space:pre-wrap;word-break:break-word}",
			".lit-autofill-actions{display:flex;align-items:center;gap:7px;margin-top:9px;flex-wrap:wrap}",
			".lit-autofill-batch-tools{display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:0 10px 7px}",
			".lit-autofill-batch-panel{margin:0 8px 8px;padding:8px;border:1px solid var(--dsw-alias-border-l1);border-radius:7px;background:var(--dsw-alias-bg-layer-1);font-size:11px;line-height:1.6}",
			".lit-autofill-batch-panel ul{margin:4px 0 0;padding-left:18px}",
			".lit-autofill-batch-error{color:var(--dsw-alias-state-error-primary);word-break:break-word}",
			".lit-item-select{vertical-align:middle;margin:0 5px 0 0}",
			".lit-batch-review{display:inline-block;margin-left:5px;color:var(--dsw-alias-brand-primary);font-size:10.5px}",
			".lit-task-center{flex:none;padding:6px 14px;border-bottom:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-base)}",
			".lit-task-summary{display:flex;align-items:center;gap:8px;min-height:24px}",
			".lit-task-summary{flex-wrap:wrap}",
			".lit-task-summary-label{font-size:12px;font-weight:600;white-space:nowrap}",
			".lit-task-summary-stage{min-width:120px;flex:1;overflow-wrap:anywhere}",
			".lit-task-toggle{display:inline-flex;align-items:center;gap:5px;flex:none;cursor:pointer;border:1px solid var(--dsw-alias-border-l1);border-radius:6px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-secondary);padding:4px 8px;font:inherit;font-size:11px;white-space:nowrap}",
			".lit-task-toggle:hover{color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2)}",
			".lit-task-toggle:focus-visible{outline:3px solid #6e9c73;outline-offset:2px}",
			".lit-task-list{display:grid;gap:5px;margin-top:6px;max-height:160px;overflow:auto}",
			".lit-task-row{display:flex;align-items:flex-start;gap:8px;padding:6px 8px;border:1px solid var(--dsw-alias-border-l1);border-radius:6px;background:var(--dsw-alias-bg-layer-1);font-size:11px;line-height:1.5}",
			".lit-task-main{flex:1;min-width:0}",
			".lit-task-title{font-weight:600}",
			".lit-task-stage{color:var(--dsw-alias-label-secondary);overflow-wrap:anywhere}",
			".lit-task-error{color:var(--dsw-alias-state-error-primary);overflow-wrap:anywhere}",
			".lit-task-progress{height:3px;margin-top:4px;border-radius:99px;background:var(--dsw-alias-bg-layer-2);overflow:hidden}",
			".lit-task-progress>span{display:block;height:100%;background:var(--dsw-alias-brand-primary)}",
			".lit-evidence{font-size:10px;color:var(--dsw-alias-label-secondary);line-height:1.5}",
			".lit-evidence summary{cursor:pointer;color:var(--dsw-alias-brand-primary)}",
			".lit-evidence span{display:block;margin-top:2px;white-space:pre-wrap;word-break:break-word}",
			".lit-field{display:flex;flex-direction:column;gap:3px;min-width:0}",
			".lit-field.lit-wide{grid-column:1/-1}",
			".lit-flabel{font-size:11px;color:var(--dsw-alias-label-secondary)}",
			".lit-flabel.is-empty:after{content:' · 待填';color:var(--dsw-alias-state-warn-primary)}",
			".lit-input,.lit-textarea{width:100%;box-sizing:border-box;background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l1);border-radius:6px;color:var(--dsw-alias-label-primary);padding:4px 7px;font:inherit;font-size:12.5px;outline:none}",
			".lit-input:focus,.lit-textarea:focus{border-color:var(--dsw-alias-brand-primary)}",
			".lit-textarea{min-height:70px;resize:vertical;line-height:1.7;font-family:inherit}",
			".lit-textarea-lg{min-height:200px}",
			".lit-bar{height:6px;border-radius:999px;background:var(--dsw-alias-bg-layer-2);overflow:hidden}",
			".lit-bar-fill{height:100%;background:var(--dsw-alias-brand-primary)}",
			".lit-progress-line{font-size:11.5px;color:var(--dsw-alias-label-secondary);margin-top:6px}",
			".lit-chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:7px}",
			".lit-chip{font-size:10.5px;padding:1px 6px;border-radius:999px;border:1px dashed var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary)}",
			".lit-range{width:100%;margin:6px 0 2px}",
			".lit-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:8px;margin-top:6px}",
			".lit-stat{background:var(--dsw-alias-bg-layer-2);border-radius:8px;padding:6px 8px}",
			".lit-stat-v{font-size:15px;font-weight:600;line-height:1.3}",
			".lit-stat-k{font-size:10.5px;color:var(--dsw-alias-label-secondary)}",
			".lit-log{font-size:11px;color:var(--dsw-alias-label-secondary);line-height:1.7;margin-top:5px}",
			".lit-seg{border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:8px 10px;margin-bottom:8px;background:var(--dsw-alias-bg-base)}",
			".lit-seg.is-done{border-color:var(--dsw-alias-state-success-primary)}",
			".lit-seg-h{display:flex;align-items:center;gap:6px;font-size:11.5px;color:var(--dsw-alias-label-secondary);margin-bottom:5px;flex-wrap:wrap}",
			".lit-seg-no{font-weight:600;color:var(--dsw-alias-label-primary)}",
			".lit-seg-en{font-size:12px;line-height:1.65;white-space:pre-wrap;max-height:130px;overflow:auto;overflow-wrap:anywhere;background:var(--dsw-alias-bg-layer-2);border-radius:6px;padding:6px 8px;margin-bottom:6px}",
			".lit-batch{font-size:11.5px;color:var(--dsw-alias-brand-primary);font-weight:600}",
			".lit-detail summary{cursor:pointer;font-size:11px;color:var(--dsw-alias-label-secondary);margin-top:4px}",
			".lit-tablewrap{overflow:auto;max-height:60vh;border:1px solid var(--dsw-alias-border-l1);border-radius:8px}",
			".lit-table{border-collapse:separate;border-spacing:0;width:max-content;min-width:100%}",
			".lit-table th,.lit-table td{border-right:1px solid var(--dsw-alias-border-l1);border-bottom:1px solid var(--dsw-alias-border-l1);padding:4px;vertical-align:top;text-align:left}",
			".lit-table th{position:sticky;top:0;z-index:2;background:var(--dsw-alias-bg-layer-2);font-size:11.5px;white-space:nowrap;font-weight:600}",
			".lit-table td.lit-stick,.lit-table th.lit-stick{position:sticky;left:0;z-index:1;background:var(--dsw-alias-bg-layer-1);text-align:center}",
			".lit-table th.lit-stick{z-index:3}",
			".lit-cell{display:block;width:196px;min-height:58px;box-sizing:border-box;background:transparent;border:none;color:inherit;font:inherit;font-size:12px;line-height:1.6;resize:vertical;outline:none;padding:2px}",
			".lit-cell:focus{background:var(--dsw-alias-bg-layer-2)}",
			".lit-hbtn{display:inline-flex;align-items:center;gap:4px;cursor:pointer;border:1px solid transparent;background:transparent;color:var(--dsw-alias-label-secondary);border-radius:6px;padding:3px 7px;font:inherit;font-size:12px}",
			".lit-hbtn:hover{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary)}",
			".lit-hbtn.is-on{color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary)}",
			".lit-icon-wrap{display:inline-flex;align-items:center;justify-content:center;color:inherit}",
			".lit-icon-wrap.is-on{color:var(--dsw-alias-brand-primary)}",
			".lit-float{position:fixed;right:16px;top:64px;width:min(378px,calc(100vw - 32px));max-height:74vh;display:flex;flex-direction:column;background:var(--dsw-alias-bg-overlay);border:1px solid var(--dsw-alias-border-l2);border-radius:12px;box-shadow:0 12px 32px rgba(0,0,0,.28);z-index:60;pointer-events:auto;overflow:hidden}",
			".lit-float-head{display:flex;align-items:center;gap:6px;padding:8px 10px;border-bottom:1px solid var(--dsw-alias-border-l1)}",
			".lit-float-title{font-weight:600;font-size:12.5px}",
			".lit-float-body{padding:10px;overflow:auto;display:flex;flex-direction:column;gap:8px}",
			".lit-float-steptitle{font-size:12px;font-weight:600}",
			".lit-float-foot{display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap}",
			".lit-path{font-size:11px;color:var(--dsw-alias-label-secondary);word-break:break-all;line-height:1.6}",
			".lit-workflow-nav{display:flex;align-items:center;gap:6px;padding:7px 14px;border-bottom:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-1);flex:none;overflow-x:auto}",
			".lit-workflow-tab{flex:none;cursor:pointer;border:1px solid transparent;border-radius:7px;background:transparent;color:#5f6c5d;padding:6px 11px;font:inherit;font-size:12.5px;white-space:nowrap}",
			".lit-workflow-tab:hover{background:#f1f5ef;color:#314a34}",
			".lit-workflow-tab.is-on{background:#eaf2e8;border-color:#cfdfcc;color:#2e6b3a;font-weight:600}",
			".lit-library-head{display:flex;align-items:center;gap:8px;padding:8px 10px 5px;font-size:12px;font-weight:600;color:#435342}",
			".lit-form-groups{display:grid;gap:8px}",
			".lit-form-group{border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:var(--dsw-alias-bg-base);overflow:hidden}",
			".lit-form-group-toggle{display:flex;align-items:center;gap:8px;width:100%;min-height:40px;padding:7px 10px;border:0;background:transparent;color:var(--dsw-alias-label-primary);text-align:left;font:inherit;cursor:pointer}",
			".lit-form-group-toggle:hover{background:#f0f4ed}",
			".lit-form-group-name{font-size:12.5px;font-weight:600}",
			".lit-form-group-hint{font-size:11.5px;color:#667363}",
			".lit-form-group-count{margin-left:auto;color:#596a57;font-size:11.5px;white-space:nowrap}",
			".lit-form-group-fields{padding:2px 10px 10px}",
			".lit-page{font-size:13.5px}",
			".lit-small,.lit-h2{font-size:12px;color:#657160}",
			".lit-flabel{font-size:12px;color:#566353;line-height:1.5}",
			".lit-input,.lit-textarea{font-size:13px;min-height:36px;padding:6px 8px}",
			".lit-textarea{min-height:88px}",
			".lit-textarea-lg{min-height:180px}",
			".lit-btn{min-height:34px;padding:5px 11px}",
			".lit-mini{min-height:28px;padding:3px 7px;font-size:11.5px}",
			".lit-papertitle{font-size:16px;overflow-wrap:anywhere}",
			".lit-reader-seg-text{font-size:13px;line-height:1.8}",
			".lit-workflow-tab:focus-visible,.lit-form-group-toggle:focus-visible,.lit-btn:focus-visible,.lit-mini:focus-visible,.lit-collapse:focus-visible,.lit-hset button:focus-visible,.lit-input:focus-visible,.lit-textarea:focus-visible,.lit-cell:focus-visible{outline:3px solid #6e9c73;outline-offset:2px;position:relative;z-index:3}",
			"@media(max-width:760px){.lit-workflow-nav{padding-left:9px;padding-right:9px}.lit-col-list{width:230px}.lit-col-main{padding:10px 12px 36px}.lit-form-group-hint{display:none}}",
			".lit-list-filters{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;padding:0 10px 8px;flex:none}",
			".lit-filter-select{width:100%;min-width:0;height:38px;min-height:38px;padding:0 26px 0 10px!important;border-radius:8px;background-color:#fff;font-size:12px;line-height:1.3}",
			".lit-filter-wide{grid-column:1/-1}",
		].join("\n");

		// ───────────────────────── 纯函数工具 ─────────────────────────

		function errText(error) {
			if (error === null || error === undefined) return "unknown";
			if (typeof error === "string") return error;
			return String(error.message || error);
		}

		function uid(prefix) {
			return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
		}

		function blankProgress() {
			return { percent: 0, minutes: 0, lastReadAt: 0, firstReadAt: 0, finishedAt: 0, log: [], readSegments: 0, scroll: null, readerMode: null, layoutScale: 1 };
		}

		function blankPaper() {
			const paper = {
				id: uid("p"), createdAt: Date.now(), status: "未读",
				kind: "", pmid: "", url: "", tags: "",
				pdf: null,
				translation: { source: "", result: "", segments: [], picked: [], updatedAt: 0 },
				progress: blankProgress(),
			};
			for (const id of COL_IDS) paper[id] = "";
			return paper;
		}

		function isFilled(paper, id) {
			const value = paper ? paper[id] : "";
			return typeof value === "string" && value.trim().length > 0;
		}

		function filledCount(paper) {
			if (paper === null) return 0;
			let n = 0;
			for (const id of COL_IDS) if (isFilled(paper, id)) n++;
			return n;
		}

		function progressOf(paper) {
			const raw = paper && paper.progress && typeof paper.progress === "object" ? paper.progress : {};
			return Object.assign(blankProgress(), raw, {
				log: Array.isArray(raw.log) ? raw.log : [],
				scroll: normalizeScroll(raw.scroll),
				readerMode: raw.readerMode === "pdf" || raw.readerMode === "layout" || raw.readerMode === "text" ? raw.readerMode : null,
				layoutScale: Math.max(0.6, Math.min(3, Number(raw.layoutScale) || 1)),
			});
		}

		function titleFromName(name) {
			return String(name || "").replace(/\.pdf$/i, "").replace(/[_]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 200);
		}

		function statusClass(status) {
			if (status === "已完成") return "lit-pill-done";
			if (status === "精读中") return "lit-pill-doing";
			if (status === "泛读") return "lit-pill-skim";
			return "";
		}

		/** 把毫秒折算成「1 小时 5 分」/「32 分」/「<1 分」。 */
		function fmtDuration(ms) {
			const minutes = Math.floor(ms / 60000);
			if (minutes <= 0) return "<1 分";
			if (minutes < 60) return minutes + " 分";
			const hours = Math.floor(minutes / 60);
			const rest = minutes % 60;
			return rest === 0 ? hours + " 小时" : hours + " 小时 " + rest + " 分";
		}

		function fmtClock(ms) {
			const total = Math.max(0, Math.floor(ms / 1000));
			const m = Math.floor(total / 60);
			const s = total % 60;
			return (m < 10 ? "0" + m : String(m)) + ":" + (s < 10 ? "0" + s : String(s));
		}

		function fmtDay(ts) {
			if (!ts) return "—";
			const d = new Date(ts);
			const pad = (n) => (n < 10 ? "0" + n : String(n));
			return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + " " + pad(d.getHours()) + ":" + pad(d.getMinutes());
		}

		/** 按空行优先、超长按句子切、相邻碎块合并的方式切成可翻译的段。 */
		function splitSegments(text) {
			const norm = String(text || "").replace(/\r\n?/g, "\n");
			const blocks = norm.split(/\n\s*\n/);
			const raw = [];
			for (const block of blocks) {
				const trimmed = block.trim();
				if (trimmed.length > 0) raw.push(trimmed);
			}
			if (raw.length === 0) return [];
			const MAX = 1400;
			const MIN = 220;
			const out = [];
			for (const block of raw) {
				if (block.length <= MAX) { out.push(block); continue; }
				const sentences = block.match(/[^.!?]*[.!?]+\s*|[^.!?]+$/g) || [block];
				let current = "";
				for (const sentence of sentences) {
					if (current.length > 0 && current.length + sentence.length > MAX) { out.push(current.trim()); current = ""; }
					current += sentence;
				}
				if (current.trim().length > 0) out.push(current.trim());
			}
			const merged = [];
			for (const piece of out) {
				const prev = merged.length > 0 ? merged[merged.length - 1] : null;
				if (prev !== null && prev.length < MIN && piece.length < MIN) {
					merged[merged.length - 1] = prev + "\n\n" + piece;
					continue;
				}
				merged.push(piece);
			}
			return merged;
		}

		function b64FromBytes(bytes) {
			const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
			const parts = [];
			let chunk = "";
			let i = 0;
			for (; i + 2 < bytes.length; i += 3) {
				const n = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2];
				chunk += chars[(n >> 18) & 63] + chars[(n >> 12) & 63] + chars[(n >> 6) & 63] + chars[n & 63];
				if (chunk.length >= 8192) { parts.push(chunk); chunk = ""; }
			}
			const rest = bytes.length - i;
			if (rest === 1) {
				const n = bytes[i] << 16;
				chunk += chars[(n >> 18) & 63] + chars[(n >> 12) & 63] + "==";
			} else if (rest === 2) {
				const n = (bytes[i] << 16) | (bytes[i + 1] << 8);
				chunk += chars[(n >> 18) & 63] + chars[(n >> 12) & 63] + chars[(n >> 6) & 63] + "=";
			}
			parts.push(chunk);
			return parts.join("");
		}

		/** 兼容 v1/v2（动态插件时期）的数据：旧字段搬进模板 13 栏，补上 progress。 */
		function migratePaper(paper) {
			const out = Object.assign({}, paper);
			for (const id of COL_IDS) if (typeof out[id] !== "string") out[id] = "";
			if (out.rank === "") {
				const bits = [];
				if (paper.jcr) bits.push("JCR " + paper.jcr);
				if (paper.cas) bits.push("中科院 " + paper.cas);
				out.rank = bits.join(" / ");
			}
			if (out.published === "") out.published = typeof paper.year === "string" ? paper.year : "";
			if (out.results === "") out.results = typeof paper.conclusion === "string" ? paper.conclusion : "";
			if (out.dataSource === "") out.dataSource = typeof paper.database === "string" ? paper.database : "";
			if (out.thoughts === "" && paper.steps && typeof paper.steps === "object") {
				const notes = [];
				for (const key of ["pre", "ask", "deep", "crit", "sum"]) {
					const step = paper.steps[key];
					if (step && typeof step.note === "string" && step.note.trim().length > 0) notes.push(step.note);
				}
				out.thoughts = notes.join("\n\n");
			}
			if (out.pdf === undefined) out.pdf = null;
			if (!out.translation || typeof out.translation !== "object") out.translation = { source: "", result: "", segments: [], updatedAt: 0 };
			if (!Array.isArray(out.translation.segments)) out.translation.segments = [];
			if (!Array.isArray(out.translation.picked)) out.translation.picked = [];
			// 勾划篮：攒起来待翻译的勾划（每篇各一个）
			if (!Array.isArray(out.translation.batch)) out.translation.batch = [];
			if (!Array.isArray(out.mindmaps)) out.mindmaps = [];
			if (typeof out.status !== "string" || out.status.length === 0) out.status = "未读";
			for (const key of ["kind", "pmid", "url", "tags"]) if (typeof out[key] !== "string") out[key] = "";
			out.progress = progressOf(out);
			if (out.status === "已完成" && out.progress.percent === 0) out.progress.percent = 100;
			return out;
		}

		function BookIcon(props) {
			const size = props && props.size ? props.size : 18;
			return h("svg", {
				width: size, height: size, viewBox: "0 0 24 24", fill: "none",
				stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round", strokeLinejoin: "round",
			},
				h("path", { d: "M4 4.5h5.5A2.5 2.5 0 0 1 12 7v13a2 2 0 0 0-2-2H4z" }),
				h("path", { d: "M20 4.5h-5.5A2.5 2.5 0 0 0 12 7v13a2 2 0 0 1 2-2h6z" }),
			);
		}

		// ───────────────────────── 插件定义 ─────────────────────────

		exports.inject = ["slots", "layout", "timer"];

		/**
		 * 版式模式的文字层要用到的两个纯函数，放在工厂作用域里（不碰 ctx、没有副作用），
		 * 这样冒烟测试可以直接调它验证坐标换算。
		 */
		/** 文字层里一个小块的位置：viewport.transform × item.transform（手写矩阵乘法，不依赖 pdf.js 内部 API） */
		function textItemBox(item, viewport) {
			const m = item && item.transform;
			const v = viewport && viewport.transform;
			if (!m || m.length < 6 || !v || v.length < 6) return null;
			const c = v[0] * m[2] + v[2] * m[3];
			const d = v[1] * m[2] + v[3] * m[3];
			const e = v[0] * m[4] + v[2] * m[5] + v[4];
			const f = v[1] * m[4] + v[3] * m[5] + v[5];
			const fontHeight = Math.sqrt(c * c + d * d);
			if (!(fontHeight > 0) || !isFinite(fontHeight)) return null;
			if (!isFinite(e) || !isFinite(f)) return null;
			return { left: e, top: f - fontHeight, fontHeight, width: (Number(item.width) || 0) * (Number(viewport.scale) || 1) };
		}

		/** 空白与大小写归一化：用来把 PDF 文字层里的选区对回原文段落 */
		function normText(value) {
			return String(value === null || value === undefined ? "" : value).replace(/\s+/g, " ").trim().toLowerCase();
		}

		/**
		 * 版式模式文字层里，两个文字块之间要不要补一个空格。
		 * 那一层是一堆绝对定位的 span，**中间没有空白字符**，所以跨块选中会粘成
		 * 「adenocarcinomasadenocarcinomathe」。这里按几何间隙判断；中文之间不补。
		 * 放在工厂作用域是为了能被测试直接调（纯函数，没有副作用）。
		 */
		function needsWordSpace(prevText, prev, nextText, next) {
			const a = String(prevText === null || prevText === undefined ? "" : prevText);
			const b = String(nextText === null || nextText === undefined ? "" : nextText);
			if (a.length === 0 || b.length === 0 || !prev || !next) return false;
			const fontHeight = Number(next.fontHeight) || Number(prev.fontHeight) || 10;
			// 不在同一行就不补（换行由 DOM 顺序表达）
			if (Math.abs(Number(prev.top) - Number(next.top)) > Math.max(2, fontHeight * 0.6)) return false;
			const left = a.slice(-1);
			const right = b[0];
			const cjk = (ch) => /[\u2e80-\u9fff\u3000-\u303f\uff00-\uffef]/.test(ch);
			if (cjk(left) || cjk(right)) return false;
			if (/[\s\-/（(\[【]$/.test(left)) return false;
			if (/^[\s).,;:!?\]}）】，。；：！？、]/.test(right)) return false;
			const gap = Number(next.left) - (Number(prev.left) + Number(prev.width));
			// 0.18 个字号：正常词间空格约 0.25–0.33 em，而同一个词被 kern 切成两块时通常 < 0.1 em
			return gap > fontHeight * 0.18;
		}

		// ───────────────────────── 思维导图（纯计算，放这里是为了能被测试直接调）─────────────────────────
		const MIND_ROW = 25;
		const MIND_PAD = 14;
		const MIND_MAX_W = 300;

		/** 粗略估文字宽度：中日韩字符按 12px，其余按 7px（11.5px 字号下够用了） */
		function mindTextWidth(text) {
			let width = 0;
			for (const ch of String(text === null || text === undefined ? "" : text)) {
				width += /[\u2e80-\u9fff\u3000-\u303f\uff00-\uffef]/.test(ch) ? 12 : 7;
			}
			return width;
		}
		/** 太长就截断，保证框装得下（完整文字仍放在 <title> 里可以悬停看） */
		function mindFitLabel(label, maxPx) {
			const text = String(label === null || label === undefined ? "" : label);
			let width = 0;
			let out = "";
			for (const ch of text) {
				const w = /[\u2e80-\u9fff\u3000-\u303f\uff00-\uffef]/.test(ch) ? 12 : 7;
				if (width + w > maxPx - 18) return out + "…";
				width += w;
				out += ch;
			}
			return out;
		}

		/**
		 * 横向树布局：后序遍历定纵向位置（叶子依次排、父节点居中在孩子中间），
		 * 再按「每层最宽的文字」算列宽，避免长标签压到下一层。
		 */
		function mindLayout(tree) {
			const nodes = [];
			let cursor = 0;
			const build = (node, depth) => {
				const kids = (Array.isArray(node && node.children) ? node.children : []).map((child) => build(child, depth + 1));
				const label = String(node && node.label ? node.label : "·");
				const y0 = cursor;
				cursor += MIND_ROW;
				const cy = kids.length === 0 ? y0 + MIND_ROW / 2 : (kids[0].cy + kids[kids.length - 1].cy) / 2;
				const self = { label, depth, cy, kids, x: 0, w: 0, h: 19, display: label };
				nodes.push(self);
				return self;
			};
			if (tree === null || tree === undefined) return { nodes: [], edges: [], width: 0, height: 0 };
			const root = build(tree, 0);
			const colWidth = [];
			for (const node of nodes) {
				colWidth[node.depth] = Math.max(colWidth[node.depth] || 60, Math.min(MIND_MAX_W, mindTextWidth(node.label) + 20));
			}
			let x = MIND_PAD;
			const colX = [];
			for (let depth = 0; depth < colWidth.length; depth++) {
				colX[depth] = x;
				x += colWidth[depth] + 26;
			}
			const edges = [];
			for (const node of nodes) {
				node.w = colWidth[node.depth] || 60;
				node.x = colX[node.depth] || MIND_PAD;
				node.display = mindFitLabel(node.label, node.w);
				for (const kid of node.kids) edges.push({ from: node, to: kid });
			}
			return { nodes, edges, width: x - 26 + MIND_PAD, height: cursor + MIND_PAD * 2 };
		}

		/** 导图 → 大纲文本（粘进 XMind / 幕布都能直接识别这种缩进） */
		function mindOutline(tree, depth, lines) {
			const pad = "  ".repeat(depth);
			lines.push(pad + (depth === 0 ? "# " : "- ") + String(tree && tree.label ? tree.label : ""));
			for (const child of (tree && Array.isArray(tree.children) ? tree.children : [])) mindOutline(child, depth + 1, lines);
			return lines;
		}
		function mindOutlineText(tree) {
			return mindOutline(tree, 0, []).join("\n");
		}

		// ───────────────────── 阅读位置（切页/切模式后回到原地）─────────────────────
		/**
		 * 位置记成「第几块 + 块内比例」而不是像素：换个窗口宽度、缩放一变，
		 * 每块的高度就变了，只有比例是稳的。
		 */
		function normalizeScroll(raw) {
			const src = raw && typeof raw === "object" ? raw : {};
			const one = (value) => {
				if (!value || typeof value !== "object") return null;
				const i = Number(value.i);
				const r = Number(value.r);
				if (!Number.isFinite(i) || i < 0) return null;
				return { i: Math.floor(i), r: Number.isFinite(r) ? Math.max(0, Math.min(0.999, r)) : 0 };
			};
			return { text: one(src.text), layout: one(src.layout) };
		}

		/** 一串「每块上边距与高度」+ 当前 scrollTop → 最上面那块是谁、块内走了多少 */
		function scrollIndexAt(boxes, scrollTop) {
			const list = Array.isArray(boxes) ? boxes.filter((b) => b && isFinite(b.top) && isFinite(b.height) && b.height > 0) : [];
			if (list.length === 0) return null;
			const base = list[0].top;
			const top = (Number.isFinite(scrollTop) && scrollTop > 0 ? scrollTop : 0) + base;
			let best = 0;
			for (let i = 0; i < list.length; i++) {
				if (list[i].top <= top + 1) best = i;
				else break;
			}
			const box = list[best];
			const r = Math.max(0, Math.min(0.999, (top - box.top) / box.height));
			return { i: best, r: Math.round(r * 1000) / 1000 };
		}

		/** 反过来：{i, r} → 该设成多少 scrollTop */
		function scrollTopFor(boxes, saved) {
			const list = Array.isArray(boxes) ? boxes.filter((b) => b && isFinite(b.top) && isFinite(b.height) && b.height > 0) : [];
			if (list.length === 0 || !saved || !isFinite(saved.i)) return null;
			const box = list[Math.max(0, Math.min(list.length - 1, Math.floor(saved.i)))];
			const r = isFinite(saved.r) ? Math.max(0, Math.min(0.999, saved.r)) : 0;
			return Math.max(0, Math.round(box.top - list[0].top + box.height * r));
		}

		/** 往上找到左半边原文区的容器（文字模式与版式模式都带 lit-reader-text 这个类） */
		function readerTextRoot(node) {
			let n = node;
			while (n && n.nodeType !== 1) n = n.parentNode;
			while (n) {
				if (typeof n.className === "string" && /(^|\s)lit-reader-text(\s|$)/.test(n.className)) return n;
				n = n.parentNode;
			}
			return null;
		}

		/** 只读取原文中的实际文字；无论拖选方向怎样，都排除段号、工具栏和右栏译文。 */
		function readerSelection(selection, expectedRoot) {
			if (!selection || selection.rangeCount === 0 || selection.isCollapsed) return null;
			const root = expectedRoot || readerTextRoot(selection.anchorNode) || readerTextRoot(selection.focusNode);
			if (!root || !root.ownerDocument) return null;
			const range = selection.getRangeAt(0);
			const blocks = root.querySelectorAll(".lit-reader-seg-text, .lit-pdftext");
			const parts = [];
			const segIndices = [];
			const pageNumbers = [];
			for (const block of blocks) {
				if (!range.intersectsNode(block)) continue;
				const walker = root.ownerDocument.createTreeWalker(block, 4);
				const chunks = [];
				let node = null;
				while ((node = walker.nextNode())) {
					if (!range.intersectsNode(node)) continue;
					const start = range.startContainer === node ? range.startOffset : 0;
					const end = range.endContainer === node ? range.endOffset : node.textContent.length;
					if (end > start) chunks.push(node.textContent.slice(start, end));
				}
				const text = chunks.join("").replace(/[\t\r ]+/g, " ").trim();
				if (!text) continue;
				parts.push(text);
				const segment = block.closest("[data-seg]");
				const page = block.closest("[data-page]");
				if (segment) {
					const index = Number(segment.getAttribute("data-seg"));
					if (Number.isInteger(index) && index >= 0 && segIndices.indexOf(index) < 0) segIndices.push(index);
				}
				if (page) {
					const number = Number(page.getAttribute("data-page")) + 1;
					if (Number.isInteger(number) && number > 0 && pageNumbers.indexOf(number) < 0) pageNumbers.push(number);
				}
			}
			if (parts.length === 0) return null;
			return { text: parts.join("\n\n"), segIndex: segIndices.length === 1 ? segIndices[0] : null, segIndices, pageNumbers };
		}

		function selectionMode(ui) {
			return ui && (ui.selectionMode === "manual" || ui.selectionMode === "instant") ? ui.selectionMode : "basket";
		}
		function selectionSourceKey(item) {
			if (item && item.sourceKey) return item.sourceKey;
			if (item && Array.isArray(item.pageNumbers) && item.pageNumbers.length > 0) return "pages:" + item.pageNumbers.join(",");
			if (item && Array.isArray(item.segIndices) && item.segIndices.length > 0) return "segments:" + item.segIndices.join(",");
			return item && Number.isFinite(item.segIndex) ? "segments:" + item.segIndex : "selection";
		}
		function selectionKey(item) {
			return selectionSourceKey(item) + "\u0000" + normText(item && (item.text || item.en));
		}
		function selectionLabel(item) {
			if (item && item.mergedCount > 1) return "合并 " + item.mergedCount + " 条勾画";
			const pages = item && item.pageNumbers;
			if (Array.isArray(pages) && pages.length > 0) return "第 " + (pages.length > 1 ? pages[0] + "–" + pages[pages.length - 1] : pages[0]) + " 页";
			const indices = item && item.segIndices;
			if (Array.isArray(indices) && indices.length > 1) return "第 " + (indices[0] + 1) + "–" + (indices[indices.length - 1] + 1) + " 段";
			return item && Number.isFinite(item.segIndex) ? "第 " + (item.segIndex + 1) + " 段" : "勾画选区";
		}
		function coversWholeSegment(text, segment) {
			return !!segment && normText(text).length > 0 && normText(text) === normText(segment.en);
		}
		function sourceHash(text) {
			let hash = 2166136261;
			for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
			return text.length + ":" + (hash >>> 0).toString(16);
		}

		function applyInner(ctx) {
			if (ctx.slots === undefined) return;

			// 自己的样式表，随插件卸载移除
			ctx.effect(() => {
				if (typeof document === "undefined") return () => {};
				const tag = document.createElement("style");
				tag.dataset.plugin = "dsh-literature-reading";
				tag.textContent = CSS;
				document.head.appendChild(tag);
				return () => { try { tag.remove(); } catch { /* ignore */ } };
			}, "literature-reading: styles");

			/** 同源 HTTP JSON RPC：host 半的 /dsh-litread/rpc。 */
			async function rpc(op, args) {
				let response = null;
				try {
					response = await fetch(RPC_ROUTE, {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({ op, args: args || {} }),
					});
				} catch (error) {
					// 桌面 IPC 暂不可用时，把底层错误转换为可直接理解的提示。
					set({ backendDown: true });
					throw new Error("本地桌面服务暂时不可用（" + errText(error) + "）。请重启应用后重试。");
				}
				if (state.backendDown === true) set({ backendDown: false });
				const text = await response.text();
				try {
					return JSON.parse(text);
				} catch {
					throw new Error("桌面版返回了无法识别的响应（HTTP " + response.status + "）：" + text.slice(0, 200));
				}
			}

			let state = {
				loading: false, error: null, dirty: false, savedAt: 0, loadBroken: false,
				papers: [], drafts: [], activeId: null, tab: "entry", panelOpen: false,
				scratch: { source: "", result: "", segments: [], picked: [] },
				txBusy: false, txError: null, txAnnotate: true,
				txSel: null, txBatch: null, txAbort: false,
				pdfBusy: false, pdfMsg: "", exporting: false, exportMsg: "",
				tick: 0, readingSince: 0, readingPaperId: null, onMainPanel: false,
				// 左右栏折叠（持久化在 data.json 的 ui 里）；uiAuto* 记录「是被自动收起的」
				ui: { left: true, right: true, txHeight: "m", readerMode: "text", split: 50, mindZoom: 100, selectionMode: "basket", selBatch: true, basketOpen: false, taskPanelOpen: false, readerToolsOpen: false, readerPdfControlsOpen: true, readerRightControlsOpen: true, readerAutoSize: true, readerOriginalOpen: true, readerHistoryOpen: false, formGroups: { basic: true, design: false, findings: false, extra: false } }, uiAutoLeft: false, uiAutoRight: false, splitDragging: false,
				sel: null, readerView: null, txStatus: "", readerSelectionOpen: false,
				// 选段总结成思维导图：mindTab=右半边切到导图视图，mindId=当前看的是哪一张
				mindBusy: false, mindErr: "", mindMsg: "", mindTab: false, mindId: null, mindText: "", reextractArmed: false,
				autoFillBusy: false, autoFillPaperId: null, autoFillDraft: null, autoFillStatus: null,
				autoFillBatchDrafts: {}, autoFillBatch: null,
				pdfEvidenceBusy: false, pdfEvidenceStatus: null,
				batchPreview: "",
				armedRemoveId: null,
				backendDown: false,
				taskFeed: [], taskPanelOpen: false, txTaskId: null, paperMutationBusy: false,
				// 版式模式（自己用 pdf.js 画真实页面）：ready=null 表示还没查过本地有没有库
				pdfjsReady: null, pdfjsBusy: false, pdfjsMsg: "", pdfjsErr: "", pdfjsHint: "", pdfjsPages: 0, pdfjsScale: 1,
			};

			const subs = new Set();
			const emit = () => { for (const fn of subs) { try { fn(); } catch { /* ignore */ } } };
			const set = (patch) => {
				if (Object.prototype.hasOwnProperty.call(patch, "activeId") && patch.activeId !== state.activeId) {
					clearNativeSelection();
					patch = Object.assign({ readerView: null, batchPreview: "" }, patch, { sel: null, readerSelectionOpen: false });
				}
				state = Object.assign({}, state, patch);
				emit();
			};
			const taskStopFlags = new Map();
			const taskStopHandlers = new Map();
			let taskSequence = 0;
			/* Host bridge: dispatch window CustomEvent("literature-reader:task", {detail:{id,type,title,status,stage,progress,error,canCancel,cancelLabel}}); progress is 0..100 or null. Tasks update the collapsed summary; opening the details is always a user action. If canCancel is true, the UI emits "literature-reader:task-cancel" with detail {id}; the host must confirm the outcome via another task event. */
			const TASK_EVENT_NAME = "literature-reader:task";
			const taskIsActive = (task) => !!(task && (task.status === "running" || task.status === "stopping"));
			function upsertTask(task) {
				if (!task || typeof task.id !== "string" || task.id.length === 0) return;
				const old = state.taskFeed.find((item) => item.id === task.id) || {};
				const nextTask = Object.assign({}, old, task, { updatedAt: Date.now() });
				const rest = state.taskFeed.filter((item) => item.id !== task.id);
				set({ taskFeed: [nextTask].concat(rest).slice(0, 8) });
			}
			function beginTask(type, title, stage, options) {
				const id = String(type || "task") + "-" + Date.now() + "-" + (++taskSequence);
				taskStopFlags.set(id, false);
				if (options && typeof options.onStop === "function") taskStopHandlers.set(id, options.onStop);
				upsertTask({
					id, type: String(type || "task"), title: String(title || "任务"), status: "running",
					stage: String(stage || "准备中"), progress: null,
					canCancel: !!(options && options.canCancel),
					cancelLabel: options && options.cancelLabel ? String(options.cancelLabel) : "停止等待",
					cancelMode: options && options.cancelMode === "queue" ? "queue" : "drop",
				});
				return id;
			}
			function updateTask(id, patch) {
				if (!id || !state.taskFeed.some((item) => item.id === id)) return;
				upsertTask(Object.assign({}, state.taskFeed.find((item) => item.id === id), patch || {}, { id }));
			}
			function taskStopRequested(id) { return !!(id && taskStopFlags.get(id) === true); }
			function stopTask(id) {
				const task = state.taskFeed.find((item) => item.id === id);
				if (!task || !task.canCancel || task.status !== "running") return;
				taskStopFlags.set(id, true);
				try {
					const handler = taskStopHandlers.get(id);
					if (handler) handler();
					else if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("literature-reader:task-cancel", { detail: { id } }));
				} catch { /* ignore */ }
				const queue = task.cancelMode === "queue";
				updateTask(id, {
					status: "stopping", canCancel: false,
					stage: queue
						? "停止后续排队项，等待当前响应；当前后台请求不会被中止"
						: task.external === true
							? "已请求停止；等待桌面服务确认，后台请求可能仍在继续"
							: "停止等待，迟到结果将丢弃（后台请求仍继续）",
				});
			}
			function finishTask(id, status, stage, error) {
				if (!id) return;
				taskStopFlags.delete(id);
				taskStopHandlers.delete(id);
				const task = state.taskFeed.find((item) => item.id === id);
				if (!task) return;
				updateTask(id, {
					status: status || "success", stage: String(stage || "已完成"),
					progress: status === "success" ? 100 : task.progress,
					canCancel: false, error: error ? String(error) : "",
				});
			}
			function receiveExternalTask(event) {
				const raw = event && event.detail;
				if (!raw || typeof raw.id !== "string" || !raw.id || typeof raw.title !== "string") return;
				const taskId = raw.id.slice(0, 120);
				const validStatuses = ["running", "stopping", "success", "error", "cancelled"];
				const status = validStatuses.indexOf(raw.status) >= 0 ? raw.status : "running";
				const progress = typeof raw.progress === "number" && isFinite(raw.progress)
					? Math.max(0, Math.min(100, raw.progress)) : null;
				upsertTask({
					id: taskId, type: typeof raw.type === "string" ? raw.type.slice(0, 40) : "cloud", external: true, quiet: raw.quiet === true,
					title: raw.title.slice(0, 120), status,
					stage: typeof raw.stage === "string" ? raw.stage.slice(0, 240) : "处理中",
					progress, error: typeof raw.error === "string" ? raw.error.slice(0, 500) : "",
					canCancel: raw.canCancel === true && status === "running",
					cancelLabel: typeof raw.cancelLabel === "string" ? raw.cancelLabel.slice(0, 40) : "停止等待",
				});
				if (status === "success" || status === "error" || status === "cancelled") {
					taskStopFlags.delete(taskId);
					taskStopHandlers.delete(taskId);
				}
			}
			ctx.effect(() => {
				if (typeof window === "undefined") return () => {};
				window.addEventListener(TASK_EVENT_NAME, receiveExternalTask);
				return () => window.removeEventListener(TASK_EVENT_NAME, receiveExternalTask);
			}, "literature-reading: task events");
			function beginTranslationTask(title, stage, options) {
				const id = beginTask("translation", title, stage, Object.assign({ canCancel: true, cancelLabel: "停止等待" }, options || {}));
				set({ txTaskId: id });
				return id;
			}
			function finishTranslationTask(id, status, stage, error) {
				finishTask(id, status, stage, error);
				if (state.txTaskId === id) set({ txTaskId: null, txBusy: false, txBatch: null });
			}
			function taskPaperStillActive(paperId) {
				if (state.paperMutationBusy) return false;
				return paperId === null ? activePaper() === null : !!state.papers.find((paper) => paper && paper.id === paperId) && activePaper() && activePaper().id === paperId;
			}
			function segmentStillMatches(paperId, id, en, zh) {
				let list = null;
				if (paperId === null) list = state.scratch && Array.isArray(state.scratch.segments) ? state.scratch.segments : [];
				else {
					const paper = state.papers.find((item) => item && item.id === paperId);
					list = paper && paper.translation && Array.isArray(paper.translation.segments) ? paper.translation.segments : [];
				}
				const current = list.find((item) => item && item.id === id);
				return !!current && current.en === en && String(current.zh || "") === String(zh || "");
			}

			function useStore() {
				const pair = React.useState(0);
				React.useEffect(() => {
					const bump = () => pair[1]((n) => n + 1);
					subs.add(bump);
					return () => { subs.delete(bump); };
				}, []);
				return state;
			}

			// ── 载入与保存 ──

			let loadStarted = false;
			async function ensureLoaded() {
				if (loadStarted) return;
				loadStarted = true;
				set({ loading: true });
				let res = null;
				try {
					res = await rpc("load", {});
				} catch (error) {
					set({ loading: false, error: "读取失败：" + errText(error) });
					return;
				}
				if (!res || res.ok !== true) {
					set({ loading: false, error: "读取失败：" + ((res && res.error) || "unknown") });
					return;
				}
				let data = null;
				let loadBroken = false;
				if (res.exists === true && res.text) {
					// 手工编辑过的 JSON 可能带 UTF-8 BOM，JSON.parse 会直接抛错；
					// 一旦被当成"没有数据"，下一次保存就会把整份数据覆盖掉 —— 先剥 BOM，
					// 真解析不了就暂停自动保存，宁可不动也不能写没。
					const text = String(res.text).replace(/^\uFEFF/, "");
					try {
						data = JSON.parse(text);
					} catch (error) {
						data = null;
						loadBroken = true;
					}
				}
				const rawPapers = data && Array.isArray(data.papers) ? data.papers : [];
				const papers = rawPapers.map(migratePaper);
				const drafts = data && Array.isArray(data.drafts) ? data.drafts : [];
				const savedUi = data && data.ui && typeof data.ui === "object" ? data.ui : null;
				const savedGroups = savedUi && savedUi.formGroups && typeof savedUi.formGroups === "object" ? savedUi.formGroups : {};
				const mode = selectionMode(savedUi);
				const ui = { left: !savedUi || savedUi.left !== false, right: !savedUi || savedUi.right !== false, txHeight: savedUi && typeof savedUi.txHeight === "string" ? savedUi.txHeight : "m", readerMode: savedUi && (savedUi.readerMode === "pdf" || savedUi.readerMode === "layout") ? savedUi.readerMode : "text", split: splitClamp(savedUi && savedUi.split), mindZoom: mindZoomClamp(savedUi && savedUi.mindZoom), selectionMode: mode, selBatch: mode === "basket", basketOpen: savedUi && savedUi.basketOpen === true, taskPanelOpen: savedUi && savedUi.taskPanelOpen === true, readerToolsOpen: savedUi && savedUi.readerToolsOpen === true, readerPdfControlsOpen: !savedUi || savedUi.readerPdfControlsOpen !== false, readerRightControlsOpen: !savedUi || savedUi.readerRightControlsOpen !== false, readerAutoSize: !savedUi || savedUi.readerAutoSize !== false, readerOriginalOpen: !savedUi || savedUi.readerOriginalOpen !== false, readerHistoryOpen: savedUi && savedUi.readerHistoryOpen === true, formGroups: { basic: savedGroups.basic !== false, design: savedGroups.design === true, findings: savedGroups.findings === true, extra: savedGroups.extra === true } };
				// 显示真实的数据文件位置（host 半 load 会回传），换台机器也是对的
				if (typeof res.path === "string" && res.path.length > 0) shownDataPath = res.path;
				set({
					loading: false, papers, drafts, ui,
					taskPanelOpen: state.taskFeed.length > 0 ? state.taskPanelOpen : ui.taskPanelOpen,
					activeId: papers.length > 0 ? papers[0].id : null,
					loadBroken,
					error: loadBroken ? "数据文件解析失败，已暂停自动保存以免覆盖：" + shownDataPath : null,
				});
			}

			let pendingSave = null;
			async function flush() {
				// 数据文件读不出来时绝不写回：那会把还存在的文件覆盖成空列表
				if (state.loadBroken === true) { set({ dirty: false }); return; }
				const payload = JSON.stringify({ version: 4, updatedAt: Date.now(), papers: state.papers, drafts: state.drafts, ui: state.ui });
				let res = null;
				try {
					res = await rpc("save", { text: payload });
				} catch (error) {
					set({ error: "保存失败：" + errText(error) });
					return;
				}
				if (res && res.ok === true) set({ dirty: false, savedAt: Date.now(), error: null });
				else set({ error: "保存失败：" + ((res && res.error) || "unknown") });
			}
			function scheduleSave() {
				if (pendingSave !== null) { try { pendingSave(); } catch { /* ignore */ } }
				pendingSave = ctx.timeout(() => { pendingSave = null; flush(); }, 700);
				set({ dirty: true });
			}
			async function flushBeforeClose() {
				if (pendingSave !== null) {
					try { pendingSave(); } catch { /* ignore */ }
					pendingSave = null;
				}
				// A broken source file cannot be overwritten. Closing is safe only when
				// the paused autosave has no unsaved edits to discard.
				if (state.loadBroken === true) {
					return state.dirty !== true;
				}
				if (state.dirty !== true) return true;
				try {
					await flush();
					return state.dirty !== true;
				} catch {
					return false;
				}
			}
			ctx.effect(() => () => { if (pendingSave !== null) { try { pendingSave(); } catch { /* ignore */ } } });

			// ── 数据变更 ──

			const patchPaper = (id, patch) => {
				if (state.paperMutationBusy) return;
				set({ papers: state.papers.map((p) => (p.id === id ? Object.assign({}, p, patch) : p)) });
				scheduleSave();
			};
			async function requestAutoFillDraft(paper, taskId) {
				if (taskId) updateTask(taskId, { stage: "从 PDF 抽取正文：" + (paper.title || paper.pdf.name), progress: null });
				const extracted = await rpc("reextract", { name: paper.pdf.name });
				if (taskStopRequested(taskId)) return null;
				if (!extracted || extracted.ok !== true) throw new Error((extracted && extracted.error) || "读取 PDF 正文失败。");
				const source = typeof extracted.text === "string" ? extracted.text.trim() : "";
				if (!source) throw new Error("这份 PDF 没有可识别的文字；扫描版 PDF 暂不支持自动填表。");
				if (taskId) updateTask(taskId, { stage: "发送正文到 DeepSeek，等待识别结果", progress: null });
				const result = await rpc("autoFillTable", { text: source, title: paper.title || "" });
				if (taskStopRequested(taskId)) return null;
				if (!result || result.ok !== true) throw new Error((result && result.error) || "AI 识别失败。");
				const values = result.values && typeof result.values === "object" ? result.values : {};
				const evidence = result.evidence && typeof result.evidence === "object" ? result.evidence : {};
				const fields = {};
				const selected = {};
				const current = state.papers.find((item) => item && item.id === paper.id) || paper;
				for (const column of COLUMNS) {
					const value = typeof values[column.id] === "string" ? values[column.id].trim() : "";
					const quote = typeof evidence[column.id] === "string" ? evidence[column.id].trim() : "";
					fields[column.id] = { value, evidence: quote };
					selected[column.id] = value.length > 0 && !(typeof current[column.id] === "string" && current[column.id].trim());
				}
				const count = COLUMNS.filter((column) => fields[column.id].value.length > 0).length;
				return {
					draft: { paperId: paper.id, fields, selected, model: typeof result.model === "string" ? result.model : "deepseek-chat" },
					count,
				};
			}
			async function autoFillPaper(paper) {
				if (state.paperMutationBusy) { set({ autoFillStatus: { paperId: paper && paper.id, kind: "error", text: "本机文献正在移入回收站，请稍后再识别。" } }); return; }
				if (!paper || !paper.pdf || !paper.pdf.name) {
					set({ autoFillStatus: { paperId: paper && paper.id, kind: "error", text: "请先为这篇文献导入 PDF。" } });
					return;
				}
				if (state.autoFillBusy || (state.autoFillBatch && state.autoFillBatch.stage === "running")) return;
				const taskId = beginTask("auto-fill", "自动填表：" + (paper.title || "未命名文献"), "准备读取 PDF", { canCancel: true, cancelLabel: "停止等待" });
				set({ autoFillBusy: true, autoFillPaperId: paper.id, autoFillDraft: null, autoFillStatus: { paperId: paper.id, kind: "busy", text: "正在读取 PDF 并识别表格…" } });
				try {
					const generated = await requestAutoFillDraft(paper, taskId);
					if (taskStopRequested(taskId) || generated === null) {
						set({ autoFillDraft: null, autoFillStatus: { paperId: paper.id, kind: "error", text: "已停止等待，迟到识别结果已丢弃（后台请求仍继续）。" } });
						finishTask(taskId, "cancelled", "迟到识别结果已丢弃（后台请求仍继续）");
						return;
					}
					set({
						autoFillDraft: generated.draft,
						autoFillStatus: { paperId: paper.id, kind: "success", text: "已优先检索 PDF 正文前后各 1000 字；长文再补充检索摘要、方法、结果和讨论/结论段。识别 " + generated.count + " 栏；请检查预览后再填入。" },
					});
					finishTask(taskId, "success", "识别完成，已生成待核对预览");
				} catch (error) {
					const stopped = taskStopRequested(taskId);
					set({ autoFillDraft: null, autoFillStatus: { paperId: paper.id, kind: "error", text: stopped ? "已停止等待，识别结果将丢弃（后台请求仍继续）。" : "自动填表失败：" + errText(error) } });
					finishTask(taskId, stopped ? "cancelled" : "error", stopped ? "停止等待；后台请求仍继续" : "自动填表失败", stopped ? "" : errText(error));
				} finally {
					set({ autoFillBusy: false, autoFillPaperId: null });
				}
			}
			async function startAutoFillBatch(ids) {
				if (state.paperMutationBusy) { set({ txStatus: "本机文献正在移入回收站，请稍后再批量识别。" }); return; }
				if (state.autoFillBusy || (state.autoFillBatch && state.autoFillBatch.stage === "running")) return;
				const uniqueIds = Array.from(new Set(Array.isArray(ids) ? ids : [])).filter((id) => {
					const paper = state.papers.find((item) => item && item.id === id);
					return !!(paper && paper.pdf && paper.pdf.name);
				});
				if (uniqueIds.length === 0) return;
				const taskId = beginTask("auto-fill-batch", "批量自动填表（" + uniqueIds.length + " 篇）", "等待第 1 篇", { canCancel: true, cancelMode: "queue", cancelLabel: "停止排队" });
				set({ autoFillBusy: true, autoFillPaperId: null, autoFillBatch: { ids: uniqueIds, processed: 0, currentPaperId: null, stage: "running", successes: [], failures: [] } });
				for (let index = 0; index < uniqueIds.length; index++) {
					if (taskStopRequested(taskId)) break;
					const paperId = uniqueIds[index];
					let paper = state.papers.find((item) => item && item.id === paperId);
					updateTask(taskId, { stage: "识别第 " + (index + 1) + " / " + uniqueIds.length + " 篇：" + (paper && paper.title || "文献"), progress: Math.round((index / uniqueIds.length) * 100) });
					set({ autoFillBatch: Object.assign({}, state.autoFillBatch, { currentPaperId: paperId }) });
					try {
						if (!paper || !paper.pdf || !paper.pdf.name) throw new Error("文献或 PDF 已移除。");
						if (getAutoFillDraft(paperId)) throw new Error("这篇文献已有待审阅预览；请先填入或取消预览，再重新识别。");
						const generated = await requestAutoFillDraft(paper, taskId);
						if (taskStopRequested(taskId) || generated === null) break;
						paper = state.papers.find((item) => item && item.id === paperId);
						if (!paper || !paper.pdf || !paper.pdf.name) throw new Error("识别期间文献或 PDF 已移除，结果未保存。");
						const currentDraft = generated.draft;
						for (const column of COLUMNS) {
							currentDraft.selected[column.id] = currentDraft.fields[column.id].value.length > 0 && !(typeof paper[column.id] === "string" && paper[column.id].trim());
						}
						const batchDrafts = Object.assign({}, state.autoFillBatchDrafts, { [paperId]: currentDraft });
						const batch = Object.assign({}, state.autoFillBatch, { processed: index + 1, successes: state.autoFillBatch.successes.concat([paperId]) });
						set({ autoFillBatchDrafts: batchDrafts, autoFillBatch: batch });
					} catch (error) {
						if (taskStopRequested(taskId)) break;
						const failure = { paperId, title: paper && paper.title || "（文献已移除）", error: errText(error) };
						const batch = Object.assign({}, state.autoFillBatch, { processed: index + 1, failures: state.autoFillBatch.failures.concat([failure]) });
						set({ autoFillBatch: batch });
					}
				}
				const stopped = taskStopRequested(taskId);
				set({
					autoFillBusy: false, autoFillPaperId: null,
					autoFillBatch: Object.assign({}, state.autoFillBatch, { currentPaperId: null, stage: stopped ? "stopped" : "complete" }),
				});
				if (stopped) finishTask(taskId, "cancelled", "已停止后续识别；已生成的预览保留");
				else if (state.autoFillBatch && state.autoFillBatch.failures && state.autoFillBatch.failures.length > 0) {
					const completed = state.autoFillBatch.processed || 0;
					finishTask(taskId, "error", "处理 " + completed + " 篇，" + state.autoFillBatch.failures.length + " 篇失败；失败项可查看详情", state.autoFillBatch.failures.map((item) => item.error).join("；").slice(0, 500));
				} else finishTask(taskId, "success", "全部 " + uniqueIds.length + " 篇已生成待核对预览");
			}
			function getAutoFillDraft(paperId) {
				if (state.autoFillDraft && state.autoFillDraft.paperId === paperId) return state.autoFillDraft;
				return state.autoFillBatchDrafts && state.autoFillBatchDrafts[paperId] || null;
			}
			function updateAutoFillDraft(paperId, updater) {
				const current = getAutoFillDraft(paperId);
				if (!current) return;
				const next = updater(current);
				if (state.autoFillDraft && state.autoFillDraft.paperId === paperId) {
					set({ autoFillDraft: next });
					return;
				}
				set({ autoFillBatchDrafts: Object.assign({}, state.autoFillBatchDrafts, { [paperId]: next }) });
			}
			function removeAutoFillDraft(paperId) {
				const batchDrafts = Object.assign({}, state.autoFillBatchDrafts);
				delete batchDrafts[paperId];
				set({
					autoFillDraft: state.autoFillDraft && state.autoFillDraft.paperId === paperId ? null : state.autoFillDraft,
					autoFillBatchDrafts: batchDrafts,
				});
			}
			function editAutoFillDraft(paperId, fieldId, patch) {
				updateAutoFillDraft(paperId, (draft) => {
					const fields = Object.assign({}, draft.fields);
					const next = Object.assign({}, fields[fieldId], patch);
					if (Object.prototype.hasOwnProperty.call(patch, "value") && patch.value !== fields[fieldId].value) next.evidence = "";
					fields[fieldId] = next;
					return Object.assign({}, draft, { fields });
				});
			}
			function selectAutoFillField(paperId, fieldId, selected) {
				updateAutoFillDraft(paperId, (draft) => {
					const selection = Object.assign({}, draft.selected, { [fieldId]: selected });
					return Object.assign({}, draft, { selected: selection });
				});
			}
			function applyAutoFillDraft(paper) {
				if (state.paperMutationBusy) { set({ autoFillStatus: { paperId: paper && paper.id, kind: "error", text: "本机文献正在移入回收站，请稍后再应用自动填表结果。" } }); return; }
				const draft = getAutoFillDraft(paper.id);
				if (!draft) return;
				const current = state.papers.find((item) => item.id === paper.id);
				if (!current) return;
				const patch = {};
				const provenance = Object.assign({}, current.aiEvidence && typeof current.aiEvidence === "object" ? current.aiEvidence : {});
				for (const column of COLUMNS) {
					const field = draft.fields[column.id];
					if (!draft.selected[column.id] || !field || !field.value || (current[column.id] || "").trim()) continue;
					patch[column.id] = field.value;
					if (field.evidence) provenance[column.id] = { quote: field.evidence, model: draft.model, updatedAt: Date.now(), pdfName: current.pdf && current.pdf.name || "" };
					else delete provenance[column.id];
				}
			const count = Object.keys(patch).length;
				if (count > 0) {
					patch.aiEvidence = provenance;
					patchPaper(paper.id, patch);
					set({ autoFillStatus: { paperId: paper.id, kind: "success", text: "已填入 " + count + " 个空白栏；原有内容未覆盖。" } });
					removeAutoFillDraft(paper.id);
				} else {
					set({ autoFillStatus: { paperId: paper.id, kind: "info", text: "没有选中可填入的空白栏；已有内容没有改动。" } });
					removeAutoFillDraft(paper.id);
				}
			}
			function discardAutoFillDraft(paperId) {
				removeAutoFillDraft(paperId);
			}
			const addPaper = () => {
				if (state.paperMutationBusy) { set({ txStatus: "本机文献正在移入回收站，请稍后再新建文献" }); return; }
				const paper = blankPaper();
				set({ papers: [paper].concat(state.papers), activeId: paper.id, tab: "entry" });
				scheduleSave();
			};
			const removePaper = async (id, name) => {
				if (state.paperMutationBusy) return;
				if (!state.papers.some((paper) => paper && paper.id === id)) return;
				if (state.txBusy || state.mindBusy || state.pdfBusy || state.autoFillBusy) {
					set({ armedRemoveId: null, txStatus: "当前还有文献处理任务，请等它完成后再移入回收站。" });
					return;
				}
				const taskId = beginTask("local-trash", "移入回收站：" + (name || "文献"), "保存当前文献数据", { canCancel: false });
				set({ paperMutationBusy: true, txError: null, txStatus: "正在把《" + (name || "文献") + "》移入回收站…" });
				try {
					if (state.loadBroken) throw new Error("本机数据文件解析失败，已暂停写入；请先修复或备份文件后再删除文献。");
					if (pendingSave !== null) { try { pendingSave(); } catch { /* ignore */ } pendingSave = null; }
					if (state.dirty) await flush();
					if (state.dirty) throw new Error(state.error || "当前修改还没有保存成功，文献未移入回收站。");
					updateTask(taskId, { stage: "将文献记录安全移入回收站" });
					const result = await rpc("movePaperToTrash", { paperId: id });
					if (!result || result.ok !== true) throw new Error((result && result.error) || "移入回收站失败。");
					const rest = state.papers.filter((paper) => paper.id !== id);
					set({
						papers: rest,
						activeId: state.activeId === id ? (rest.length > 0 ? rest[0].id : null) : state.activeId,
						armedRemoveId: null,
						txStatus: "已移入回收站：《" + (name || "文献") + "》。可在顶部“本地数据”中恢复；PDF 原件仍保留在本机。",
					});
					finishTask(taskId, "success", "已移入本机回收站，可从“本地数据”恢复");
				} catch (error) {
					const message = errText(error);
					set({ armedRemoveId: null, txError: "移入回收站失败：" + message, txStatus: "原文献仍保留在文献库中。" });
					finishTask(taskId, "error", "移入回收站失败；原文献仍保留", message);
				} finally {
					set({ paperMutationBusy: false });
					if (state.dirty) scheduleSave();
				}
			};
			/**
			 * 两段式移除：第一次点只是「上膛」，再点一次才真删。
			 * 删一篇会连带 13 栏内容、译文、导图、阅读进度，一键直删太容易手滑。
			 */
			function askRemovePaper(paper) {
				if (!paper || typeof paper.id !== "string") return;
				if (state.paperMutationBusy) { set({ txStatus: "本机文献正在移入回收站，请稍后再操作。" }); return; }
				const name = paper.title || "（未命名文献）";
				if (state.armedRemoveId !== paper.id) {
					const segs = Array.isArray(paper.translation && paper.translation.segments) ? paper.translation.segments.length : 0;
					const minds = Array.isArray(paper.mindmaps) ? paper.mindmaps.length : 0;
					set({
						armedRemoveId: paper.id, txError: null,
						txStatus: "再点一次就会移除《" + name + "》（" + filledCount(paper) + "/13 栏已填"
							+ (segs > 0 ? " · " + segs + " 段" : "") + (minds > 0 ? " · " + minds + " 张导图" : "")
							+ "会一起删掉；PDF 原件仍留在数据目录里）",
					});
					return;
				}
				void removePaper(paper.id, name);
			}
			const addDraft = () => {
				const draft = { id: uid("d"), source: SOURCES[0], title: "", note: "", date: new Date().toISOString().slice(0, 10) };
				set({ drafts: [draft].concat(state.drafts), tab: "drafts" });
				scheduleSave();
			};
			const patchDraft = (id, patch) => {
				set({ drafts: state.drafts.map((d) => (d.id === id ? Object.assign({}, d, patch) : d)) });
				scheduleSave();
			};
			const removeDraft = (id) => {
				set({ drafts: state.drafts.filter((d) => d.id !== id) });
				scheduleSave();
			};

			const activePaper = () => state.papers.find((p) => p.id === state.activeId) || null;

			// ── 阅读进度：计时 + 落盘 ──

			/** 阅读计时只统计「正在读这篇」的墙钟时间：整页工作台打开或浮动画板打开，且选中了某篇。 */
			function readingTicking() {
				const visible = typeof document === "undefined" || document.visibilityState !== "hidden";
				if (!visible) return false;
				return (state.panelOpen === true || state.onMainPanel === true) && state.papers.some((p) => p.id === state.activeId);
			}

			function applyReadingTime(ms) {
				const id = state.readingPaperId;
				if (id === null || ms <= 0) return;
				const paper = state.papers.find((p) => p.id === id);
				if (!paper) return;
				const progress = progressOf(paper);
				const minutes = Math.min(ms / 60000, 30);
				const next = Object.assign({}, progress, {
					minutes: Math.round((progress.minutes + minutes) * 100) / 100,
					lastReadAt: Date.now(),
					firstReadAt: progress.firstReadAt || Date.now(),
				});
				patchPaper(id, { progress: next });
			}

			function flushReadingTime() {
				if (state.readingPaperId === null || state.readingSince === 0) return;
				const elapsed = Date.now() - state.readingSince;
				set({ readingSince: Date.now() });
				if (elapsed > 2000) applyReadingTime(elapsed);
			}

			function setProgress(paperId, patch) {
				const paper = state.papers.find((p) => p.id === paperId);
				if (!paper) return;
				const progress = progressOf(paper);
				const next = Object.assign({}, progress, patch);
				if (next.percent !== progress.percent) {
					const log = progress.log.slice(0, 49);
					log.unshift({ at: Date.now(), minutes: next.minutes, percent: next.percent });
					next.log = log;
				}
				patchPaper(paperId, { progress: next });
			}

			function markFinished(paperId) {
				const paper = state.papers.find((p) => p.id === paperId);
				if (!paper) return;
				const progress = progressOf(paper);
				patchPaper(paperId, {
					status: "已完成",
					progress: Object.assign({}, progress, {
						percent: 100,
						finishedAt: Date.now(),
						lastReadAt: Date.now(),
						log: [{ at: Date.now(), minutes: progress.minutes, percent: 100 }].concat(progress.log.slice(0, 49)),
					}),
				});
			}

			// 每 15 秒把本次阅读时长落盘，并在面板开着时驱动秒表显示。
			// 不阅读时什么都不做 —— 否则每秒 set() 会把整棵工作台树重渲染一遍。
			ctx.interval(() => {
				if (!readingTicking()) {
					if (state.readingSince !== 0) {
						flushReadingTime();
						set({ readingPaperId: null, readingSince: 0 });
					}
					return;
				}
				// 换了篇文献：先把上一篇的时长结算掉，再开始新的一篇
				if (state.readingPaperId !== null && state.readingPaperId !== state.activeId) flushReadingTime();
				if (state.readingPaperId !== state.activeId || state.readingSince === 0) {
					set({ readingPaperId: state.activeId, readingSince: Date.now() });
				}
				const tick = state.tick + 1;
				if (tick % 15 === 0) flushReadingTime();
				set({ tick });
			}, 1000);

			// 页面关闭/切走前尽量把时长写回
			ctx.effect(() => {
				if (typeof window === "undefined") return () => {};
				const onHide = () => { if (readingTicking()) flushReadingTime(); };
				window.addEventListener("pagehide", onHide);
				document.addEventListener("visibilitychange", onHide);
				return () => {
					window.removeEventListener("pagehide", onHide);
					document.removeEventListener("visibilitychange", onHide);
				};
			}, "literature-reading: reading clock");

			// ── 翻译 ──

			function txBox() {
				const paper = activePaper();
				if (paper !== null) {
					const tx = paper.translation && typeof paper.translation === "object" ? paper.translation : {};
					return Object.assign({ source: "", result: "", segments: [], picked: [] }, tx);
				}
				return Object.assign({ source: "", result: "", segments: [], picked: [] }, state.scratch);
			}
			const txSource = () => txBox().source || "";
			const txResult = () => txBox().result || "";
			const segsOf = () => {
				const box = txBox();
				return Array.isArray(box.segments) ? box.segments : [];
			};
			function txWrite(patch) {
				const paper = activePaper();
				if (paper !== null) patchPaper(paper.id, { translation: Object.assign(txBox(), patch) });
				else set({ scratch: Object.assign({ source: "", result: "", segments: [], picked: [] }, state.scratch, patch) });
			}
			const setSegments = (arr) => txWrite({ segments: arr });
			const updateSegment = (id, patch) => setSegments(segsOf().map((x) => (x.id === id ? Object.assign({}, x, patch) : x)));
			const removeSegment = (id) => setSegments(segsOf().filter((x) => x.id !== id));
			const clearSegments = () => setSegments([]);

			function buildContext(segs, id) {
				const idx = segs.findIndex((x) => x.id === id);
				if (idx <= 0) return "";
				const prev = segs[idx - 1];
				let out = prev.en || "";
				if (prev.zh && prev.zh.trim().length > 0) out += "\n\n（上一段的中文译文）\n" + prev.zh;
				return out.slice(-1600);
			}

			/** 按分段 id 翻一段（原文框里「翻译选中段」用）；对照精读页按下标翻的叫 translateSegmentAt */
			async function translateOne(id) {
				if (state.paperMutationBusy) { set({ txError: "本机文献正在移入回收站，请稍后再翻译。" }); return; }
				if (state.txBusy) return;
				const segs = segsOf();
				const seg = segs.find((x) => x.id === id);
				if (!seg) return;
				if (!seg.en || seg.en.trim().length === 0) { set({ txError: "这一段是空的" }); return; }
				const paper = activePaper();
				const paperId = paper ? paper.id : null;
				const originalEn = seg.en;
				const originalZh = seg.zh || "";
				const taskId = beginTranslationTask("翻译一段", "等待模型响应");
				set({ txBusy: true, txError: null, txBatch: { done: 0, total: 1 } });
				let res = null;
				try {
					res = await rpc("translate", { text: seg.en, annotate: state.txAnnotate, context: buildContext(segs, id) });
				} catch (error) {
					const stopped = taskStopRequested(taskId);
					set({ txBusy: false, txBatch: null, txError: stopped ? null : "翻译失败：" + errText(error) });
					finishTranslationTask(taskId, stopped ? "cancelled" : "error", stopped ? "已停止等待；后台请求仍继续" : "翻译失败", stopped ? "" : errText(error));
					return;
				}
				if (taskStopRequested(taskId)) {
					set({ txBusy: false, txBatch: null, txError: null, txStatus: "已停止等待，迟到译文已丢弃（后台请求仍继续）" });
					finishTranslationTask(taskId, "cancelled", "迟到译文已丢弃（后台请求仍继续）");
					return;
				}
				if (!res || res.ok !== true) {
					const message = (res && res.error) || "unknown";
					set({ txBusy: false, txBatch: null, txError: "翻译失败：" + message });
					finishTranslationTask(taskId, "error", "翻译失败", message);
					return;
				}
				if (!taskPaperStillActive(paperId) || !segmentStillMatches(paperId, id, originalEn, originalZh)) {
					set({ txBusy: false, txBatch: null, txStatus: "原文或译文已更改，迟到译文未写入" });
					finishTranslationTask(taskId, "cancelled", "检测到文献/内容已更改，迟到译文未写入");
					return;
				}
				setSegments(segsOf().map((x) => (x.id === id ? Object.assign({}, x, { zh: res.text }) : x)));
				set({ txBusy: false, txBatch: null });
				finishTranslationTask(taskId, "success", "已写入译文");
			}

			function translateSelection() {
				if (state.paperMutationBusy) { set({ txError: "本机文献正在移入回收站，请稍后再翻译。" }); return; }
				if (state.txBusy) { set({ txError: "已有翻译任务正在处理，请稍后再试" }); return; }
				const src = txSource();
				const sel = state.txSel;
				if (!sel || sel.end <= sel.start) { set({ txError: "先在原文框里选中要翻译的那一段" }); return; }
				const start = Math.max(0, Math.min(sel.start, src.length));
				const end = Math.max(0, Math.min(sel.end, src.length));
				const text = src.slice(start, end).trim();
				if (text.length === 0) { set({ txError: "选中的是空白" }); return; }
				const seg = { id: uid("s"), en: text, zh: "" };
				setSegments(segsOf().concat([seg]));
				set({ txError: null });
				translateOne(seg.id);
			}

			function clearTranslation() {
				txWrite({ source: "", result: "", segments: [], updatedAt: 0 });
				set({ txError: null, txSel: null });
			}

			// ── PDF 导入 ──

			async function importPdfFile(file) {
				if (!file) return;
				if (state.paperMutationBusy) { set({ pdfMsg: "本机文献正在移入回收站，请稍后再导入 PDF。" }); return; }
				if (state.pdfBusy) { set({ pdfMsg: "已有 PDF 导入任务正在处理，请等待完成。" }); return; }
				const activeAtStart = activePaper();
				const targetPaperId = activeAtStart ? activeAtStart.id : null;
				const taskId = beginTask("pdf-import", "导入 " + (file.name || "PDF"), "读取文件内容", { canCancel: true, cancelLabel: "停止等待" });
				set({ pdfBusy: true, pdfMsg: "正在读取 " + (file.name || "PDF") + "…" });
				let bytes = null;
				try {
					bytes = new Uint8Array(await file.arrayBuffer());
				} catch (error) {
					const stopped = taskStopRequested(taskId);
					set({ pdfBusy: false, pdfMsg: stopped ? "已停止等待，文件读取结果已丢弃" : "读取文件失败：" + errText(error) });
					finishTask(taskId, stopped ? "cancelled" : "error", stopped ? "文件读取结果已丢弃" : "读取文件失败", stopped ? "" : errText(error));
					return;
				}
				if (taskStopRequested(taskId)) {
					set({ pdfBusy: false, pdfMsg: "已停止等待，文件读取结果已丢弃" });
					finishTask(taskId, "cancelled", "文件读取结果已丢弃");
					return;
				}
				updateTask(taskId, { stage: "检查 PDF 格式和文件大小", progress: 10 });
				if (bytes.length < 5 || bytes[0] !== 0x25 || bytes[1] !== 0x50 || bytes[2] !== 0x44 || bytes[3] !== 0x46) {
					set({ pdfBusy: false, pdfMsg: "这不是 PDF 文件（开头不是 %PDF）" });
					finishTask(taskId, "error", "文件不是 PDF");
					return;
				}
				if (bytes.length > 32 * 1024 * 1024) {
					set({ pdfBusy: false, pdfMsg: "PDF 超过 32 MB 的导入上限，请压缩文件后再试。" });
					finishTask(taskId, "error", "PDF 超过 32 MB 导入上限");
					return;
				}
				updateTask(taskId, { stage: "调用桌面服务保存 PDF 并抽取正文", progress: 20 });
				set({ pdfMsg: "正在抽取文本（" + Math.round(bytes.length / 1024) + " KB）…" });
				let res = null;
				try {
					res = await rpc("importPdf", { name: file.name || "paper.pdf", base64: b64FromBytes(bytes) });
				} catch (error) {
					const stopped = taskStopRequested(taskId);
					set({ pdfBusy: false, pdfMsg: stopped ? "已停止等待，迟到导入结果将丢弃（后台请求仍继续）" : "导入失败：" + errText(error) });
					finishTask(taskId, stopped ? "cancelled" : "error", stopped ? "停止等待；后台请求仍继续" : "导入失败", stopped ? "" : errText(error));
					return;
				}
				if (taskStopRequested(taskId)) {
					set({ pdfBusy: false, pdfMsg: "已停止等待，迟到导入结果已丢弃（后台请求仍继续）" });
					finishTask(taskId, "cancelled", "迟到导入结果已丢弃（后台请求仍继续）");
					return;
				}
				if (!res || res.ok !== true) {
					const message = (res && res.error) || "unknown";
					set({ pdfBusy: false, pdfMsg: "导入失败：" + message });
					finishTask(taskId, "error", "导入失败", message);
					return;
				}
				updateTask(taskId, { stage: "登记文献和提取结果", progress: 80 });
				const text = typeof res.text === "string" ? res.text : "";
				const info = {
					name: res.name, path: res.path, bytes: res.bytes, pages: res.pages,
					chars: res.chars, confidence: res.confidence, engine: res.engine || "", importedAt: Date.now(),
					lowConfidence: res.lowConfidence === true,
				};
				const existing = targetPaperId === null ? null : state.papers.find((paper) => paper && paper.id === targetPaperId) || null;
				// 导入时就直接切好段：手动「按段落切分」那个按钮已经去掉了，
				// 没有这一步新导入的文献会一段都没有，翻译整条链路就断了
				const freshSegs = splitSegments(text).map((piece) => ({ id: uid("s"), en: piece, zh: "" }));
				if (existing !== null) {
					const base = existing.translation && typeof existing.translation === "object" ? existing.translation : { source: "", result: "", segments: [], updatedAt: 0 };
					const keepSource = typeof base.source === "string" && base.source.trim().length > 0;
					const keepSegs = Array.isArray(base.segments) && base.segments.length > 0;
					patchPaper(existing.id, {
						pdf: info,
						title: existing.title && existing.title.trim().length > 0 ? existing.title : titleFromName(res.name),
						translation: keepSource
							? (keepSegs ? base : Object.assign({}, base, { segments: freshSegs, updatedAt: Date.now() }))
							: Object.assign({}, base, { source: text, segments: freshSegs, updatedAt: Date.now() }),
					});
				} else {
					const paper = blankPaper();
					paper.title = titleFromName(res.name);
					paper.pdf = info;
					paper.translation = { source: text, result: "", segments: freshSegs, picked: [], batch: [], updatedAt: Date.now() };
					paper.progress = Object.assign(blankProgress(), { firstReadAt: Date.now(), lastReadAt: Date.now() });
					set({ papers: [paper].concat(state.papers), activeId: state.activeId === null ? paper.id : state.activeId, tab: state.activeId === null ? "entry" : state.tab });
					scheduleSave();
				}
				let msg;
				if (text.length > 0) {
					msg = "已导入：" + (res.pages ? res.pages + " 页，" : "") + "抽取到 " + text.length + " 字";
					if (freshSegs.length > 0) msg += "，自动切成 " + freshSegs.length + " 段";
					if (res.truncated === true) msg += "（已截断）";
					if (res.lowConfidence === true) msg += "　⚠ 抽出来可能像乱码（可读度 " + res.confidence + "%），已自动试过 pdf.js；建议切「版式」核对，或点「重新抽取文字」";
				} else {
					msg = "PDF 已保存，但没抽出文字（可能是扫描件或图片版 PDF），英文原文请手动粘贴";
				}
				if (res.error) msg = String(res.error);
				set({ pdfBusy: false, pdfMsg: msg });
				finishTask(taskId, "success", "PDF 已导入并登记到文献库");
			}

			/** 从数据目录里的 PDF 原件重新抽一遍文字（抽成乱码、或换了抽取引擎时用） */
			async function reextractPdf() {
				if (state.paperMutationBusy) { set({ txError: "本机文献正在移入回收站，请稍后再抽取 PDF。" }); return; }
				const paper = activePaper();
				if (paper === null) { set({ txError: "先选中一篇文献" }); return; }
				const name = paper.pdf && paper.pdf.name ? String(paper.pdf.name) : "";
				if (name.length === 0) { set({ txError: "这篇还没有导入 PDF" }); return; }
				const hasZh = segsOf().some((x) => x.zh && x.zh.trim().length > 0);
				if (hasZh && state.reextractArmed !== true) {
					set({ reextractArmed: true, txError: null, txStatus: "现有分段里已经有译文：再点一次「重新抽取文字」就会重建分段（PDF 原件不动）" });
					return;
				}
				const paperId = paper.id;
				const translationSignature = JSON.stringify(paper.translation || {});
				const taskId = beginTask("pdf-extract", "重新抽取 PDF 文字", "调用本地服务读取 PDF", { canCancel: true, cancelLabel: "停止等待" });
				set({ reextractArmed: false, txBusy: true, txTaskId: taskId, txError: null, txStatus: "正在重新抽取文字…" });
				let res = null;
				try {
					res = await rpc("reextract", { name });
				} catch (error) {
					const stopped = taskStopRequested(taskId);
					set({ txBusy: false, txTaskId: null, txStatus: stopped ? "已停止等待；后台请求仍继续" : "", txError: stopped ? null : "重新抽取失败：" + errText(error) });
					finishTask(taskId, stopped ? "cancelled" : "error", stopped ? "停止等待；后台请求仍继续" : "重新抽取失败", stopped ? "" : errText(error));
					return;
				}
				if (taskStopRequested(taskId)) {
					set({ txBusy: false, txTaskId: null, txStatus: "已停止等待，迟到抽取结果已丢弃（后台请求仍继续）", txError: null });
					finishTask(taskId, "cancelled", "迟到抽取结果已丢弃（后台请求仍继续）");
					return;
				}
				if (!res || res.ok !== true) {
					const message = (res && res.error) || "unknown";
					set({ txBusy: false, txTaskId: null, txStatus: "", txError: "重新抽取失败：" + message });
					finishTask(taskId, "error", "重新抽取失败", message);
					return;
				}
				const text = typeof res.text === "string" ? res.text : "";
				const engine = res.engine === "pdfjs" ? "pdf.js" : "内置抽取器";
				if (text.trim().length === 0) {
					set({ txBusy: false, txTaskId: null, txStatus: "", txError: "重新抽取还是没拿到文字（扫描件/图片版 PDF 需要手动粘原文）" });
					finishTask(taskId, "error", "未抽取到文字");
					return;
				}
				const latest = state.papers.find((item) => item && item.id === paperId);
				if (!latest || !activePaper() || activePaper().id !== paperId || JSON.stringify(latest.translation || {}) !== translationSignature) {
					set({ txBusy: false, txTaskId: null, txStatus: "文献或笔记内容已更改，迟到抽取结果未写入", txError: null });
					finishTask(taskId, "cancelled", "文献或笔记内容已更改，迟到抽取结果未写入");
					return;
				}
				const known = {};
				const initialSegs = latest.translation && Array.isArray(latest.translation.segments) ? latest.translation.segments : [];
				for (const seg of initialSegs) if (seg.zh) known[seg.en] = seg.zh;
				const segs = splitSegments(text).map((piece) => ({ id: uid("s"), en: piece, zh: known[piece] || "" }));
				patchPaper(paper.id, {
					translation: Object.assign({}, latest.translation || {}, { source: text, segments: segs, updatedAt: Date.now() }),
					pdf: Object.assign({}, latest.pdf, {
						pages: res.pages, chars: res.chars, confidence: res.confidence,
						lowConfidence: res.lowConfidence === true, engine: res.engine || "", extractedAt: Date.now(),
					}),
					progress: Object.assign({}, progressOf(latest), { readSegments: 0, scroll: null }),
				});
				set({
					txBusy: false, txTaskId: null,
					txError: null,
					readerView: null,
					sel: null,
					txStatus: "重新抽取完成：共 " + segs.length + " 段 · 可读度 " + res.confidence + "%（" + engine + "）",
				});
				finishTask(taskId, "success", "重新抽取完成，共 " + segs.length + " 段");
			}

			async function exportTsv() {
				set({ exporting: true, exportMsg: "" });
				const lines = [COLUMNS.map((c) => c.label).join("\t")];
				for (const paper of state.papers) {
					const cells = COLUMNS.map((c) => (typeof paper[c.id] === "string" ? paper[c.id] : "").replace(/\t/g, " ").replace(/\r?\n/g, " "));
					lines.push(cells.join("\t"));
				}
				let res = null;
				try {
					res = await rpc("exportTsv", { text: "\ufeff" + lines.join("\r\n") + "\r\n", name: "文献阅读表格.tsv" });
				} catch (error) {
					set({ exporting: false, exportMsg: "导出失败：" + errText(error) });
					return;
				}
				if (res && res.ok === true) set({ exporting: false, exportMsg: "已导出：" + res.path + "（Excel 可直接打开）" });
				else set({ exporting: false, exportMsg: "导出失败：" + ((res && res.error) || "unknown") });
			}

			function togglePanel() { set({ panelOpen: !state.panelOpen }); }
			function openFullPage() {
				set({ panelOpen: false });
				try { ctx.layout.selectPanel("litread"); } catch { /* ignore */ }
			}

			// ───────────────────────── 基础控件 ─────────────────────────

			function Field(props) {
				return h("div", { className: "lit-field" + (props.wide ? " lit-wide" : "") },
					h("span", { className: "lit-flabel" + (props.empty ? " is-empty" : "") }, props.label),
					props.children);
			}
			function Input(props) {
				return h("input", {
					className: "lit-input", value: props.value || "", placeholder: props.placeholder || "",
					onChange: (e) => props.onChange(e.target.value),
				});
			}
			function Area(props) {
				return h("textarea", {
					className: "lit-textarea" + (props.big ? " lit-textarea-lg" : ""),
					style: props.style || undefined,
					value: props.value || "", placeholder: props.placeholder || "",
					onChange: (e) => props.onChange(e.target.value),
					onSelect: props.onSelect || undefined,
				});
			}
			function Select(props) {
				return h("select", {
					className: "lit-input", value: props.value || "",
					onChange: (e) => props.onChange(e.target.value),
				}, props.options.map((o) => h("option", { key: o, value: o }, o)));
			}
			function PdfPicker(props) {
				return h("label", { className: "lit-btn" + (props.primary ? " lit-btn-primary" : ""), style: { cursor: "pointer" } },
					props.label || "导入 PDF",
					h("input", {
						type: "file", accept: "application/pdf,.pdf", style: { display: "none" },
						onChange: (e) => {
							const file = e.target.files && e.target.files[0];
							if (file) importPdfFile(file);
							e.target.value = "";
						},
					}));
			}

			// ───────────────────────── 进度卡 ─────────────────────────

			function ProgressCard(props) {
				const s = useStore();
				const paper = props.paper;
				const progress = progressOf(paper);
				const reading = s.readingPaperId === paper.id && s.readingSince > 0;
				const sessionMs = reading ? Date.now() - s.readingSince : 0;
				return h("div", { className: "lit-card" },
					h("div", { className: "lit-card-h" },
						"阅读进度",
						h("span", { className: "lit-grow" }),
						progress.percent >= 100 ? h("span", { className: "lit-ok" }, "已读完") : null),
					h("div", { className: "lit-bar" },
						h("div", { className: "lit-bar-fill", style: { width: Math.max(0, Math.min(100, progress.percent)) + "%" } })),
					h("div", { className: "lit-progress-line" }, progress.percent + "%"),
					h("input", {
						className: "lit-range", type: "range", min: 0, max: 100, step: 5,
						value: Math.max(0, Math.min(100, progress.percent)),
						onChange: (e) => setProgress(paper.id, { percent: Number(e.target.value) }),
					}),
					h("div", { className: "lit-float-foot", style: { justifyContent: "flex-start" } },
						[25, 50, 75, 100].map((v) => h("button", {
							key: v, className: "lit-mini",
							onClick: () => setProgress(paper.id, { percent: v }),
						}, v + "%")),
						h("button", {
							className: "lit-mini",
							title: "按已填的模板栏数估算",
							onClick: () => setProgress(paper.id, { percent: Math.round((filledCount(paper) / COLUMNS.length) * 100) }),
						}, "按栏数估算"),
						h("button", { className: "lit-mini", onClick: () => markFinished(paper.id) }, "标记读完")),
					h("div", { className: "lit-progress-line" },
						"本次 " + (reading ? fmtClock(sessionMs) : "00:00") + "　·　累计 " + fmtDuration(progress.minutes * 60000)),
					h("div", { className: "lit-small" }, "上次阅读：" + fmtDay(progress.lastReadAt) + (progress.finishedAt ? "　·　读完于 " + fmtDay(progress.finishedAt) : "")),
					h("div", { className: "lit-small" }, "计时只在「文献面板打开且选中这篇」时走，最多每次计入 30 分钟。"),
					progress.log.length > 0
						? h("div", { className: "lit-log" },
							progress.log.slice(0, 5).map((entry, i) => h("div", { key: i },
								fmtDay(entry.at) + "　" + entry.percent + "%　累计 " + fmtDuration((entry.minutes || 0) * 60000))))
						: null);
			}

			function StatsCard() {
				const s = useStore();
				const now = new Date();
				const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - ((now.getDay() + 6) % 7)).getTime();
				let totalMinutes = 0;
				let weekMinutes = 0;
				let finished = 0;
				let readingNow = 0;
				for (const paper of s.papers) {
					const progress = progressOf(paper);
					totalMinutes += progress.minutes || 0;
					if (progress.lastReadAt >= weekStart) weekMinutes += progress.minutes || 0;
					if (paper.status === "已完成" || progress.percent >= 100) finished++;
					else if ((progress.percent || 0) > 0 || paper.status === "精读中") readingNow++;
				}
				const stats = [
					{ k: "本周阅读", v: fmtDuration(weekMinutes * 60000) },
					{ k: "累计阅读", v: fmtDuration(totalMinutes * 60000) },
					{ k: "已读完", v: finished + " 篇" },
					{ k: "在读", v: readingNow + " 篇" },
					{ k: "文献总数", v: s.papers.length + " 篇" },
					{ k: "泛读记录", v: s.drafts.length + " 条" },
				];
				return h("div", { className: "lit-card" },
					h("div", { className: "lit-card-h" }, "阅读统计"),
					h("div", { className: "lit-stats" }, stats.map((item) => h("div", { key: item.k, className: "lit-stat" },
						h("div", { className: "lit-stat-v" }, item.v),
						h("div", { className: "lit-stat-k" }, item.k)))));
			}

			// ───────────────────────── 逐篇填写 ─────────────────────────

			function EntryForm(props) {
				const paper = props.paper;
				const s = useStore();
				const draft = getAutoFillDraft(paper.id);
				const status = s.autoFillStatus && s.autoFillStatus.paperId === paper.id ? s.autoFillStatus : null;
				const evidenceStatus = s.pdfEvidenceStatus && s.pdfEvidenceStatus.paperId === paper.id ? s.pdfEvidenceStatus : null;
				const suggestions = draft ? COLUMNS.filter((column) => draft.fields[column.id] && draft.fields[column.id].value) : [];
				const fillable = suggestions.filter((column) => !(typeof paper[column.id] === "string" && paper[column.id].trim()));
				const selectedCount = fillable.filter((column) => draft.selected[column.id] && draft.fields[column.id].value.trim()).length;
				const groupOpen = Object.assign({ basic: true, design: false, findings: false, extra: false }, s.ui && s.ui.formGroups ? s.ui.formGroups : {});
				const renderColumn = (column) => {
					const value = typeof paper[column.id] === "string" ? paper[column.id] : "";
					const onChange = (v) => {
						const patch = {}; patch[column.id] = v;
						if (paper.aiEvidence && typeof paper.aiEvidence === "object" && paper.aiEvidence[column.id]) {
							const provenance = Object.assign({}, paper.aiEvidence);
							delete provenance[column.id];
							patch.aiEvidence = provenance;
						}
						patchPaper(paper.id, patch);
					};
					const provenance = paper.aiEvidence && typeof paper.aiEvidence === "object" ? paper.aiEvidence[column.id] : null;
					const source = provenance && typeof provenance.quote === "string" ? provenance.quote : "";
					const control = column.long
						? h(Area, { value, placeholder: column.ph, onChange })
						: h(Input, { value, placeholder: column.ph, onChange });
					return h(Field, { key: column.id, label: column.label, wide: column.wide, empty: value.trim().length === 0 }, control, source ? h("details", { className: "lit-evidence" },
						h("summary", null, "查看 AI 来源依据"),
						h("span", null, source),
						paper.pdf ? h("button", { className: "lit-mini", disabled: s.pdfEvidenceBusy, onClick: () => locateEvidenceOnPdf(paper, source) }, s.pdfEvidenceBusy ? "定位中…" : "定位到 PDF") : null) : null);
				};
				return h("div", { className: "lit-card" },
					h("div", { className: "lit-card-h" },
						"阅读模板 13 栏",
						h("span", { className: "lit-grow" }),
						h("button", {
							className: "lit-btn lit-btn-primary",
							disabled: s.autoFillBusy || !!draft || !paper.pdf || !paper.pdf.name,
							title: draft ? "请先核对、填入或取消当前预览，再重新识别" : paper.pdf ? "从这篇 PDF 提取证据并生成填表草稿" : "请先导入这篇文献的 PDF",
							onClick: () => autoFillPaper(paper),
						}, s.autoFillBusy && s.autoFillPaperId === paper.id ? "识别中…" : draft ? "已有待审阅预览" : "DeepSeek 自动填表")),
					h("div", { className: "lit-small lit-autofill-note" }, "会将当前 PDF 提取出的正文发送到 DeepSeek；先预览核对，只填入你选中的空白栏。"),
					status ? h("div", { className: status.kind === "error" ? "lit-err lit-autofill-status" : status.kind === "success" ? "lit-ok lit-autofill-status" : "lit-small lit-autofill-status" }, status.text) : null,
					evidenceStatus ? h("div", { className: evidenceStatus.kind === "error" ? "lit-err lit-autofill-status" : evidenceStatus.kind === "success" ? "lit-ok lit-autofill-status" : "lit-small lit-autofill-status" }, evidenceStatus.text) : null,
					h("div", { className: "lit-form-groups" }, COLUMN_GROUPS.map((group) => {
						const expanded = groupOpen[group.id] === true;
						const count = group.fields.filter((column) => isFilled(paper, column.id)).length;
						return h("section", { className: "lit-form-group", key: group.id },
							h("button", {
								type: "button", className: "lit-form-group-toggle", "aria-expanded": expanded,
								onClick: () => {
									const formGroups = Object.assign({}, groupOpen, { [group.id]: !expanded });
									set({ ui: Object.assign({}, s.ui, { formGroups }) });
									scheduleSave();
								},
							},
								h("span", { "aria-hidden": "true" }, expanded ? "▾" : "▸"),
								h("span", { className: "lit-form-group-name" }, group.label),
								h("span", { className: "lit-form-group-hint" }, group.hint),
								h("span", { className: "lit-form-group-count" }, count + "/" + group.fields.length + " 已填")),
							expanded ? h("div", { className: "lit-form lit-form-group-fields" }, group.fields.map(renderColumn)) : null);
					})),
					draft ? h("div", { className: "lit-autofill-preview" },
						h("div", { className: "lit-autofill-heading" },
							h("strong", null, "识别结果预览"),
							h("span", { className: "lit-small" }, "只会填入空白栏；原有内容不会被覆盖。请核对原文依据。")),
						fillable.length > 0
							? h("div", { className: "lit-autofill-list" }, fillable.map((column) => {
								const field = draft.fields[column.id];
								return h("div", { key: column.id, className: "lit-autofill-item" },
									h("label", { className: "lit-autofill-choice" },
										h("input", { type: "checkbox", checked: draft.selected[column.id] === true, onChange: (e) => selectAutoFillField(paper.id, column.id, e.target.checked) }),
										h("strong", null, column.label)),
									h("textarea", { className: "lit-autofill-value", value: field.value, onChange: (e) => editAutoFillDraft(paper.id, column.id, { value: e.target.value }) }),
									h("div", { className: "lit-autofill-evidence" }, field.evidence
										? [h("strong", { key: "label" }, "原文依据："), field.evidence, paper.pdf ? h("button", { key: "locate", className: "lit-mini", disabled: s.pdfEvidenceBusy, onClick: () => locateEvidenceOnPdf(paper, field.evidence) }, s.pdfEvidenceBusy ? "定位中…" : "定位到 PDF") : null]
										: "内容已修改，请自行核对"));
							}))
							: h("div", { className: "lit-small" }, suggestions.length ? "这些识别到的栏目已有内容，按保护规则已跳过。" : "没有找到可用的、能在 PDF 原文中核实的栏目；已有内容没有改动。"),
						h("div", { className: "lit-autofill-actions" },
							h("span", { className: "lit-small" }, "分区/影响因子和个人思考通常不在正文中，无法确认时会留空。"),
							h("span", { className: "lit-grow" }),
							h("button", { className: "lit-btn", onClick: () => discardAutoFillDraft(paper.id) }, "取消"),
							h("button", { className: "lit-btn lit-btn-primary", disabled: selectedCount === 0, onClick: () => applyAutoFillDraft(paper) }, "填入已选 " + selectedCount + " 栏"))) : null);
			}

			function ExtraForm(props) {
				const paper = props.paper;
				const [lookupBusy, setLookupBusy] = React.useState(false);
				const [lookupStatus, setLookupStatus] = React.useState(null);
				const up = (patch) => patchPaper(paper.id, patch);
				async function lookupMetadata() {
					const identifier = String(paper.pmid || "").trim();
					if (!identifier) {
						setLookupStatus({ paperId: paper.id, kind: "error", text: "请先在 PMID / DOI 栏填写文献标识符。" });
						return;
					}
					const isDoi = /^(?:(?:https?:\/\/)?(?:dx\.)?doi\.org\/)?10\.\d{4,9}\//i.test(identifier) || /^doi\s*:/i.test(identifier);
					setLookupBusy(true);
					setLookupStatus({ paperId: paper.id, kind: "busy", text: "正在查询 PubMed / Crossref…" });
					try {
						const result = await rpc("lookupMetadata", isDoi ? { doi: identifier } : { pmid: identifier });
						if (!result || result.ok !== true) throw new Error((result && result.error) || "元数据查询失败。");
						const metadata = result.metadata;
						if (!metadata || typeof metadata !== "object") {
							setLookupStatus({ paperId: paper.id, kind: "info", text: "没有查到匹配记录；请检查 PMID / DOI 是否正确。" });
							return;
						}
						const current = state.papers.find((item) => item && item.id === paper.id) || paper;
						const patch = {};
						const labels = [];
						for (const [id, label] of [["title", "标题"], ["journal", "期刊"], ["published", "发表时间"], ["url", "链接"]]) {
							const value = typeof metadata[id] === "string" ? metadata[id].trim() : "";
							if (value && !(typeof current[id] === "string" && current[id].trim())) { patch[id] = value; labels.push(label); }
						}
						if (!(typeof current.kind === "string" && current.kind.trim()) && typeof metadata.kind === "string") {
							const kindText = metadata.kind.toLocaleLowerCase();
							const kind = /meta[\s-]?analysis/.test(kindText) ? "Meta 分析"
								: /review/.test(kindText) ? "综述"
								: /randomi[sz]ed controlled trial|clinical trial/.test(kindText) ? "RCT"
								: /cohort/.test(kindText) ? "队列研究"
								: /original research/.test(kindText) ? "原始研究" : "";
							if (kind) { patch.kind = kind; labels.push("文章类型"); }
						}
						if (!String(current.pmid || "").trim()) {
							const id = metadata.pmid || metadata.doi;
							if (typeof id === "string" && id.trim()) { patch.pmid = id.trim(); labels.push("PMID / DOI"); }
						}
						if (labels.length > 0) {
							patchPaper(paper.id, patch);
							setLookupStatus({ paperId: paper.id, kind: "success", text: "已补充 " + labels.join("、") + "；原有内容未覆盖。" });
						} else {
							setLookupStatus({ paperId: paper.id, kind: "info", text: "查到文献，但可补充的空栏为 0；已有内容未改动。" });
						}
					} catch (error) {
						setLookupStatus({ paperId: paper.id, kind: "error", text: "元数据查询失败：" + errText(error) });
					} finally {
						setLookupBusy(false);
					}
				}
				return h("div", { className: "lit-card" },
					h("div", { className: "lit-card-h" },
						"附加信息（不在模板栏里，但方便检索）",
						h("span", { className: "lit-grow" }),
						h("button", { className: "lit-btn", disabled: lookupBusy, onClick: lookupMetadata }, lookupBusy ? "查询中…" : "按 PMID / DOI 补元数据")),
					h("div", { className: "lit-small" }, "仅向 PubMed / Crossref 查询你填写的 PMID 或 DOI；只补充空白栏，不覆盖已有内容。"),
					lookupStatus && lookupStatus.paperId === paper.id ? h("div", { className: lookupStatus.kind === "error" ? "lit-err lit-autofill-status" : lookupStatus.kind === "success" ? "lit-ok lit-autofill-status" : "lit-small lit-autofill-status" }, lookupStatus.text) : null,
					h("div", { className: "lit-form" },
						h(Field, { label: "阅读状态" }, h(Select, { value: paper.status, options: STATUSES, onChange: (v) => up({ status: v }) })),
						h(Field, { label: "文章类型" }, h(Select, { value: paper.kind || "原始研究", options: KINDS, onChange: (v) => up({ kind: v }) })),
						h(Field, { label: "PMID / DOI" }, h(Input, { value: paper.pmid, placeholder: "PMID 或 DOI", onChange: (v) => up({ pmid: v }) })),
						h(Field, { label: "链接" }, h(Input, { value: paper.url, placeholder: "https://pubmed.ncbi.nlm.nih.gov/…", onChange: (v) => up({ url: v }) })),
						h(Field, { label: "标签", wide: true }, h(Input, { value: paper.tags, placeholder: "逗号分隔，如：MR, 心血管", onChange: (v) => up({ tags: v }) }))));
			}

			function EntryView() {
				const s = useStore();
				React.useEffect(() => { ensureLoaded(); }, []);
				const paper = activePaper();
				if (paper === null) {
					return h("div", { className: "lit-col-main" },
						h("div", { className: "lit-empty" },
							"左侧选一篇文献，或先导入一份 PDF 开始读：",
							h("div", { style: { marginTop: "10px" } }, h(PdfPicker, { primary: true, label: "导入 PDF 自动建一篇" }))));
				}
				return h("div", { className: "lit-col-main" },
					h("div", { className: "lit-paperhead" },
						h("div", { className: "lit-papertitle" }, paper.title || "（未命名文献）"),
						paper.pdf ? h("button", { className: "lit-mini", onClick: () => set({ tab: "translate" }) }, "去翻译") : null,
						h("button", {
							className: "lit-mini" + (s.armedRemoveId === paper.id ? " lit-mini-armed" : ""),
							title: "移除这篇文献（会先让你确认一次）",
							onClick: () => askRemovePaper(paper),
						}, s.armedRemoveId === paper.id ? "确认移除" : "移除这篇")),
					h(ExtraForm, { paper, key: paper.id }),
					h(EntryForm, { paper }));
			}

			// ───────────────────────── 表格总览 ─────────────────────────

			function TableView() {
				useStore();
				React.useEffect(() => { ensureLoaded(); }, []);
				const s = state;
				return h("div", { className: "lit-col-main" },
					h(StatsCard, null),
					h("div", { className: "lit-card" },
						h("div", { className: "lit-card-h" },
							"表格总览（与模板同栏）",
							h("span", { className: "lit-grow" }),
							h("button", { className: "lit-btn", disabled: s.exporting, onClick: exportTsv }, s.exporting ? "导出中…" : "导出 TSV"),
							h("button", { className: "lit-btn lit-btn-primary", onClick: addPaper }, "+ 新建一行")),
						h("div", { className: "lit-small" }, "直接在这里改；导出后在 Excel 里打开就是模板那张表。"),
						s.exportMsg ? h("div", { className: s.exportMsg.indexOf("已导出") === 0 ? "lit-ok" : "lit-err" }, s.exportMsg) : null),
					h("div", { className: "lit-tablewrap" },
						h("table", { className: "lit-table" },
							h("thead", null, h("tr", null,
								h("th", { className: "lit-stick" }, "#"),
								COLUMNS.map((c) => h("th", { key: c.id }, c.label)))),
							h("tbody", null,
								s.papers.length === 0
									? h("tr", null, h("td", { colSpan: COLUMNS.length + 1 }, h("div", { className: "lit-empty" }, "还没有文献")))
									: s.papers.map((paper, idx) => h("tr", { key: paper.id },
										h("td", { className: "lit-stick" },
											h("div", { className: "lit-small" }, String(idx + 1)),
											h("button", { className: "lit-mini", onClick: () => set({ activeId: paper.id, tab: "entry" }) }, "编辑")),
										COLUMNS.map((column) => h("td", { key: column.id },
											h("textarea", {
												className: "lit-cell",
												value: typeof paper[column.id] === "string" ? paper[column.id] : "",
												onChange: (e) => { const patch = {}; patch[column.id] = e.target.value; patchPaper(paper.id, patch); },
											})))))))));
			}

			// ───────────────────────── 翻译 ─────────────────────────

			function TxSide() {
				return h("div", null,
					h("div", { className: "lit-card" },
						h("div", { className: "lit-card-h" }, "分段翻译怎么用"),
						h("div", { className: "lit-small" }, "· 在原文框里拖选一段 → 点「翻译选中段」，只译选中的那一截"),
						h("div", { className: "lit-small" }, "· 导入 PDF 时会自动切成段；想重切就点「重新抽取文字」"),
						h("div", { className: "lit-small" }, "· 每段会自动带上一段作为上下文，术语与指代更一致"),
						h("div", { className: "lit-small" }, "· 在「对照精读」页勾划几段，可以攒进勾划篮再合并成一段一起翻")),
					h("div", { className: "lit-card" },
						h("div", { className: "lit-card-h" }, "译文怎么处理原文"),
						h("div", { className: "lit-small" }, "· 专业术语、方法名、统计量、数据库名第一次出现时写成「中文（English）」"),
						h("div", { className: "lit-small" }, "· HR、OR、BMI、GWAS 这类缩写保留英文，不硬译"),
						h("div", { className: "lit-small" }, "· 数字、P 值、95%CI、样本量、rs 编号原样保留"),
						h("div", { className: "lit-path", style: { marginTop: "6px" } }, "数据文件：" + shownDataPath)));
			}

						/** ── 对照精读：左半边 PDF 原文（可任意勾划），右半边是勾划出来的译文 ── */

			function pickedOf() {
				const box = txBox();
				return Array.isArray(box.picked) ? box.picked : [];
			}
			function txWritePicked(list) {
				txWrite({ picked: list });
			}

			// ── 勾划篮：先把几段勾划攒起来，再一起翻 ──

			function batchOf() {
				const box = txBox();
				return Array.isArray(box.batch) ? box.batch : [];
			}
			function txWriteBatch(list) {
				txWrite({ batch: list });
				if (state.batchPreview !== "") set({ batchPreview: mergedBatchText() });
			}
			function batchMode() {
				return selectionMode(state.ui) === "basket";
			}
			function setSelectionMode(value) {
				const mode = selectionMode({ selectionMode: value });
				set({ ui: Object.assign({}, state.ui, { selectionMode: mode, selBatch: mode === "basket" }) });
				scheduleSave();
				set({
					txStatus: mode === "basket" ? "勾画后自动加入勾画篮，稍后可合并或逐条翻译"
						: mode === "manual" ? "勾画后先预览，点击「翻译当前选区」才会发送请求"
							: "勾画后立即翻译；已有任务时，新选区会保存到勾画篮",
				});
			}
			function translationSourceStamp() {
				return sourceHash(txSource() + "\u0000" + segsOf().map((seg) => String(seg.id) + "\u0000" + String(seg.en || "")).join("\u0001"));
			}
			function batchItemPresent(item) {
				return batchOf().some((current) => current.id === item.id && current.text === item.text
					&& selectionSourceKey(current) === selectionSourceKey(item) && current.sourceStamp === item.sourceStamp);
			}
			function removeTranslatedItems(items) {
				txWriteBatch(batchOf().filter((current) => !items.some((item) => current.id === item.id && current.text === item.text
					&& selectionSourceKey(current) === selectionSourceKey(item) && current.sourceStamp === item.sourceStamp)));
			}
			/** 按原文位置和规范化后的文字去重；篮子满时明确提示，保留已有项目。 */
			function addToBatch(selection) {
				if (!selection || !selection.text.trim()) return;
				const paper = activePaper();
				if (state.paperMutationBusy || selection.paperId !== (paper ? paper.id : null) || selection.sourceStamp !== translationSourceStamp()) {
					set({ txError: "文献或原文已更改，请等待当前操作完成后重新勾画。" }); return;
				}
				if (selection.text.length > 40000) { set({ txError: "单个选区最多 40,000 字，请缩小选区后再勾画。" }); return; }
				const list = batchOf();
				if (list.some((item) => selectionKey(item) === selectionKey(selection) && (!item.sourceStamp || item.sourceStamp === selection.sourceStamp))) {
					set({ txStatus: "这段已在勾画篮中，共 " + list.length + " 条" });
					return;
				}
				if (list.length >= 40) { set({ txError: "勾画篮已满（40 条）。请先翻译或移出部分内容；当前选区仍可单独翻译。" }); return; }
				const entry = Object.assign({}, selection, { id: uid("b"), at: Date.now() });
				const next = list.concat([entry]);
				txWriteBatch(next);
				set({
					txError: null,
					txStatus: "已加入勾画篮：" + next.length + " 条 · " + batchChars() + " 字，可继续勾画或稍后一起翻译",
				});
			}
			function removeFromBatch(id) {
				txWriteBatch(batchOf().filter((x) => x.id !== id));
			}
			function previewBatchItem(item) {
				clearNativeSelection();
				const paper = activePaper();
				set({ sel: Object.assign({}, item, { paperId: paper ? paper.id : null, sourceStamp: item.sourceStamp || translationSourceStamp() }), readerSelectionOpen: true });
			}
			function clearBatch() {
				txWriteBatch([]);
				set({ batchPreview: "", txStatus: "篮子已清空" });
			}
			/** 合并后的原文：段与段之间空一行，方便模型看出这是多个片段 */
			function mergedBatchText() {
				return batchOf().map((x) => String(x.text || "").trim()).filter((x) => x.length > 0).join("\n\n");
			}
			function batchChars() {
				return batchOf().reduce((n, x) => n + String(x.text || "").length, 0);
			}
			function reusableSelection(item, annotate) {
				const entry = pickedOf().find((picked) => selectionKey(picked) === selectionKey(item)
					&& (!picked.sourceStamp || picked.sourceStamp === item.sourceStamp)
					&& (picked.annotate !== false) === annotate && String(picked.zh || "").trim());
				if (entry) return { kind: "picked", id: entry.id };
				const seg = Number.isFinite(item.segIndex) ? segsOf()[item.segIndex] : null;
				if (coversWholeSegment(item.text, seg) && String(seg.zh || "").trim() && (seg.annotate !== false) === annotate) {
					return { kind: "seg", index: item.segIndex };
				}
				return null;
			}
			/** 只有完整选中且译文为空的段落才写回段落；其余译文作为独立选区保留。 */
			function saveSelectionTranslation(item, text, annotate) {
				const seg = Number.isFinite(item.segIndex) ? segsOf()[item.segIndex] : null;
				if (coversWholeSegment(item.text, seg) && !String(seg.zh || "").trim()) {
					updateSegment(seg.id, { zh: text, annotate });
					return { kind: "seg", index: item.segIndex };
				}
				const entry = Object.assign({}, item, { id: uid("k"), en: item.text, zh: text, annotate, at: Date.now() });
				delete entry.text;
				txWritePicked([entry].concat(pickedOf()));
				return { kind: "picked", id: entry.id };
			}

			/** 把篮子里的几段勾划拼成一段，一次翻掉（模型能看到全文，中文更连贯） */
			async function translateBasket() {
				if (state.paperMutationBusy) { set({ txError: "本机文献正在移入回收站，请稍后再翻译。" }); return; }
				if (state.txBusy) return;
				const list = batchOf().slice();
				if (list.length === 0) { set({ txError: "勾画篮是空的，先在左侧原文中勾画文字。" }); return; }
				const merged = mergedBatchText();
				if (merged.length === 0) { set({ txError: "篮子里的内容都是空的" }); return; }
				if (merged.length > 40000) { set({ txError: "合并内容超过 40,000 字，请使用「逐条翻译」或移出部分内容。" }); return; }
				const segs = segsOf();
				const paper = activePaper();
				const paperId = paper ? paper.id : null;
				const sourceStamp = translationSourceStamp();
				if (list.some((item) => item.sourceStamp && item.sourceStamp !== sourceStamp)) {
					set({ txError: "勾画后原文已重新抽取或修改，请移出旧选区并重新勾画，再进行合并翻译。" }); return;
				}
				const annotate = state.txAnnotate;
				const initialSelection = state.sel;
				const initialView = state.readerView;
				const first = list.find((x) => x.segIndex !== null && segs[x.segIndex]);
				const taskId = beginTranslationTask("合并翻译勾划", "等待模型响应");
				set({
					txBusy: true, txError: null, txBatch: { done: 0, total: 1 },
					txStatus: "正在把 " + list.length + " 段勾划合并成一段翻译（" + merged.length + " 字）…",
				});
				let res = null;
				try {
					res = await rpc("translate", {
						text: merged,
						annotate,
						context: first ? buildContext(segs, segs[first.segIndex].id) : "",
					});
				} catch (error) {
					const stopped = taskStopRequested(taskId);
					set({ txBusy: false, txBatch: null, txStatus: stopped ? "已停止等待；后台请求仍继续" : "", txError: stopped ? null : "合并翻译失败：" + errText(error) });
					finishTranslationTask(taskId, stopped ? "cancelled" : "error", stopped ? "已停止等待；后台请求仍继续" : "合并翻译失败", stopped ? "" : errText(error));
					return;
				}
				if (taskStopRequested(taskId)) {
					set({ txBusy: false, txBatch: null, txStatus: "已停止等待，迟到译文已丢弃（后台请求仍继续）", txError: null });
					finishTranslationTask(taskId, "cancelled", "迟到译文已丢弃（后台请求仍继续）");
					return;
				}
				if (!res || res.ok !== true || !String(res.text || "").trim()) {
					const message = (res && res.error) || "unknown";
					set({ txBusy: false, txBatch: null, txStatus: "", txError: "合并翻译失败：" + message });
					finishTranslationTask(taskId, "error", "合并翻译失败", message);
					return;
				}
				if (!taskPaperStillActive(paperId) || translationSourceStamp() !== sourceStamp || !list.every(batchItemPresent)) {
					set({ txBusy: false, txBatch: null, txStatus: "文献或勾划内容已更改，迟到译文未写入" });
					finishTranslationTask(taskId, "cancelled", "文献或勾划内容已更改，迟到译文未写入");
					return;
				}
				const entry = {
					id: uid("k"), en: merged, zh: res.text, at: Date.now(),
					segIndex: null, mergedCount: list.length, sourceStamp, annotate,
					pageNumbers: Array.from(new Set(list.flatMap((item) => item.pageNumbers || []))),
				};
				txWritePicked([entry].concat(pickedOf()));
				removeTranslatedItems(list);
				set({
					txBusy: false, txBatch: null,
					readerView: state.sel === initialSelection && state.readerView === initialView ? { kind: "picked", id: entry.id } : state.readerView,
					txStatus: "已合并翻译 " + list.length + " 条勾画（" + merged.length + " 字）" + (batchOf().length > 0 ? "；新增的 " + batchOf().length + " 条仍在勾画篮中" : ""),
				});
				finishTranslationTask(taskId, "success", "已完成合并翻译");
			}

			/** 每完成一条即保存并移出；新增项目与失败项目留在篮中，方便继续。 */
			async function translateBasketEach() {
				if (state.paperMutationBusy) { set({ txError: "本机文献正在移入回收站，请稍后再翻译。" }); return; }
				if (state.txBusy) return;
				const list = batchOf().slice();
				if (list.length === 0) { set({ txError: "勾画篮是空的，先在左侧原文中勾画文字。" }); return; }
				const paper = activePaper();
				const paperId = paper ? paper.id : null;
				const sourceStamp = translationSourceStamp();
				const annotate = state.txAnnotate;
				const initialSelection = state.sel;
				const initialView = state.readerView;
				const taskId = beginTranslationTask("逐条翻译勾画", "等待第 1 / " + list.length + " 条", {
					canCancel: true, cancelMode: "queue", cancelLabel: "停止排队",
					onStop: () => set({ txAbort: true }),
				});
				set({ txBusy: true, txError: null, txAbort: false, txBatch: { done: 0, total: list.length }, txStatus: "正在逐条翻译 " + list.length + " 条勾画…" });
				let completed = 0;
				let skipped = 0;
				let lastView = null;
				let failure = "";
				let sourceChanged = false;
				for (let i = 0; i < list.length; i++) {
					if (taskStopRequested(taskId) || state.txAbort === true) break;
					if (!taskPaperStillActive(paperId) || translationSourceStamp() !== sourceStamp) { sourceChanged = true; break; }
					const item = list[i];
					if (!batchItemPresent(item)) { skipped++; continue; }
					if ((item.sourceStamp && item.sourceStamp !== sourceStamp) || String(item.text || "").length > 40000) { skipped++; continue; }
					updateTask(taskId, { stage: "翻译第 " + (i + 1) + " / " + list.length + " 条", progress: Math.round((i / list.length) * 100) });
					set({ txBatch: { done: i, total: list.length } });
					let view = reusableSelection(item, annotate);
					if (!view) {
						const seg = Number.isFinite(item.segIndex) ? segsOf()[item.segIndex] : null;
						let res = null;
						try {
							res = await rpc("translate", { text: item.text, annotate, context: seg ? buildContext(segsOf(), seg.id) : "" });
						} catch (error) {
							if (!taskStopRequested(taskId)) failure = "第 " + (i + 1) + " 条翻译失败：" + errText(error);
							break;
						}
						if (!taskPaperStillActive(paperId) || translationSourceStamp() !== sourceStamp) { sourceChanged = true; break; }
						if (!res || res.ok !== true || !String(res.text || "").trim()) {
							if (!taskStopRequested(taskId)) failure = "第 " + (i + 1) + " 条翻译失败：" + ((res && res.error) || "未返回译文");
							break;
						}
						if (!batchItemPresent(item)) { skipped++; continue; }
						view = saveSelectionTranslation(Object.assign({}, item, { sourceStamp }), res.text, annotate);
					}
					lastView = view;
					completed++;
					removeTranslatedItems([item]);
					set({ txBatch: { done: i + 1, total: list.length }, txStatus: "已保存 " + completed + " 条译文，正在处理本次队列" });
				}
				const interrupted = taskStopRequested(taskId) || state.txAbort === true;
				const status = failure ? "error" : (interrupted || sourceChanged ? "cancelled" : "success");
				const message = (failure ? "本次队列暂停" : sourceChanged ? "文献或原文已更改，停止处理" : interrupted ? "已停止后续排队" : "逐条翻译完成")
					+ "；已保存 " + completed + " 条译文，未完成及新增内容留在各自的勾画篮中"
					+ (skipped > 0 ? "（" + skipped + " 条已移出、原文已更改或超出长度限制，未翻译）" : "");
				set({ txAbort: false, txStatus: message, txError: failure || null,
					readerView: lastView && taskPaperStillActive(paperId) && state.sel === initialSelection && state.readerView === initialView ? lastView : state.readerView });
				finishTranslationTask(taskId, status, message, failure);
			}
			function setReaderMode(mode) {
				clearSelection();
				const paper = activePaper();
				if (paper !== null) {
					const progress = progressOf(paper);
					patchPaper(paper.id, { progress: Object.assign({}, progress, { readerMode: mode }) });
				}
				set({ ui: Object.assign({}, state.ui, { readerMode: mode }) });
				scheduleSave();
			}

			// ── 中间栏内部左（原文）/右（译文）的占比 ──

			/** 占比收在 20~80 之间：再极端就会把另一栏挤到没法看 */
			function splitClamp(value) {
				const n = typeof value === "number" && isFinite(value) ? value : 50;
				return Math.max(20, Math.min(80, Math.round(n)));
			}
			function splitNow() {
				return splitClamp(state.ui && state.ui.split);
			}
			/** 拖动过程中不落盘，松手才写（每 1px 都存一次太吵） */
			function setSplit(value, save) {
				const next = splitClamp(value);
				if (next === splitNow()) return;
				set({ ui: Object.assign({}, state.ui, { split: next }) });
				if (save === true) scheduleSave();
			}
			/** 标题栏那个小图标：点一下换一档（也能直接拖中间的分隔条） */
			const SPLIT_STEPS = [50, 62, 38, 74, 26];
			function cycleSplit() {
				const now = splitNow();
				let index = SPLIT_STEPS.indexOf(now);
				index = index < 0 ? 0 : (index + 1) % SPLIT_STEPS.length;
				setSplit(SPLIT_STEPS[index], true);
			}

			// ── 导图大小 ──
			const MIND_ZOOMS = [100, 125, 150, 175, 200];
			function mindZoomClamp(value) {
				const n = typeof value === "number" && isFinite(value) ? value : 100;
				return Math.max(60, Math.min(300, Math.round(n)));
			}
			function mindZoomNow() {
				return mindZoomClamp(state.ui && state.ui.mindZoom);
			}
			function setMindZoom(value, save) {
				const next = mindZoomClamp(value);
				if (next === mindZoomNow()) return;
				set({ ui: Object.assign({}, state.ui, { mindZoom: next }) });
				if (save === true) scheduleSave();
			}
			function cycleMindZoom() {
				const now = mindZoomNow();
				const index = MIND_ZOOMS.indexOf(now);
				setMindZoom(index < 0 || index === MIND_ZOOMS.length - 1 ? MIND_ZOOMS[0] : MIND_ZOOMS[index + 1], true);
			}
			/** Ctrl + 滚轮在导图上直接缩放 */
			function mindWheel(event) {
				if (!event || event.ctrlKey !== true) return;
				if (typeof event.preventDefault === "function") event.preventDefault();
				const step = event.deltaY > 0 ? -10 : 10;
				setMindZoom(mindZoomNow() + step, true);
			}
			/** 放大镜图标：镜片大小跟着缩放走 */
			function MindSizeIcon(props) {
				const pct = mindZoomClamp(props && props.pct);
				const r = 3.4 + (pct / 300) * 2.4;
				return h("svg", { width: 14, height: 14, viewBox: "0 0 16 16", "aria-hidden": "true", style: { verticalAlign: "-2px" } },
					h("circle", { cx: 7, cy: 7, r: r, fill: "none", stroke: "currentColor", strokeWidth: 1.5 }),
					h("line", { x1: 7 + r * 0.72, y1: 7 + r * 0.72, x2: 14, y2: 14, stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "round" }));
			}

			/** 收起/展开的小三角：open=true 时朝上（点它是收起），否则朝右（点它是展开） */
			function ChevronIcon(props) {
				const open = props && props.open === true;
				return h("svg", { width: 12, height: 12, viewBox: "0 0 12 12", "aria-hidden": "true", style: { verticalAlign: "-1px" } },
					h("path", {
						d: open ? "M2 7.6 L6 3.6 L10 7.6" : "M4.4 2 L8.4 6 L4.4 10",
						fill: "none", stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round", strokeLinejoin: "round",
					}));
			}

			/** 勾划篮收起/展开（状态记在 ui.basketOpen，重启后保持） */
			function setBasketOpen(on) {
				set({ ui: Object.assign({}, state.ui, { basketOpen: on === true }) });
				scheduleSave();
			}
			/** 抓住中间的分隔条左右拖 */
			function splitStart(event) {
				const row = event && event.currentTarget ? event.currentTarget.parentNode : null;
				if (!row || typeof row.getBoundingClientRect !== "function") return;
				if (typeof event.preventDefault === "function") event.preventDefault();
				const rect = row.getBoundingClientRect();
				if (!(rect.width > 0)) return;
				set({ splitDragging: true });
				const move = (ev) => {
					const clientX = ev && typeof ev.clientX === "number" ? ev.clientX : null;
					if (clientX === null) return;
					setSplit(((clientX - rect.left) / rect.width) * 100, false);
				};
				const up = () => {
					if (typeof document !== "undefined" && typeof document.removeEventListener === "function") {
						document.removeEventListener("mousemove", move);
						document.removeEventListener("mouseup", up);
					}
					set({ splitDragging: false });
					scheduleSave();
				};
				if (typeof document !== "undefined" && typeof document.addEventListener === "function") {
					document.addEventListener("mousemove", move);
					document.addEventListener("mouseup", up);
				}
			}
			/** 图标本身就是占比示意：左边那块越宽，左边就越宽 */
			function SplitIcon(props) {
				const pct = splitClamp(props && props.pct);
				const inner = 10;
				const gap = 1.6;				const left = Math.max(2.2, Math.min(inner - gap - 2.2, (inner - gap) * (pct / 100)));
				const right = Math.max(2.2, inner - gap - left);
				return h("svg", { width: 14, height: 14, viewBox: "0 0 16 16", "aria-hidden": "true", style: { verticalAlign: "-2px" } },
					h("rect", { x: 2, y: 2.5, width: left, height: 11, rx: 1, fill: "currentColor" }),
					h("rect", { x: 2 + left + gap, y: 2.5, width: right, height: 11, rx: 1, fill: "currentColor", opacity: 0.4 }));
			}

			function selectSegment(index, fromSource) {
				if (fromSource && typeof window !== "undefined" && readerSelection(window.getSelection())) return;
				clearSelection();
				set({ readerView: { kind: "seg", index } });
			}

			// ── 选段 → 总结 → 思维导图 ──

			/** 要总结哪一段：优先刚勾划的选区，其次右半边正在看的那段/那条选区 */
			function mindSource() {
				const paper = activePaper();
				const hint = paper && typeof paper.title === "string" ? paper.title : "";
				const sel = state.sel;
				if (sel && typeof sel.text === "string" && sel.text.trim().length > 0) {
					return {
						text: sel.text,
						hint,
						label: sel.segIndex === null ? "勾划的 " + sel.text.length + " 字" : "第 " + (sel.segIndex + 1) + " 段里勾划的 " + sel.text.length + " 字",
					};
				}
				const view = state.readerView;
				const segs = segsOf();
				if (view && view.kind === "seg" && segs[view.index] && segs[view.index].en.trim().length > 0) {
					return { text: segs[view.index].en, hint, label: "第 " + (view.index + 1) + " 段全文" };
				}
				if (view && view.kind === "picked") {
					const entry = pickedOf().find((x) => x.id === view.id);
					if (entry && typeof entry.en === "string" && entry.en.trim().length > 0) {
						return { text: entry.en, hint, label: "勾划选区（" + entry.en.length + " 字）" };
					}
				}
				return null;
			}

			function mindsOf(paper) {
				return paper && Array.isArray(paper.mindmaps) ? paper.mindmaps : [];
			}

			async function summarizeCurrent() {
				if (state.paperMutationBusy) { set({ mindErr: "本机文献正在移入回收站，请稍后再生成导图。" }); return; }
				const paper = activePaper();
				if (paper === null) { set({ mindErr: "先选中一篇文献" }); return; }
				const source = mindSource();
				if (source === null) { set({ mindErr: "先在左半边勾划一段文字，或点某一段再总结" }); return; }
				const taskId = beginTask("mindmap", "生成思维导图", "等待模型总结", { canCancel: true, cancelLabel: "停止等待" });
				set({ mindBusy: true, mindErr: "", mindMsg: "正在总结 " + source.label + " …", txStatus: "正在把" + source.label + "总结成思维导图…" });
				let res = null;
				try {
					res = await rpc("summarize", { text: source.text, hint: source.hint });
				} catch (error) {
					const stopped = taskStopRequested(taskId);
					set({ mindBusy: false, mindMsg: "", mindErr: stopped ? "" : "总结失败：" + errText(error), txStatus: stopped ? "已停止等待；后台请求仍继续" : "" });
					finishTask(taskId, stopped ? "cancelled" : "error", stopped ? "停止等待；后台请求仍继续" : "总结失败", stopped ? "" : errText(error));
					return;
				}
				if (taskStopRequested(taskId)) {
					set({ mindBusy: false, mindMsg: "", mindErr: "", txStatus: "已停止等待，迟到导图已丢弃（后台请求仍继续）" });
					finishTask(taskId, "cancelled", "迟到导图已丢弃（后台请求仍继续）");
					return;
				}
				if (!res || res.ok !== true) {
					const extra = res && typeof res.raw === "string" && res.raw.trim().length > 0 ? "（模型说的是：「" + res.raw.trim().slice(0, 160) + "…」）" : "";
					const message = ((res && res.error) || "unknown") + extra;
					set({ mindBusy: false, mindMsg: "", mindErr: "总结失败：" + message, txStatus: "" });
					finishTask(taskId, "error", "总结失败", message);
					return;
				}
				const tree = res.tree && typeof res.tree === "object" ? res.tree : null;
				if (tree === null) { set({ mindBusy: false, mindMsg: "", mindErr: "总结失败：返回里没有导图结构", txStatus: "" }); finishTask(taskId, "error", "返回里没有导图结构"); return; }
				if (!state.papers.find((item) => item && item.id === paper.id)) {
					set({ mindBusy: false, mindMsg: "", mindErr: "", txStatus: "文献已删除，迟到导图未保存" });
					finishTask(taskId, "cancelled", "文献已删除，迟到导图未保存");
					return;
				}
				const entry = {
					id: uid("m"),
					label: source.label,
					source: source.text.slice(0, 600),
					title: String(tree.label || "思维导图"),
					tree,
					at: Date.now(),
				};
				const latestPaper = state.papers.find((item) => item && item.id === paper.id);
				const list = mindsOf(latestPaper).concat([entry]).slice(-40);
				patchPaper(paper.id, { mindmaps: list });
				set({ mindBusy: false, mindMsg: "", mindErr: "", mindTab: true, mindId: entry.id, mindText: "", txStatus: "已生成思维导图：" + entry.title });
				finishTask(taskId, "success", "已生成并保存思维导图");
			}

			function removeMind(id) {
				const paper = activePaper();
				if (paper === null) return;
				const list = mindsOf(paper).filter((x) => x.id !== id);
				patchPaper(paper.id, { mindmaps: list });
				if (state.mindId === id) set({ mindId: list.length > 0 ? list[list.length - 1].id : null });
			}

			/** 复制大纲：能自动复制就复制，不行就把文字摊出来让人手动全选 */
			function copyMindOutline(map) {
				if (!map || !map.tree) return;
				const text = mindOutlineText(map.tree);
				set({ mindText: text });
				let clipboard = null;
				try {
					clipboard = typeof navigator !== "undefined" && navigator.clipboard && typeof navigator.clipboard.writeText === "function" ? navigator.clipboard : null;
				} catch { clipboard = null; }
				if (clipboard === null) {
					set({ mindMsg: "浏览器不让自动复制，下面就是大纲文字，全选复制即可" });
					return;
				}
				try {
					const done = clipboard.writeText(text);
					if (done && typeof done.then === "function") {
						done.then(() => set({ mindMsg: "大纲已复制，可以直接粘进 XMind / 幕布 / Word" }), () => set({ mindMsg: "自动复制被拒了，下面就是大纲文字，全选复制即可" }));
						return;
					}
					set({ mindMsg: "大纲已复制" });
				} catch {
					set({ mindMsg: "自动复制被拒了，下面就是大纲文字，全选复制即可" });
				}
			}

			function MindMap(props) {
				const laid = mindLayout(props.tree);
				if (laid.nodes.length === 0) return h("div", { className: "lit-empty" }, "这张导图是空的");
				const zoom = mindZoomClamp(props && props.zoom);
				return h("svg", {
					className: "lit-mind",
					viewBox: "0 0 " + laid.width + " " + laid.height,
					preserveAspectRatio: "xMinYMin meet",
					style: { width: zoom + "%", height: "auto" },
				},
					laid.edges.map((edge, i) => h("path", {
						key: "e" + i,
						className: "lit-mind-edge",
						d: "M" + (edge.from.x + edge.from.w) + " " + edge.from.cy
							+ " C" + (edge.from.x + edge.from.w + 18) + " " + edge.from.cy
							+ ", " + (edge.to.x - 18) + " " + edge.to.cy
							+ ", " + edge.to.x + " " + edge.to.cy,
					})),
					laid.nodes.map((node, i) => h("g", { key: "n" + i, className: "lit-mind-node d" + Math.min(node.depth, 2) },
						h("rect", { x: node.x, y: node.cy - node.h / 2, width: node.w, height: node.h, rx: 5 }),
						h("title", null, node.label),
						h("text", { x: node.x + 9, y: node.cy + 4 }, node.display))));
			}

			function MindPanel(props) {
				const s = useStore();
				const paper = props.paper;
				const maps = mindsOf(paper);
				const current = maps.find((x) => x.id === s.mindId) || (maps.length > 0 ? maps[maps.length - 1] : null);
				const kids = [];
				kids.push(h("div", { key: "head", className: "lit-small" }, maps.length === 0
					? "还没有导图：在左半边勾划一段文字（或点某一段），再点上面的「总结成导图」。"
					: "已生成 " + maps.length + " 张（点标题切换）："));
				for (const map of maps) {
					kids.push(h("div", {
						key: map.id,
						className: "lit-picked" + (current !== null && current.id === map.id ? " is-current" : ""),
						onClick: () => set({ mindId: map.id }),
					}, map.title + "　·　" + String(map.label || "").slice(0, 20)));
				}
				if (current !== null) {
					const meta = "中心主题：" + String(current.tree && current.tree.label ? current.tree.label : "")
						+ "　·　来源：" + String(current.label || "");
					kids.push(h("div", { key: "meta", className: "lit-small", style: { margin: "8px 0 4px" } }, meta));
					kids.push(h("div", { key: "map", className: "lit-mind-wrap", onWheel: mindWheel }, h(MindMap, { tree: current.tree, zoom: s.ui && s.ui.mindZoom })));
					kids.push(h("div", {
						key: "acts",
						style: { marginTop: "6px", display: "flex", gap: "6px", flexWrap: "wrap", alignItems: "center" },
					},
						h("button", {
							key: "zoom",
							className: "lit-btn",
							style: { display: "inline-flex", alignItems: "center", gap: "4px" },
							title: "导图大小 " + mindZoomNow() + "% —— 点一下换一档（Ctrl+滚轮也能缩放）",
							onClick: () => cycleMindZoom(),
						}, h(MindSizeIcon, { pct: mindZoomNow() }), "大小 " + mindZoomNow() + "%"),
						h("button", { key: "fit", className: "lit-btn", onClick: () => setMindZoom(100, true) }, "适应宽度"),
						h("button", { key: "copy", className: "lit-btn", onClick: () => copyMindOutline(current) }, "复制大纲"),
						h("button", { key: "redo", className: "lit-btn", disabled: s.mindBusy, onClick: () => summarizeCurrent() }, "重新总结当前选段"),
						h("button", { key: "del", className: "lit-btn", onClick: () => removeMind(current.id) }, "删除这张")));
				}
				if (s.mindText.length > 0) {
					kids.push(h("div", { key: "texth", className: "lit-small", style: { marginTop: "6px" } }, s.mindMsg || "大纲文字："));
					kids.push(h("textarea", {
						key: "text",
						className: "lit-mind-text",
						readOnly: true,
						value: s.mindText,
						onClick: (e) => { if (e && e.target && typeof e.target.select === "function") e.target.select() },
					}));
					kids.push(h("button", { key: "fold", className: "lit-btn", onClick: () => set({ mindText: "", mindMsg: "" }) }, "收起大纲"));
				}
				return h("div", null, kids);
			}
			function removePicked(id) {
				txWritePicked(pickedOf().filter((x) => x.id !== id));
				const view = state.readerView;
				if (view && view.kind === "picked" && view.id === id) set({ readerView: null });
			}

			/** 正在看的这一条译文：优先当前段/当前选区，其次整篇译文 */
			function currentTranslation() {
				const view = state.readerView;
				const segs = segsOf();
				if (view && view.kind === "seg" && segs[view.index]) {
					const seg = segs[view.index];
					return {
						label: "第 " + (view.index + 1) + " 段",
						zh: seg.zh || "",
						write: (value) => updateSegment(seg.id, { zh: value }),
					};
				}
				if (view && view.kind === "picked") {
					const entry = pickedOf().find((x) => x.id === view.id);
					if (entry) {
						return {
							label: "勾划选区",
							zh: entry.zh || "",
							write: (value) => txWritePicked(pickedOf().map((x) => (x.id === entry.id ? Object.assign({}, x, { zh: value }) : x))),
						};
					}
				}
				return {
					label: "整篇译文",
					zh: txResult(),
					write: (value) => txWrite({ result: value, updatedAt: Date.now() }),
				};
			}

			function clearNativeSelection() {
				if (typeof window === "undefined" || typeof window.getSelection !== "function") return;
				try {
					const selection = window.getSelection();
					if (selection && (readerTextRoot(selection.anchorNode) || readerTextRoot(selection.focusNode))) selection.removeAllRanges();
				} catch { /* ignore */ }
			}
			function clearSelection() {
				clearNativeSelection();
				set({ sel: null, readerSelectionOpen: false });
			}
			/** 松手后收集一次原文选区，再按用户选择的模式处理。 */
			function captureSelection(root) {
				if (typeof window === "undefined" || typeof window.getSelection !== "function") return;
				let selected = null;
				try {
					selected = readerSelection(window.getSelection(), root);
				} catch { return; }
				if (!selected) { set({ sel: null }); return; }
				if (selected.segIndices.length === 0 && selected.pageNumbers.length > 0) selected.segIndex = matchSegmentIndex(selected.text);
				const paper = activePaper();
				selected.paperId = paper ? paper.id : null;
				selected.sourceStamp = translationSourceStamp();
				selected.sourceKey = selectionSourceKey(selected);
				const previousView = state.readerView;
				const previousPicked = previousView && previousView.kind === "picked"
					? pickedOf().find((entry) => entry.id === previousView.id) : null;
				const previousWasMerged = previousPicked && Number.isInteger(previousPicked.mergedCount) && previousPicked.mergedCount > 0;
				set({
					sel: selected,
					readerView: previousWasMerged ? null : state.readerView,
					readerSelectionOpen: selectionMode(state.ui) === "manual" || state.readerSelectionOpen,
				});
				if (batchMode()) addToBatch(selected);
				else if (selectionMode(state.ui) === "instant") maybeAutoTranslate(selected);
				else set({ txStatus: "已选中 " + selected.text.length + " 字，可预览、加入勾画篮或点击翻译", txError: null });
			}

			/** 左栏滚动时记录「读到第几段」，只前进不后退，并同步到阅读进度 */
			let lastReadMark = -1;
			function handleReaderScroll(event) {
				rememberScroll("text");
				const box = event.currentTarget;
				if (!box || typeof box.querySelectorAll !== "function") return;
				const blocks = box.querySelectorAll("[data-seg]");
				if (blocks.length === 0) return;
				const line = box.getBoundingClientRect().top + box.clientHeight * 0.75;
				let reached = 0;
				for (let i = 0; i < blocks.length; i++) {
					if (blocks[i].getBoundingClientRect().top <= line) reached = i;
					else break;
				}
				if (reached === lastReadMark) return;
				lastReadMark = reached;
				const paper = activePaper();
				if (paper === null) return;
				const progress = progressOf(paper);
				if (reached <= (progress.readSegments || 0)) return;
				const next = Object.assign({}, progress, { readSegments: reached, lastReadAt: Date.now() });
				const pct = Math.round(((reached + 1) / blocks.length) * 100);
				if (pct > progress.percent) next.percent = pct;
				patchPaper(paper.id, { progress: next });
			}

			/** 立即翻译模式下，忙时收进篮子；成功译文可复用，失败后可以重试。 */
			function maybeAutoTranslate(selection) {
				if (state.txBusy) {
					addToBatch(selection);
					if (batchOf().some((item) => selectionKey(item) === selectionKey(selection))) {
						set({ txStatus: "已有翻译任务，当前选区已保存到勾画篮，稍后可继续翻译" });
					}
					return;
				}
				translatePicked();
			}

			/** 只翻第 index 段（点左栏某一段后，右半边一键把这段翻出来） */
			async function translateSegmentAt(index) {
				if (state.paperMutationBusy) { set({ txError: "本机文献正在移入回收站，请稍后再翻译。" }); return; }
				if (state.txBusy) return;
				const segs = segsOf();
				const seg = segs[index];
				if (!seg || !seg.en || seg.en.trim().length === 0) return;
				const paper = activePaper();
				const paperId = paper ? paper.id : null;
				const originalZh = seg.zh || "";
				const taskId = beginTranslationTask("翻译第 " + (index + 1) + " 段", "等待模型响应");
				set({ readerView: { kind: "seg", index }, txBusy: true, txError: null, txStatus: "正在翻译第 " + (index + 1) + " 段…", txBatch: { done: 0, total: 1 } });
				let res = null;
				try {
					res = await rpc("translate", { text: seg.en, annotate: state.txAnnotate, context: buildContext(segs, seg.id) });
				} catch (error) {
					const stopped = taskStopRequested(taskId);
					set({ txBusy: false, txBatch: null, txStatus: stopped ? "已停止等待；后台请求仍继续" : "", txError: stopped ? null : "翻译失败：" + errText(error) });
					finishTranslationTask(taskId, stopped ? "cancelled" : "error", stopped ? "已停止等待；后台请求仍继续" : "翻译失败", stopped ? "" : errText(error));
					return;
				}
				if (taskStopRequested(taskId)) {
					set({ txBusy: false, txBatch: null, txStatus: "已停止等待，迟到译文已丢弃（后台请求仍继续）", txError: null });
					finishTranslationTask(taskId, "cancelled", "迟到译文已丢弃（后台请求仍继续）");
					return;
				}
				if (!res || res.ok !== true) {
					const message = (res && res.error) || "unknown";
					set({ txBusy: false, txBatch: null, txStatus: "", txError: "翻译失败：" + message });
					finishTranslationTask(taskId, "error", "翻译失败", message);
					return;
				}
				if (!taskPaperStillActive(paperId) || !segmentStillMatches(paperId, seg.id, seg.en, originalZh)) {
					set({ txBusy: false, txBatch: null, txStatus: "原文或译文已更改，迟到译文未写入" });
					finishTranslationTask(taskId, "cancelled", "检测到文献/内容已更改，迟到译文未写入");
					return;
				}
				setSegments(segsOf().map((x) => (x.id === seg.id ? Object.assign({}, x, { zh: res.text }) : x)));
				set({ txBusy: false, txBatch: null, readerView: { kind: "seg", index }, txStatus: "已写入第 " + (index + 1) + " 段译文" });
				finishTranslationTask(taskId, "success", "已写入译文");
			}

			/** 保存当前勾画的译文；继续勾画不影响已经发出的请求，也不抢占新的预览。 */
			async function translatePicked() {
				if (state.paperMutationBusy) { set({ txError: "本机文献正在移入回收站，请稍后再翻译。" }); return; }
				if (state.txBusy) return;
				const sel = state.sel;
				if (!sel || sel.text.length === 0) { set({ txError: "先在左半边勾划一段文字" }); return; }
				const segs = segsOf();
				const paper = activePaper();
				const paperId = paper ? paper.id : null;
				const sourceStamp = translationSourceStamp();
				if (sel.paperId !== paperId || sel.sourceStamp !== sourceStamp) { set({ txError: "文献或原文已更改，请重新勾画。" }); return; }
				if (sel.text.length > 40000) { set({ txError: "单个选区最多 40,000 字，请缩小选区后再翻译。" }); return; }
				const annotate = state.txAnnotate;
				const initialView = state.readerView;
				const index = sel.segIndex;
				const seg = index !== null && index >= 0 && index < segs.length ? segs[index] : null;
				const reusable = reusableSelection(sel, annotate);
				const matchingBatch = batchOf().filter((item) => selectionKey(item) === selectionKey(sel) && (!item.sourceStamp || item.sourceStamp === sourceStamp));
				if (reusable) {
					removeTranslatedItems(matchingBatch);
					set({ readerView: reusable, txError: null, txStatus: "已显示已有译文，可直接修改" });
					return;
				}
				const taskId = beginTranslationTask("翻译勾划选区", "等待模型响应");
				set({ txBusy: true, txError: null, txStatus: "正在翻译 " + sel.text.length + " 字…", txBatch: { done: 0, total: 1 } });
				let res = null;
				try {
					res = await rpc("translate", {
						text: sel.text,
						annotate,
						context: seg !== null ? buildContext(segs, seg.id) : "",
					});
				} catch (error) {
					const stopped = taskStopRequested(taskId);
					set({ txBusy: false, txBatch: null, txStatus: stopped ? "已停止等待；后台请求仍继续" : "", txError: stopped ? null : "翻译失败：" + errText(error) });
					finishTranslationTask(taskId, stopped ? "cancelled" : "error", stopped ? "已停止等待；后台请求仍继续" : "翻译失败", stopped ? "" : errText(error));
					return;
				}
				if (taskStopRequested(taskId)) {
					set({ txBusy: false, txBatch: null, txStatus: "已停止等待，迟到译文已丢弃（后台请求仍继续）", txError: null });
					finishTranslationTask(taskId, "cancelled", "迟到译文已丢弃（后台请求仍继续）");
					return;
				}
				if (!res || res.ok !== true || !String(res.text || "").trim()) {
					const message = (res && res.error) || "unknown";
					set({ txBusy: false, txBatch: null, txStatus: "", txError: "翻译失败：" + message });
					finishTranslationTask(taskId, "error", "翻译失败", message);
					return;
				}
				if (!taskPaperStillActive(paperId) || translationSourceStamp() !== sourceStamp) {
					set({ txBusy: false, txBatch: null, txStatus: "文献或原文已更改，迟到译文未写入" });
					finishTranslationTask(taskId, "cancelled", "文献或原文已更改，迟到译文未写入");
					return;
				}
				const resultView = saveSelectionTranslation(sel, res.text, annotate);
				removeTranslatedItems(matchingBatch);
				const showResult = state.sel === sel && state.readerView === initialView;
				const message = resultView.kind === "seg" ? "已保存完整段落的译文" : "已保存勾画选区的译文";
				set({ txBusy: false, txBatch: null, readerView: showResult ? resultView : state.readerView,
					txStatus: message + (showResult ? "，可在右侧修改" : "；当前新选区保持不变") });
				finishTranslationTask(taskId, "success", message);
			}

			// ───────────────────────── 版式模式（自己画真实 PDF 页面）─────────────────────────
			// 思路：pdf.js 不进 npm 包，第一次点「版式」时由 host 半下载到数据目录，这里再动态 import。
			// 每页画到 canvas，上面盖一层透明文字层（span 绝对定位），选中文字照样走勾划翻译。
			let pdfjsLib = null;
			let pdfjsLoading = null;
			const pdfFileUrl = (name) => PDF_ROUTE + "/" + encodeURIComponent(name);
			const pdfjsFileUrl = (file) => PDFJS_ROUTE + "/" + encodeURIComponent(file);

			async function loadPdfjs() {
				if (pdfjsLib !== null) return pdfjsLib;
				if (pdfjsLoading !== null) return await pdfjsLoading;
				pdfjsLoading = (async () => {
					const mod = await import(pdfjsFileUrl("pdf.min.mjs"));
					if (!mod || typeof mod.getDocument !== "function") throw new Error("pdf.js 模块里没有 getDocument");
					try {
						if (mod.GlobalWorkerOptions) mod.GlobalWorkerOptions.workerSrc = pdfjsFileUrl("pdf.worker.min.mjs");
					} catch { /* 起不了 worker 时 pdf.js 会退回主线程 */ }
					pdfjsLib = mod;
					return mod;
				})();
				try {
					return await pdfjsLoading;
				} catch (error) {
					pdfjsLoading = null;
					throw error;
				}
			}

			/** 文字层里一个小块的位置：见文件上方的 textItemBox（放工厂作用域是为了能被测试直接调） */

			/** 版式模式的文字层没有 data-seg，就按内容把选区对回原文段落（对上就算那一段的译文） */
			function matchSegmentIndex(text) {
				const target = normText(text);
				if (target.length < 12) return null;
				const segs = segsOf();
				let match = null;
				for (let i = 0; i < segs.length; i++) {
					const en = normText(segs[i].en);
					if (en.length === 0) continue;
					if (en.indexOf(target) >= 0) {
						if (match !== null) return null;
						match = i;
					}
				}
				return match;
			}

			const pdfState = { name: "", doc: null, pages: [], stack: null, frame: null, observer: null, sizeObserver: null, sizeTarget: null, relayoutTimer: null, width: 0, seen: -1, suppressProgressUntil: 0 };

			async function locateEvidenceOnPdf(paper, quote) {
				if (!paper || !paper.pdf || !paper.pdf.name || state.pdfEvidenceBusy) return;
				set({ pdfEvidenceBusy: true, pdfEvidenceStatus: { paperId: paper.id, kind: "busy", text: "正在查找原文依据所在页…" } });
				try {
					const result = await rpc("findPdfEvidencePage", { name: paper.pdf.name, quote });
					if (!result || result.ok !== true) throw new Error((result && result.error) || "无法定位这条原文依据。");
					const pageNumber = Number(result.page);
					if (!Number.isInteger(pageNumber) || pageNumber < 1) throw new Error("未能在这份 PDF 的文本层中找到该依据。扫描版或文字抽取差异可能导致无法定位。");
					if (state.activeId !== paper.id) throw new Error("当前文献已切换，请回到原文依据所在的文献重试。");

					const ui = Object.assign({}, state.ui, { readerMode: "layout" });
					set({ tab: "translate", ui, txError: null, txStatus: "正在打开 PDF 第 " + pageNumber + " 页…" });
					const deadline = Date.now() + 30_000;
					let located = false;
					while (Date.now() < deadline) {
						if (state.activeId !== paper.id) throw new Error("当前文献已切换，请回到原文依据所在的文献重试。");
						if (pdfState.name === paper.pdf.name && pdfState.stack) {
							const entry = pdfState.pages[pageNumber - 1];
							if (entry && entry.node && typeof entry.node.getBoundingClientRect === "function") {
								const top = entry.node.getBoundingClientRect().top - pdfState.stack.getBoundingClientRect().top + pdfState.stack.scrollTop;
								if (typeof pdfState.stack.scrollTo === "function") pdfState.stack.scrollTo({ top, behavior: "smooth" });
								else pdfState.stack.scrollTop = top;
								pdfState.suppressProgressUntil = Date.now() + 2_000;
								pdfjsRender(pageNumber - 1);
								located = true;
								break;
							}
						}
						await new Promise((resolve) => setTimeout(resolve, 100));
					}
					if (!located) throw new Error("已找到第 " + pageNumber + " 页，但 PDF 版式视图未能及时打开；请稍后重试。");
					set({ txStatus: "已定位到 PDF 第 " + pageNumber + " 页。", pdfEvidenceStatus: { paperId: paper.id, kind: "success", text: "已定位到 PDF 第 " + pageNumber + " 页。" } });
				} catch (error) {
					const message = "定位失败：" + errText(error);
					set({ pdfEvidenceStatus: { paperId: paper.id, kind: "error", text: message }, txStatus: message });
				} finally {
					set({ pdfEvidenceBusy: false });
				}
			}

			/** 页面该塞进哪个容器：拿不到真实 DOM（或者已经卸载）就什么都不做 */
			function pdfStackOf() {
				const stack = pdfState.stack;
				if (!stack || typeof stack.appendChild !== "function") return null;
				if (stack.isConnected === false) return null;
				return stack;
			}

			async function pdfjsCheck() {
				// 注意：这里不主动清 pdfjsErr —— 否则「下载失败」的提示会被下一次例行检查悄悄抹掉
				let res = null;
				try {
					res = await rpc("pdfjs", { action: "status" });
				} catch (error) {
					// 查不出来 ≠ 本地没有：这两种情况给的话完全不一样，
					// 早先一失败就当成「需要下载 pdf.js」，于是在后端断开时把人引去下载，纯属误导
					set({ pdfjsReady: null, pdfjsErr: errText(error), pdfjsHint: "" });
					return;
				}
				if (!res || res.ok !== true) {
					set({ pdfjsReady: null, pdfjsErr: (res && res.error) || "查询本地 pdf.js 失败" });
					return;
				}
				if (res.ready === true) {
					set({ pdfjsReady: true, pdfjsHint: "", pdfjsErr: "" });
					await pdfjsOpen();
					return;
				}
				// 只有「上一轮是查不到（网络问题）」才顺手把错误清掉；
				// 否则会把「下载失败」的提示被例行检查悄悄抹掉（这个坑踩过一次）
				const wasUnknown = state.pdfjsReady === null;
				set({ pdfjsReady: false, pdfjsHint: res.hint || "", pdfjsErr: wasUnknown ? "" : state.pdfjsErr });
			}

			async function pdfjsDownload() {
				if (state.pdfjsBusy === true) return;
				set({ pdfjsBusy: true, pdfjsErr: "", pdfjsMsg: "正在下载 pdf.js（约 1.2MB）…" });
				let res = null;
				try {
					res = await rpc("pdfjs", { action: "download" });
				} catch (error) {
					set({ pdfjsBusy: false, pdfjsMsg: "", pdfjsErr: "下载失败：" + errText(error) });
					return;
				}
				if (!res || res.ok !== true || res.ready !== true) {
					const tried = res && Array.isArray(res.tried) && res.tried.length > 0 ? "　试过：" + res.tried.join(" / ") : "";
					set({
						pdfjsBusy: false, pdfjsMsg: "", pdfjsReady: false,
						pdfjsErr: ((res && res.error) || "下载失败") + tried,
						pdfjsHint: (res && res.manual) || state.pdfjsHint,
					});
					return;
				}
				set({ pdfjsBusy: false, pdfjsMsg: "", pdfjsReady: true, pdfjsHint: "", pdfjsErr: "" });
				await pdfjsOpen();
			}

			/** 打开当前这篇的 PDF：解析文档、量出每页尺寸、铺好页面骨架 */
			async function pdfjsOpen() {
				const paper = activePaper();
				if (paper === null) { set({ pdfjsErr: "先选中一篇文献" }); return; }
				const name = paper.pdf && paper.pdf.name ? String(paper.pdf.name) : "";
				if (name.length === 0) { set({ pdfjsErr: "这篇还没有导入 PDF" }); return; }
				if (pdfState.name === name && pdfState.doc !== null) { pdfjsMount(); return; }
				set({ pdfjsMsg: "正在解析 PDF…", pdfjsErr: "", pdfjsPages: 0 });
				try {
					const mod = await loadPdfjs();
					const doc = await mod.getDocument({ url: pdfFileUrl(name), useSystemFonts: true }).promise;
					const pages = [];
					for (let i = 1; i <= doc.numPages; i++) {
						const page = await doc.getPage(i);
						pages.push({ page, base: page.getViewport({ scale: 1 }), node: null, canvas: null, layer: null, rendered: false, busy: false });
					}
					pdfState.doc = doc;
					pdfState.name = name;
					pdfState.pages = pages;
					pdfState.seen = -1;
					set({ pdfjsMsg: "", pdfjsPages: doc.numPages });
					pdfjsMount();
				} catch (error) {
					set({ pdfjsMsg: "", pdfjsErr: "PDF 打不开：" + errText(error) });
				}
			}

			/**
			 * 宽度只认外层 frame（.lit-reader-layout）：它是 overflow:hidden，宽度就等于中栏宽度，
			 * 不会被放大后的页面反过来撑大。早先量的是页面容器自身，于是「量到的宽度 → 放大页面 →
			 * 容器被撑得更宽 → 再量更大」，一路把整个界面挤出去、还伴随不停重排闪屏。
			 */
			function pdfjsFrameWidth() {
				const frame = pdfState.frame;
				if (frame && typeof frame.clientWidth === "number" && frame.clientWidth > 0) return frame.clientWidth;
				const stack = pdfStackOf();
				if (stack !== null && stack.clientWidth > 0) return stack.clientWidth;
				return 640;
			}
			function pdfjsPageWidth(zoom) {
				// -30：给页面容器的左右内边距和滚动条留位置，100% 时不至于又挤出横向滚动条
				return Math.max(240, Math.round((pdfjsFrameWidth() - 30) * (zoom || 1)));
			}

			/**
			 * 按当前缩放把每页的尺寸改掉并重画。
			 * 只改尺寸、不拆 DOM：拆了整列会白一下，看着就是闪。
			 * 宽度没变就直接返回 —— 这是防「重排 → 尺寸变化 → 再触发重排」来回抖的关键。
			 */
			function pdfjsApplySize() {
				const pages = pdfState.pages;
				if (pages.length === 0 || pdfStackOf() === null) return;
				const width = pdfjsPageWidth(state.pdfjsScale);
				if (width === pdfState.width) return;
				pdfState.width = width;
				for (const entry of pages) {
					if (entry.node === null) continue;
					entry.node.style.width = width + "px";
					entry.node.style.height = Math.round(width * (entry.base.height / entry.base.width)) + "px";
					entry.node.className = "lit-pdfpage is-loading";
					if (entry.canvas !== null) { entry.canvas.width = 1; entry.canvas.height = 1 }
					if (entry.layer !== null && entry.layer.parentNode) entry.layer.parentNode.removeChild(entry.layer);
					entry.layer = null;
					entry.rendered = false;
					entry.busy = false;
				}
				pdfjsObserve();
				// 尺寸变了，每页的高度也变了：按比例把阅读位置重新对齐
				restoreScroll("layout");
			}

			function pdfjsRelayout() {
				if (pdfState.pages.length === 0) return;
				if (pdfjsPageWidth(state.pdfjsScale) === pdfState.width) return;
				if (typeof setTimeout !== "function") { pdfjsApplySize(); return; }
				if (pdfState.relayoutTimer !== null) { try { clearTimeout(pdfState.relayoutTimer) } catch { /* ignore */ } }
				pdfState.relayoutTimer = setTimeout(() => { pdfState.relayoutTimer = null; pdfjsApplySize() }, 200);
			}

			/** 只认同一个节点：每次渲染都重新 observe 的话，ResizeObserver 会立刻回调，也会闪 */
			function pdfjsWatchSize(node) {
				if (node === pdfState.sizeTarget) return;
				if (pdfState.sizeObserver !== null) {
					try { pdfState.sizeObserver.disconnect() } catch { /* ignore */ }
					pdfState.sizeObserver = null;
				}
				pdfState.sizeTarget = node || null;
				if (!node || typeof ResizeObserver !== "function") return;
				pdfState.sizeObserver = new ResizeObserver(() => pdfjsRelayout());
				try { pdfState.sizeObserver.observe(node) } catch { pdfState.sizeObserver = null; }
			}

			/** 固定的 ref 回调（每次渲染都新建函数会让 React 反复解绑/重绑，进而引发上面那个闪烁） */
			function pdfjsFrameRef(node) {
				pdfState.frame = node || null;
				pdfjsWatchSize(pdfState.frame);
			}
			function pdfjsStackRef(node) {
				pdfState.stack = node || null;
			}

			// ── 回到上次读到的位置（文字模式与版式模式各记各的）──
			const scrollMemory = { textBox: null, textAt: 0, layoutAt: 0 };

			function readerTextBoxRef(node) {
				scrollMemory.textBox = node || null;
			}

			/** 量出每个块在滚动内容里的位置（用相对容器的差值，不受 offsetParent 影响） */
			function boxesOf(container, selector) {
				if (!container || typeof container.querySelectorAll !== "function" || typeof container.getBoundingClientRect !== "function") return [];
				let base = 0;
				let nodes = null;
				try {
					base = container.getBoundingClientRect().top - (container.scrollTop || 0);
					nodes = container.querySelectorAll(selector);
				} catch { return []; }
				const out = [];
				for (let i = 0; nodes && i < nodes.length; i++) {
					const node = nodes[i];
					if (!node || typeof node.getBoundingClientRect !== "function") continue;
					const rect = node.getBoundingClientRect();
					out.push({ top: rect.top - base, height: rect.height });
				}
				return out;
			}

			function scrollBoxOf(mode) {
				return mode === "text" ? scrollMemory.textBox : pdfState.stack;
			}

			/** 记住读到哪（滚动时最多 1.2 秒写一次；切页/切模式时强制写） */
			function rememberScroll(mode, force, paperId) {
				const paper = paperId ? state.papers.find((item) => item && item.id === paperId) : activePaper();
				if (paper === null) return;
				if (!paper) return;
				const box = scrollBoxOf(mode);
				if (!box) return;
				const now = Date.now();
				if (force !== true) {
					const last = mode === "text" ? scrollMemory.textAt : scrollMemory.layoutAt;
					if (now - last < 1200) return;
				}
				if (mode === "text") scrollMemory.textAt = now; else scrollMemory.layoutAt = now;
				const at = scrollIndexAt(boxesOf(box, mode === "text" ? "[data-seg]" : "[data-page]"), box.scrollTop || 0);
				if (at === null) return;
				const progress = progressOf(paper);
				const scroll = progress.scroll || { text: null, layout: null };
				const before = scroll[mode];
				if (before && before.i === at.i && Math.abs(before.r - at.r) < 0.02) return;
				const next = { text: scroll.text || null, layout: scroll.layout || null };
				next[mode] = at;
				patchPaper(paper.id, { progress: Object.assign({}, progress, { scroll: next }) });
			}

			/** 回到上次读到的位置 */
			function restoreScroll(mode, paperId) {
				const paper = paperId ? state.papers.find((item) => item && item.id === paperId) : activePaper();
				if (paper === null) return;
				if (!paper) return;
				const saved = (progressOf(paper).scroll || {})[mode];
				if (!saved) return;
				const box = scrollBoxOf(mode);
				if (!box) return;
				const top = scrollTopFor(boxesOf(box, mode === "text" ? "[data-seg]" : "[data-page]"), saved);
				if (top === null) return;
				try { box.scrollTop = top } catch { /* ignore */ }
			}

			/** 铺页面骨架：先只给尺寸（滚到附近才真正画），这样 20 页也不会一上来就全渲染 */
			function pdfjsMount() {
				const stack = pdfStackOf();
				if (stack === null) return;
				const pages = pdfState.pages;
				const width = pdfjsPageWidth(state.pdfjsScale);
				pdfState.width = width;
				stack.textContent = "";
				for (let i = 0; i < pages.length; i++) {
					const entry = pages[i];
					const box = document.createElement("div");
					box.className = "lit-pdfpage is-loading";
					box.setAttribute("data-page", String(i));
					box.style.width = width + "px";
					box.style.height = Math.round(width * (entry.base.height / entry.base.width)) + "px";
					const canvas = document.createElement("canvas");
					box.appendChild(canvas);
					const no = document.createElement("div");
					no.className = "lit-pdfpage-no";
					no.textContent = "第 " + (i + 1) + " / " + pages.length + " 页";
					box.appendChild(no);
					stack.appendChild(box);
					entry.node = box;
					entry.canvas = canvas;
					entry.layer = null;
					entry.rendered = false;
					entry.busy = false;
				}
				pdfjsObserve();
				// 页面都铺好了：回到上次读到的那一页
				restoreScroll("layout");
			}

			/** 滚到附近才渲染；没有 IntersectionObserver 就老实全画（最多 20 页） */
			function pdfjsObserve() {
				if (pdfState.observer !== null) {
					try { pdfState.observer.disconnect() } catch { /* ignore */ }
					pdfState.observer = null;
				}
				const pages = pdfState.pages;
				if (typeof IntersectionObserver === "function") {
					const observer = new IntersectionObserver((entries) => {
						for (const item of entries) {
							if (item.isIntersecting !== true) continue;
							const index = Number(item.target && item.target.getAttribute ? item.target.getAttribute("data-page") : NaN);
							if (!Number.isFinite(index)) continue;
							pdfjsRender(index);
							pdfjsMarkRead(index);
						}
					}, { root: pdfState.stack, rootMargin: "500px 0px" });
					pdfState.observer = observer;
					for (const entry of pages) {
						if (entry.node === null) continue;
						try { observer.observe(entry.node) } catch { /* ignore */ }
					}
					return;
				}
				for (let i = 0; i < Math.min(pages.length, 20); i++) { pdfjsRender(i); pdfjsMarkRead(i) }
			}

			async function pdfjsRender(index) {
				const entry = pdfState.pages[index];
				if (!entry || entry.rendered === true || entry.busy === true) return;
				if (pdfStackOf() === null || !entry.canvas || !entry.node) return;
				entry.busy = true;
				try {
					const cssWidth = entry.node.clientWidth || pdfjsPageWidth(state.pdfjsScale);
					const viewport = entry.page.getViewport({ scale: cssWidth / entry.base.width });
					const dpr = Math.min((typeof window !== "undefined" && window.devicePixelRatio) || 1, 2);
					const canvas = entry.canvas;
					canvas.width = Math.max(1, Math.floor(viewport.width * dpr));
					canvas.height = Math.max(1, Math.floor(viewport.height * dpr));
					canvas.style.width = "100%";
					canvas.style.height = "100%";
					const task = entry.page.render({
						canvasContext: canvas.getContext("2d"),
						viewport,
						transform: dpr === 1 ? undefined : [dpr, 0, 0, dpr, 0, 0],
					});
					await task.promise;
					entry.layer = await pdfjsTextLayer(entry.page, entry.node, viewport);
					entry.rendered = true;
					entry.node.className = "lit-pdfpage";
				} catch (error) {
					entry.node.className = "lit-pdfpage is-bad";
					set({ pdfjsErr: "第 " + (index + 1) + " 页渲染失败：" + errText(error) });
				}
				entry.busy = false;
			}

			let pdfMeasureCtx = null;
			function pdfTextWidth(text, fontHeight) {
				if (typeof document === "undefined" || typeof document.createElement !== "function") return 0;
				try {
					if (pdfMeasureCtx === null) {
						const probe = document.createElement("canvas");
						pdfMeasureCtx = probe && typeof probe.getContext === "function" ? probe.getContext("2d") : false;
					}
				} catch { pdfMeasureCtx = false; }
				if (pdfMeasureCtx === null || pdfMeasureCtx === false) return 0;
				try {
					pdfMeasureCtx.font = fontHeight + "px sans-serif";
					return pdfMeasureCtx.measureText(String(text)).width;
				} catch { return 0; }
			}

			/** 透明文字层：文字不可见，但可以选中（选中后走和文字模式一样的勾划翻译） */
			async function pdfjsTextLayer(page, box, viewport) {
				const content = await page.getTextContent();
				const layer = document.createElement("div");
				layer.className = "lit-pdftext";
				const items = content && Array.isArray(content.items) ? content.items : [];
				let prev = null;
				for (const item of items) {
					const text = item && typeof item.str === "string" ? item.str : "";
					if (text.trim().length === 0) continue;
					const at = textItemBox(item, viewport);
					if (at === null) continue;
					// 跨行保留换行，同一行按几何间隙补空格，避免两个英文单词粘连。
					const newLine = prev !== null && (prev.hasEOL || Math.abs(prev.at.top - at.top) > Math.max(2, at.fontHeight * 0.6));
					if (prev !== null && (newLine || needsWordSpace(prev.text, prev.at, text, at))) {
						const space = document.createElement("span");
						space.className = "lit-pdfspace";
						space.textContent = newLine ? "\n" : " ";
						space.style.left = (prev.at.left + prev.at.width) + "px";
						space.style.top = at.top + "px";
						space.style.fontSize = at.fontHeight + "px";
						layer.appendChild(space);
					}
					const span = document.createElement("span");
					span.textContent = text;
					span.style.left = at.left + "px";
					span.style.top = at.top + "px";
					span.style.fontSize = at.fontHeight + "px";
					const measured = pdfTextWidth(text, at.fontHeight);
					if (measured > 0 && at.width > 0) {
						const ratio = at.width / measured;
						if (ratio > 0.25 && ratio < 4) span.style.transform = "scaleX(" + ratio.toFixed(3) + ")";
					}
					layer.appendChild(span);
					prev = { text, at, hasEOL: item.hasEOL === true };
				}
				box.appendChild(layer);
				return layer;
			}

			/** 版式模式按「读到第几页」记进度，只前进不后退 */
			function pdfjsMarkRead(index) {
				const pages = pdfState.pages;
				if (pages.length === 0) return;
				if (Date.now() < pdfState.suppressProgressUntil) return;
				if (index <= pdfState.seen) return;
				pdfState.seen = index;
				const paper = activePaper();
				if (paper === null) return;
				const progress = progressOf(paper);
				const pct = Math.round(((index + 1) / pages.length) * 100);
				if (pct <= progress.percent) return;
				patchPaper(paper.id, { progress: Object.assign({}, progress, { percent: pct, lastReadAt: Date.now() }) });
			}

			function pdfjsSetScale(next) {
				const value = Math.max(0.6, Math.min(3, Math.round(next * 100) / 100));
				set({ pdfjsScale: value });
				const paper = activePaper();
				if (paper !== null && progressOf(paper).layoutScale !== value) {
					const progress = progressOf(paper);
					patchPaper(paper.id, { progress: Object.assign({}, progress, { layoutScale: value }) });
				}
				pdfState.width = 0;   // 缩放变了，就算宽度数字碰巧相同也要重排
				pdfjsApplySize();
			}

			function PdfLayout(props) {
				const s = useStore();
				const pdfName = props.pdfName;
				React.useEffect(() => {
					if (pdfName.length === 0) return undefined;
					const paper = state.papers.find((item) => item && item.id === props.paperId);
					const savedScale = paper ? progressOf(paper).layoutScale : 1;
					if (state.pdfjsScale !== savedScale) {
						set({ pdfjsScale: savedScale });
						pdfState.width = 0;
					}
					pdfjsCheck();
					return () => {
						if (pdfState.observer !== null) {
							try { pdfState.observer.disconnect() } catch { /* ignore */ }
							pdfState.observer = null;
						}
						rememberScroll("layout", true, props.paperId);
					};
				}, [pdfName, props.paperId]);
				const ready = s.pdfjsReady === true;
				if (pdfName.length === 0) {
					return h("div", { className: "lit-reader-text lit-reader-layout" },
						h("div", { className: "lit-empty" }, "这篇还没有导入 PDF，导进来才能看真实版式。"));
				}
				return h("div", { className: "lit-reader-text lit-reader-layout", ref: pdfjsFrameRef, tabIndex: 0, "aria-label": "PDF 原文，可勾画文字" },
					props.controlsOpen ? h("div", { className: "lit-pdfbar" },
						h("span", { className: "lit-small" }, ready ? "真实版式 · 共 " + (s.pdfjsPages || 0) + " 页" : "真实版式"),
						h("span", { className: "lit-grow" }),
						h("button", { className: "lit-mini", style: { marginTop: 0 }, disabled: !ready || s.pdfjsScale <= 0.6, onClick: () => pdfjsSetScale(s.pdfjsScale - 0.2) }, "缩小"),
						h("span", { className: "lit-small" }, Math.round((s.pdfjsScale || 1) * 100) + "%"),
						h("button", { className: "lit-mini", style: { marginTop: 0 }, disabled: !ready || s.pdfjsScale >= 3, onClick: () => pdfjsSetScale(s.pdfjsScale + 0.2) }, "放大"),
						h("button", { className: "lit-mini", style: { marginTop: 0 }, disabled: !ready, onClick: () => pdfjsSetScale(1) }, "适应宽度"),
						h("button", { className: "lit-mini", style: { marginTop: 0 }, disabled: !ready, onClick: () => pdfjsOpen() }, "重新加载"),
						h("a", { className: "lit-mini", style: { marginTop: 0, textDecoration: "none" }, href: pdfFileUrl(pdfName), target: "_blank", rel: "noreferrer" }, "新窗口打开")) : null,
					s.pdfjsErr !== "" ? h("div", { className: "lit-reader-progress" }, h("span", { className: "lit-err" }, s.pdfjsErr)) : null,
					s.pdfjsMsg !== "" ? h("div", { className: "lit-reader-progress" }, h("span", { className: "lit-ok" }, s.pdfjsMsg)) : null,
					ready ? null : h("div", { className: "lit-pdfgate" },
						s.pdfjsReady === null
							? (s.pdfjsErr !== ""
								? h("div", null,
									h("div", { className: "lit-small" }, "暂时无法确认 PDF.js 是否可用。请重启应用后重试；PDF.js 通常已随应用安装。"),
									h("button", { className: "lit-btn lit-btn-primary", style: { marginTop: "8px" }, onClick: () => pdfjsCheck() }, "重试"))
								: h("div", { className: "lit-small" }, "正在检查本地有没有 pdf.js…"))
							: h("div", null,
								h("div", { className: "lit-small" }, "版式模式要自己把 PDF 画成真实页面，需要一次性把 Mozilla 的 pdf.js 下载到本地（约 1.2MB，之后完全离线；只下一次）。"),
								h("button", { className: "lit-btn lit-btn-primary", style: { marginTop: "8px" }, disabled: s.pdfjsBusy, onClick: () => pdfjsDownload() }, s.pdfjsBusy ? "下载中…" : "下载并启用版式"),
								h("div", { className: "lit-small", style: { marginTop: "6px" } }, "下不动也没关系：把 pdf.min.mjs 和 pdf.worker.min.mjs 手动放进数据目录的 vendor\\pdfjs 里，再点上面的「重新加载」。" + (s.pdfjsHint ? "（" + s.pdfjsHint + "）" : "")))),
					h("div", { className: "lit-pdfstack", ref: pdfjsStackRef, onScroll: () => rememberScroll("layout") }));
			}

			function ReaderLeft(props) {
				const s = useStore();
				const segs = props.segs;
				const total = segs.length;
				const readCount = Math.max(0, Math.min(total, (props.readSegments || 0) + 1));
				const readPct = total === 0 ? 0 : Math.round((readCount / total) * 100);
				const pdfName = props.pdfName;
				const want = props.readerMode || (s.ui && typeof s.ui.readerMode === "string" ? s.ui.readerMode : "text");
				const mode = pdfName ? (want === "pdf" ? "pdf" : (want === "layout" ? "layout" : "text")) : "text";
				const controlsOpen = !s.ui || s.ui.readerPdfControlsOpen !== false;
				const view = s.readerView;
				const barPct = mode === "layout" ? Math.max(0, Math.min(100, props.percent || 0)) : readPct;
				const split = splitNow();
				// 文字模式：挂载/换篇/换模式时回到上次读到的段；离开时把位置写回
				React.useEffect(() => {
						restoreScroll("text", props.paperId);
						return () => { rememberScroll("text", true, props.paperId) };
				}, [props.paperId, mode]);
				return h("div", { className: "lit-reader-pane", style: { flex: "0 0 auto", width: split + "%" } },
					h("div", { className: "lit-reader-head" },
						h("span", { className: "lit-reader-title" }, "PDF 原文"),
						h("span", { className: "lit-grow" }),
						controlsOpen ? h("button", {
							className: "lit-mini",
							style: { marginTop: 0, display: "inline-flex", alignItems: "center", gap: "4px" },
							title: "左右占比 " + split + " : " + (100 - split) + " —— 点一下换一档，也可以直接拖中间那条分隔条（双击对半）",
							onClick: cycleSplit,
						}, h(SplitIcon, { pct: split }), split + ":" + (100 - split))
							: h("span", { className: "lit-small" }, (mode === "layout" ? "版式进度 " + (props.percent || 0) + "%" : "阅读进度 " + readPct + "%")),
						controlsOpen && pdfName
							? h("span", { className: "lit-hset" },
								h("button", { className: mode === "text" ? "is-on" : "", title: "文字模式：勾画正文后按右侧选定的方式处理", onClick: () => setReaderMode("text") }, "文字"),
								h("button", { className: mode === "layout" ? "is-on" : "", title: "版式模式：在真实 PDF 页面中勾画文字，可加入勾画篮", onClick: () => setReaderMode("layout") }, "版式"),
								h("button", { className: mode === "pdf" ? "is-on" : "", title: "原生查看器：搜索、打印用（这种模式下勾划不回传）", onClick: () => setReaderMode("pdf") }, "原生"))
							: null,
						h("button", {
							className: "lit-mini",
							style: { marginTop: 0 },
							"aria-expanded": controlsOpen,
							title: controlsOpen ? "收起原文工具栏，为 PDF 阅读留出更多空间" : "展开原文工具栏",
							onClick: () => setReaderUi({ readerPdfControlsOpen: !controlsOpen }),
						}, controlsOpen ? "收起" : "展开")),
					controlsOpen ? h("div", { className: "lit-reader-progress" },
						h("div", { className: "lit-bar" }, h("div", { className: "lit-bar-fill", style: { width: barPct + "%" } })),
						mode === "layout"
							? h("div", { className: "lit-small" }, "版式模式：滚到哪记到哪" + (s.pdfjsPages > 0 ? "（共 " + s.pdfjsPages + " 页）" : ""))
							: h("div", { className: "lit-small" }, "阅读进度 " + readCount + " / " + total + " 段（" + readPct + "%）　·　往下读会自动记录")) : null,
					mode === "layout"
						? h(PdfLayout, { pdfName, paperId: props.paperId, controlsOpen })
						: mode === "pdf"
							? h("iframe", {
								className: "lit-pdf",
								src: pdfFileUrl(pdfName),
								title: "PDF 原文",
							})
							: h("div", {
								className: "lit-reader-text",
								ref: readerTextBoxRef,
								tabIndex: 0,
								"aria-label": "原文正文，可勾画文字",
								onScroll: handleReaderScroll,
							}, total === 0
								? h("div", { className: "lit-empty" }, "还没有原文：导入 PDF 会自动切成段；已经有 PDF 的话点「重新抽取文字」重建分段")
								: segs.map((seg, index) => h("div", {
									key: seg.id,
									"data-seg": String(index),
									className: "lit-reader-seg"
										+ (seg.zh && seg.zh.trim().length > 0 ? " is-done" : "")
										+ (view && view.kind === "seg" && view.index === index ? " is-current" : ""),
									onClick: () => selectSegment(index, true),
								},
									h("div", { className: "lit-reader-seg-no" },
										"第 " + (index + 1) + " 段" + (seg.zh && seg.zh.trim().length > 0 ? " · 已译" : "")),
									h("div", { className: "lit-reader-seg-text" }, seg.en)))));
			}

			function ReaderRight(props) {
				const s = useStore();
				const segs = props.segs;
				const total = segs.length;
				const picked = pickedOf();
				const batch = batchOf();
				const done = segs.filter((x) => x.zh && x.zh.trim().length > 0).length;
				const pct = total === 0 ? 0 : Math.round((done / total) * 100);
				const view = s.readerView;
				const sel = s.sel;
				let current = null;
				if (view && view.kind === "seg" && segs[view.index]) {
					current = { en: segs[view.index].en, zh: segs[view.index].zh || "", segIndex: view.index };
				} else if (view && view.kind === "picked") {
					const entry = picked.find((x) => x.id === view.id);
					if (entry) current = Object.assign({}, entry, { zh: entry.zh || "" });
				}
				const hasSel = !!(sel && sel.text.length > 0);
				const selectionInBasket = hasSel && batch.some((item) => selectionKey(item) === selectionKey(sel) && (!item.sourceStamp || item.sourceStamp === sel.sourceStamp));
				const paper = props.paper;
				const maps = mindsOf(paper);
				const canMind = mindSource() !== null;
				const controlsOpen = !s.ui || s.ui.readerRightControlsOpen !== false;
				const toolsOpen = s.ui && s.ui.readerToolsOpen === true;
				const autoSize = !s.ui || s.ui.readerAutoSize !== false;
				const originalOpen = !s.ui || s.ui.readerOriginalOpen !== false;
				const historyOpen = s.ui && s.ui.readerHistoryOpen === true;
				const basketStatusDuplicate = batch.length > 0 && /^(?:这段已在勾画篮中|已加入勾画篮[：:])/.test(s.txStatus || "");
				const canTranslateSegment = current !== null && typeof current.segIndex === "number" && !current.zh.trim();
				const mergedStatus = /^已合并翻译\s+(\d+)\s+条勾画（([\d,]+)\s*字）/.exec(s.txStatus || "");
				return h("div", { className: "lit-reader-pane lit-reader-right" },
					h("div", { className: "lit-reader-head" },
						h("span", { className: "lit-hset" },
							h("button", { className: s.mindTab ? "" : "is-on", onClick: () => set({ mindTab: false }) }, "译文"),
							h("button", {
								className: s.mindTab ? "is-on" : "",
								title: "把勾划的段落总结成思维导图",
								onClick: () => set({ mindTab: true }),
							}, "导图" + (maps.length > 0 ? " " + maps.length : ""))),
						h("span", { className: "lit-grow" }),
						controlsOpen ? h("button", {
							className: "lit-btn lit-btn-primary",
							disabled: s.mindBusy || !canMind,
							title: canMind ? "把当前选段或勾画内容总结成思维导图" : "先在左侧勾画一段文字，或点选一段正文",
							onClick: () => summarizeCurrent(),
						}, s.mindBusy ? "总结中…" : "总结成导图") : null,
						controlsOpen ? h("button", {
							className: "lit-btn lit-btn-primary",
							disabled: s.txBusy || (!hasSel && !canTranslateSegment),
							onClick: () => hasSel ? translatePicked() : translateSegmentAt(current.segIndex),
						}, s.txBusy ? "翻译中…" : hasSel ? "翻译选区" : canTranslateSegment ? "翻译这一段" : "翻译选区") : null,
						controlsOpen && s.txBusy ? h("button", {
							className: "lit-btn",
							disabled: !!(s.txTaskId && !(state.taskFeed.find((task) => task.id === s.txTaskId) || {}).canCancel),
							onClick: () => s.txTaskId ? stopTask(s.txTaskId) : set({ txAbort: true }),
						}, (s.txTaskId && (state.taskFeed.find((task) => task.id === s.txTaskId) || {}).cancelLabel) || "停止等待") : null,
						controlsOpen ? h("button", {
							className: "lit-btn",
							"aria-expanded": toolsOpen,
							title: toolsOpen ? "收起设置，为原文和译文腾出阅读空间" : "展开勾画方式、术语标注、译文高度和导图工具",
							onClick: () => setReaderUi({ readerToolsOpen: !toolsOpen }),
						}, toolsOpen ? "收起工具" : "展开工具") : null,
						h("button", {
							className: "lit-mini",
							"aria-expanded": controlsOpen,
							title: controlsOpen ? "收起译文控制区，为正文和译文留出更多空间" : "展开译文控制区",
							onClick: () => setReaderUi({ readerRightControlsOpen: !controlsOpen }),
						}, controlsOpen ? "收起" : "展开")),
					controlsOpen ? h("div", { className: "lit-reader-summary" },
						h("span", { className: "lit-reader-stat", title: "已译 " + done + " / " + total + " 段（" + pct + "%），选区译文 " + picked.length + " 条" }, "已译 " + done + "/" + total + " 段 · " + picked.length + " 条"),
						hasSel ? h("button", {
							className: "lit-mini", "aria-expanded": !!s.readerSelectionOpen,
							title: "展开或收起当前选区的原文预览",
							onClick: () => set({ readerSelectionOpen: !s.readerSelectionOpen }),
						}, "选区 " + sel.text.length + " 字") : null,
						h("button", {
							className: "lit-mini", "aria-expanded": !!(s.ui && s.ui.basketOpen === true),
							title: "展开勾画篮，核对原文后合并或逐条翻译",
							onClick: () => setBasketOpen(!(s.ui && s.ui.basketOpen === true)),
						}, "勾画篮 " + batch.length),
						h("span", {
							className: "lit-reader-status" + (mergedStatus ? " is-merged" : ""),
							title: basketStatusDuplicate || mergedStatus ? "" : s.txStatus || "",
						}, basketStatusDuplicate || mergedStatus ? "" : s.txStatus || ""),
						mergedStatus ? h("span", {
							className: "lit-reader-merged-status",
							title: s.txStatus,
						}, "已合并 " + mergedStatus[1] + " 条 · " + mergedStatus[2] + " 字") : null) : null,
					controlsOpen && toolsOpen ? h("div", { className: "lit-reader-tools" },
						h("div", { className: "lit-reader-tool-options" },
							h("label", { className: "lit-small", style: { display: "inline-flex", alignItems: "center", gap: "5px", cursor: "pointer" } },
								h("input", {
									type: "checkbox", checked: s.txAnnotate,
									onChange: (e) => set({ txAnnotate: e.target.checked }),
								}), "术语后标注英文"),
							h(HeightPicker, null)),
						h("div", { className: "lit-reader-progress" },
							h("div", { className: "lit-bar" }, h("div", { className: "lit-bar-fill", style: { width: pct + "%" } })),
							h("div", { className: "lit-small" }, "翻译进度 " + done + " / " + total + " 段（" + pct + "%）")),
						h("div", { className: "lit-reader-actions" },
							h("label", { className: "lit-selection-mode" }, "勾画后",
								h("select", { className: "lit-input", value: selectionMode(s.ui), onChange: (e) => setSelectionMode(e.target.value) },
									h("option", { value: "basket" }, "加入勾画篮"),
									h("option", { value: "manual" }, "点击翻译"),
									h("option", { value: "instant" }, "立即翻译"))),
							h("button", {
								className: "lit-btn" + (s.reextractArmed === true ? " lit-btn-primary" : ""),
								disabled: s.txBusy || !(paper && paper.pdf),
								title: "用数据目录里的 PDF 原件重新抽一遍文字（抽成乱码、或想让 pdf.js 再抽一次时用）",
								onClick: () => reextractPdf(),
							}, s.reextractArmed === true ? "再点一次确认重抽" : "重新抽取文字")),
						s.txStatus ? h("div", { className: "lit-reader-progress" }, h("span", { className: "lit-ok" }, s.txStatus)) : null) : null,
					paper && paper.pdf && paper.pdf.lowConfidence === true
						? h("div", { className: "lit-reader-progress" },
							h("span", { className: "lit-warn" }, "⚠ 这份 PDF 抽出来的文字可读度只有 " + (paper.pdf.confidence || 0)
								+ "%（多半是嵌入字体缺映射，扫描件也会这样）。建议：切到「版式」看真实版面，或点「重新抽取文字」让 pdf.js 再抽一次。"))
						: null,
					s.mindMsg !== "" && s.mindTab ? h("div", { className: "lit-reader-progress" }, h("span", { className: "lit-ok" }, s.mindMsg)) : null,
					s.mindErr !== "" ? h("div", { className: "lit-reader-progress" }, h("span", { className: "lit-err" }, s.mindErr)) : null,
					s.ui && s.ui.readerMode === "pdf" && props.pdfName
						? h("div", { className: "lit-reader-progress" }, h("span", { className: "lit-warn" }, "现在是 PDF 模式：浏览器内嵌查看器里选中的文字拿不到，勾划不会翻译。点左栏的「文字」或「版式」切回来再勾划。"))
						: null,
					s.txError !== null ? h("div", { className: "lit-reader-progress" }, h("span", { className: "lit-err" }, s.txError)) : null,
					hasSel && s.readerSelectionOpen ? h("div", { className: "lit-selection-preview" },
						h("details", null,
							h("summary", null, selectionLabel(sel) + " · " + sel.text.length + " 字" + (selectionInBasket ? " · 已加入勾画篮" : " · 当前选区") + "（展开原文）"),
							h("div", { className: "lit-selection-text" }, sel.text)),
						!selectionInBasket ? h("button", { className: "lit-mini", onClick: () => addToBatch(sel) }, "加入篮子") : null,
						h("button", { className: "lit-mini", title: "清除当前选区，已收集的勾画仍保留在篮中", onClick: clearSelection }, "清除选区")) : null,
					(batch.length > 0 || (s.ui && s.ui.basketOpen === true)) ? h("div", { className: "lit-basket" + (s.ui && s.ui.basketOpen === false ? " is-shut" : "") },
						h("div", { className: "lit-basket-h" },
							h("button", {
								className: "lit-basket-toggle",
								title: s.ui && s.ui.basketOpen === false ? "展开勾划篮" : "收起勾划篮（腾地方读原文/译文）",
								onClick: () => setBasketOpen(!(s.ui && s.ui.basketOpen !== false)),
							}, h(ChevronIcon, { open: !(s.ui && s.ui.basketOpen === false) })),
							h("span", {
								className: "lit-small lit-basket-title",
								title: "点这里也能收起/展开",
								onClick: () => setBasketOpen(!(s.ui && s.ui.basketOpen !== false)),
							}, "勾画篮：" + batch.length + " 条 · " + batchChars() + " 字" + (batchMode() ? "（稍后一起翻译）" : "")),
							s.ui && s.ui.basketOpen === false
								? null
								: h("span", { className: "lit-basket-acts" },
									h("span", { className: "lit-grow" }),
								(current === null || !controlsOpen) ? h("button", {
									className: "lit-btn lit-btn-primary",
									disabled: s.txBusy || batch.length === 0,
									title: batch.length === 0 ? "先在左侧原文勾画文字并加入勾画篮" : "将勾画篮中的内容合并成一段并翻译",
									onClick: () => translateBasket(),
								}, s.txBusy ? "合并翻译中…" : "合并翻译") : null,
									h("button", { className: "lit-btn", disabled: s.txBusy || batch.length === 0, onClick: () => translateBasketEach() }, "逐条翻译"),
									h("button", { className: "lit-btn", disabled: batch.length === 0, onClick: () => set({ batchPreview: s.batchPreview === "" ? mergedBatchText() : "" }) },
										s.batchPreview === "" ? "看合并后的原文" : "收起原文"),
									h("button", { className: "lit-btn", disabled: s.txBusy || batch.length === 0, onClick: () => clearBatch() }, "清空"))),
						(s.ui && s.ui.basketOpen === false) ? null : (batch.length === 0
							? h("div", { className: "lit-small" }, "在左侧原文中勾画文字，松手后自动收集。可合并翻译，也可逐条翻译；每篇文献的篮子分别保存。")
							: batch.map((item, i) => h("div", { key: item.id, className: "lit-basket-item" },
								h("span", { className: "lit-basket-no" }, String(i + 1) + "."),
								h("button", { className: "lit-basket-text lit-basket-preview-button", title: "点击核对原文：" + item.text, onClick: () => previewBatchItem(item) },
									selectionLabel(item) + "　" + String(item.text).slice(0, 60)),
								h("button", { className: "lit-mini", onClick: () => removeFromBatch(item.id) }, "移出")))),
						(s.ui && s.ui.basketOpen === false) || s.batchPreview === "" ? null : h("textarea", {
							className: "lit-mind-text",
							readOnly: true,
							value: s.batchPreview,
							onClick: (e) => { if (e && e.target && typeof e.target.select === "function") e.target.select() },
						}))
						: null,
					h("div", { className: "lit-reader-body" + (s.mindTab ? "" : " lit-reading-content") },
						s.mindTab ? h(MindPanel, { paper }) : (current === null
							? h("div", { className: "lit-empty" }, selectionMode(s.ui) === "basket"
								? "在左侧原文中勾画文字，松手后会自动加入勾画篮。展开篮子后，选择合并翻译或逐条翻译，译文会显示在这里。"
								: selectionMode(s.ui) === "manual" ? "在左侧原文中勾画文字，核对当前选区后点击「翻译选区」。"
									: "在左侧原文中勾画文字，松手后立即翻译；已有翻译任务时，新选区会保存到勾画篮。")
							: h("div", {
								key: view.kind === "picked" ? view.id : "seg-" + view.index,
								className: "lit-current-translation" + (autoSize ? "" : " is-fixed"),
							},
								controlsOpen ? h("div", { className: "lit-current-source" + (originalOpen ? "" : " is-shut") },
									h("div", { className: "lit-source-head" },
										h("span", { className: "lit-small", title: selectionLabel(current) + " · 原文 " + current.en.length + " 字" },
											selectionLabel(current) + " · 原文 " + current.en.length + " 字"),
										h("button", {
											className: "lit-btn lit-btn-primary lit-source-merge",
											disabled: s.txBusy || batch.length === 0,
								title: batch.length === 0 ? "先在左侧原文勾画文字并加入勾画篮" : "将勾画篮中的内容合并成一段并翻译",
											onClick: () => translateBasket(),
										}, s.txBusy ? "合并翻译中…" : "合并翻译"),
										h("button", {
											className: "lit-mini", "aria-expanded": originalOpen,
											onClick: () => setReaderUi({ readerOriginalOpen: !originalOpen }),
										}, originalOpen ? "收起原文" : "展开原文")),
									originalOpen ? h("div", { className: "lit-source-original" }, current.en) : null) : null,
								h("label", { className: "lit-translation-editor" },
									h("span", { className: "lit-small" }, "译文（可编辑）"),
									h(Area, {
										style: autoSize ? { flex: "1 1 0", minHeight: 0, resize: "none" } : { minHeight: txHeightValue(s.ui) },
										value: current.zh,
										placeholder: "这一段 / 选区的中文译文…（可以直接改）",
										onChange: (value) => {
											if (view && view.kind === "seg") updateSegment(segs[view.index].id, { zh: value });
											else if (view && view.kind === "picked") {
												txWritePicked(pickedOf().map((x) => (x.id === view.id ? Object.assign({}, x, { zh: value }) : x)));
											}
										},
									})))),
						!s.mindTab && (done > 0 || picked.length > 0) ? h("div", { className: "lit-translation-history" },
							h("button", {
								className: "lit-history-toggle", "aria-expanded": historyOpen,
								onClick: () => setReaderUi({ readerHistoryOpen: !historyOpen }),
							}, h(ChevronIcon, { open: historyOpen }), "译文记录（" + (done + picked.length) + "）", historyOpen ? "收起" : "展开查看"),
							historyOpen ? h("div", { className: "lit-history-content" },
								done > 0 ? h("div", null,
								h("div", { className: "lit-small", style: { marginTop: "4px" } }, "已译段落（点一下切过去）："),
								segs.map((seg, index) => (seg.zh && seg.zh.trim().length > 0)
									? h("div", {
										key: seg.id,
										className: "lit-picked" + (view && view.kind === "seg" && view.index === index ? " is-current" : ""),
										onClick: () => selectSegment(index),
									}, "第 " + (index + 1) + " 段　" + seg.zh.trim().slice(0, 34))
									: null))
							: null,
						picked.length > 0
							? h("div", null,
								h("div", { className: "lit-small", style: { marginTop: "4px" } }, "勾划选区译文："),
								picked.map((entry) => h("div", {
									key: entry.id,
									className: "lit-picked lit-picked-row" + (view && view.kind === "picked" && view.id === entry.id ? " is-current" : ""),
									onClick: () => { clearSelection(); set({ readerView: { kind: "picked", id: entry.id } }); },
								},
									h("span", { className: "lit-picked-text" }, selectionLabel(entry) + "　" + String(entry.zh || "").slice(0, 32)),
									h("button", {
										className: "lit-mini",
										onClick: (e) => { e.stopPropagation(); removePicked(entry.id); },
									}, "删除"))))
								: null) : null) : null));
			}

			function ReaderView() {
				const s = useStore();
				React.useEffect(() => { ensureLoaded(); }, []);
				// 只响应从原文区开始的手势；松手落在区外时仍裁出原文，按钮点击不重收旧选区。
				React.useEffect(() => {
					let pointerRoot = null;
					let keyboardRoot = null;
					let gesturePaperId = null;
					const sourceRoot = (target) => {
						const element = target && target.nodeType === 1 ? target : target && target.parentElement;
						if (!element || element.closest("button, a, input, textarea, select, .lit-pdfbar, .lit-reader-seg-no")) return null;
						return readerTextRoot(element);
					};
					const onDown = (event) => {
						pointerRoot = event.button === 0 && !state.splitDragging ? sourceRoot(event.target) : null;
						gesturePaperId = state.activeId;
					};
					const onUp = (event) => {
						const root = pointerRoot;
						pointerRoot = null;
						if (root && event.button === 0 && gesturePaperId === state.activeId && !state.splitDragging) captureSelection(root);
					};
					const onKeyDown = (event) => {
						const root = sourceRoot(event.target);
						if (root && event.shiftKey && ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End", "PageUp", "PageDown"].indexOf(event.key) >= 0) keyboardRoot = root;
						if (root && event.key === "Escape") { keyboardRoot = null; clearSelection(); }
					};
					const onKeyUp = (event) => {
						if (event.key === "Shift" && keyboardRoot) { const root = keyboardRoot; keyboardRoot = null; captureSelection(root); }
						else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "a") {
							const root = sourceRoot(event.target);
							if (root) captureSelection(root);
						}
					};
					document.addEventListener("mousedown", onDown);
					document.addEventListener("mouseup", onUp);
					document.addEventListener("keydown", onKeyDown);
					document.addEventListener("keyup", onKeyUp);
					return () => {
						document.removeEventListener("mousedown", onDown);
						document.removeEventListener("mouseup", onUp);
						document.removeEventListener("keydown", onKeyDown);
						document.removeEventListener("keyup", onKeyUp);
					};
				}, [s.activeId, s.ui && s.ui.readerMode]);
				const paper = activePaper();
				const segs = segsOf();
				const progress = paper === null ? blankProgress() : progressOf(paper);
				const pdfName = paper && paper.pdf && paper.pdf.name ? String(paper.pdf.name) : "";
				return h("div", { className: "lit-reader" + (s.splitDragging === true ? " is-splitting" : "") },
					h(ReaderLeft, { segs, pdfName, paperId: paper ? paper.id : "", readerMode: progress.readerMode, readSegments: progress.readSegments || 0, percent: progress.percent || 0 }),
					h("div", {
						className: "lit-split",
						title: "拖我调节左右占比（双击回到对半）",
						onMouseDown: splitStart,
						onDoubleClick: () => { setSplit(50, true); },
					}),
					h(ReaderRight, { segs, pdfName, paper }));
			}


			// ↓↓↓ 拼接时被误删、按原样恢复回来的两个组件 ↓↓↓
			function PdfCard(props) {
				const s = useStore();
				const p = props.paper;
				return h("div", { className: "lit-card" },
					h("div", { className: "lit-card-h" }, "PDF"),
					p.pdf
						? h("div", null,
							h("div", { className: "lit-small" }, p.pdf.name),
							h("div", { className: "lit-small" },
								(p.pdf.pages ? p.pdf.pages + " 页 · " : "") + (p.pdf.chars || 0) + " 字" + (typeof p.pdf.confidence === "number" ? " · 可读度 " + p.pdf.confidence + "%" : "") + (p.pdf.engine ? " · " + (p.pdf.engine === "pdfjs" ? "pdf.js" : "内置抽取") : "")),
							h("div", { className: "lit-path" }, p.pdf.path),
							h("div", { style: { marginTop: "6px", display: "flex", gap: "6px" } },
								h("button", { className: "lit-btn", onClick: () => set({ tab: "translate" }) }, "去对照精读"),
								h(PdfPicker, { label: "换一份" })))
						: h("div", null,
							h("div", { className: "lit-small" }, "导入 PDF 会自动建/更新这篇文献，并把抽出的英文原文放进左边原文区。"),
							h("div", { style: { marginTop: "6px" } }, h(PdfPicker, { primary: true }))),
					s.pdfMsg
						? h("div", {
							className: s.pdfMsg.indexOf("失败") >= 0 ? "lit-err" : (s.pdfBusy ? "lit-small" : "lit-ok"),
							style: { marginTop: "6px" },
						}, s.pdfMsg)
						: null);
			}

			function SidePanel(props) {
				const s = useStore();
				const p = props.paper;
				const filled = filledCount(p);
				const missing = COLUMNS.filter((c) => !isFilled(p, c.id));
				return h("div", null,
					h(ProgressCard, { paper: p }),
					h("div", { className: "lit-card" },
						h("div", { className: "lit-card-h" }, "填写进度"),
						h("div", { className: "lit-bar" },
							h("div", { className: "lit-bar-fill", style: { width: Math.round((filled / COLUMNS.length) * 100) + "%" } })),
						h("div", { className: "lit-progress-line" }, filled + " / " + COLUMNS.length + " 栏"),
						missing.length === 0
							? h("div", { className: "lit-ok", style: { marginTop: "6px" } }, "模板 13 栏都填好了 ✅")
							: h("div", { className: "lit-chips" }, missing.map((c) => h("span", { key: c.id, className: "lit-chip" }, c.label)))),
					h(PdfCard, { paper: p }),
					h("div", { className: "lit-card" },
						h("div", { className: "lit-card-h" }, "读文献时记住"),
						h("div", { className: "lit-small" }, "· 学习阶段尽量读 JCR Q1 / 中科院 1 区顶刊"),
						h("div", { className: "lit-small" }, "· 泛读靠公众号保持前沿感，值得深挖的转入精读"),
						h("div", { className: "lit-small" }, "· 纳入排除标准、分析方法适用场景是审稿人最爱问的"),
						h("div", { className: "lit-small" }, "· 每个数值代表什么（HR/OR/β、95%CI、P）要能一句话说清"),
						h("div", { className: "lit-path", style: { marginTop: "6px" } }, "数据文件：" + shownDataPath)));
			}

			function DraftCard(props) {
				const d = props.draft;
				const up = (patch) => patchDraft(d.id, patch);
				return h("div", { className: "lit-card" },
					h("div", { className: "lit-form" },
						h(Field, { label: "来源" }, h(Select, { value: d.source || SOURCES[0], options: SOURCE_OPTIONS, onChange: (v) => up({ source: v }) })),
						h(Field, { label: "日期" }, h(Input, { value: d.date || "", placeholder: "2024-01-01", onChange: (v) => up({ date: v }) })),
						h(Field, { label: "标题", wide: true }, h(Input, { value: d.title || "", placeholder: "文章标题", onChange: (v) => up({ title: v }) }))),
					h("div", { style: { marginTop: "8px" } },
						h(Area, { value: d.note || "", placeholder: "一句话结论 / 为什么值得记 / 要不要转入精读", onChange: (v) => up({ note: v }) })),
					h("div", { className: "lit-float-foot" },
						h("button", { className: "lit-mini", onClick: () => removeDraft(d.id) }, "删除")));
			}

			function DraftsView() {
				const s = useStore();
				React.useEffect(() => { ensureLoaded(); }, []);
				return h("div", { className: "lit-col-main" },
					h("div", { className: "lit-card" },
						h("div", { className: "lit-card-h" }, "泛读速记（公众号 / 前沿）"),
						h("div", { className: "lit-small" }, "看到值得留意的新文章就记一行：来源 + 标题 + 一句话结论 + 要不要转入精读。"),
						h("div", { style: { marginTop: "8px" } },
							h("button", { className: "lit-btn lit-btn-primary", onClick: addDraft }, "+ 记一条"))),
					s.drafts.length === 0 ? h("div", { className: "lit-empty" }, "还没有泛读记录") : null,
					s.drafts.map((d) => h(DraftCard, { key: d.id, draft: d })));
			}

			function PaperList(props) {
				const s = props.state;
				const query = props.query;
				const [statusFilter, setStatusFilter] = React.useState("");
				const [tableFilter, setTableFilter] = React.useState("");
				const [sortBy, setSortBy] = React.useState("recent");
				const [batchMode, setBatchMode] = React.useState(false);
				const [selectedIds, setSelectedIds] = React.useState([]);
				const papers = Array.isArray(s.papers) ? s.papers.filter((paper) => paper && typeof paper === "object") : [];
				const normalizedQuery = String(query || "").trim().toLocaleLowerCase();
				const list = papers.filter((paper) => {
					if (statusFilter && String(paper.status || "") !== statusFilter) return false;
					const completedCount = filledCount(paper);
					if (tableFilter === "missing" && completedCount === COLUMNS.length) return false;
					if (tableFilter === "complete" && completedCount < COLUMNS.length) return false;
					if (!normalizedQuery) return true;
					const hay = COL_IDS.map((id) => typeof paper[id] === "string" ? paper[id] : "").join(" ") + " " +
						(typeof paper.tags === "string" ? paper.tags : "") + " " +
						(typeof paper.pmid === "string" || typeof paper.pmid === "number" ? String(paper.pmid) : "");
					return hay.toLocaleLowerCase().indexOf(normalizedQuery) >= 0;
				});
				const listEmptyMessage = papers.length === 0 ? "还没有文献" : tableFilter === "missing"
					? (statusFilter || normalizedQuery ? "当前筛选条件下没有表格有缺项的文献" : "没有表格有缺项的文献")
					: tableFilter === "complete"
						? (statusFilter || normalizedQuery ? "当前筛选条件下没有表格已填完的文献" : "没有表格已填完的文献")
						: "没有符合当前筛选条件的文献";
				list.sort((a, b) => {
					if (sortBy === "title") return String(a.title || "").localeCompare(String(b.title || ""), "zh-CN", { sensitivity: "base" });
					const aRead = Number(progressOf(a).lastReadAt) || 0;
					const bRead = Number(progressOf(b).lastReadAt) || 0;
					return bRead - aRead;
				});
				const runningBatch = s.autoFillBatch && s.autoFillBatch.stage === "running";
				const currentBatchPaper = runningBatch ? s.papers.find((paper) => paper && paper.id === s.autoFillBatch.currentPaperId) : null;
				const setSelected = (paperId, selected) => setSelectedIds((current) => selected
					? (current.indexOf(paperId) >= 0 ? current : current.concat([paperId]))
					: current.filter((id) => id !== paperId));
				return h("div", { className: "lit-list" },
					h("div", { className: "lit-search lit-list-filters" },
						h("select", {
							className: "lit-input lit-filter-select", value: statusFilter, title: "按阅读状态筛选",
							"aria-label": "按阅读状态筛选", onChange: (e) => setStatusFilter(e.target.value),
						}, [h("option", { key: "all", value: "" }, "全部状态")].concat(STATUSES.map((status) => h("option", { key: status, value: status }, status)))),
						h("select", {
							className: "lit-input lit-filter-select", value: sortBy, title: "文献排序",
							"aria-label": "文献排序", onChange: (e) => setSortBy(e.target.value),
						}, [h("option", { key: "recent", value: "recent" }, "最近阅读"), h("option", { key: "title", value: "title" }, "标题 A–Z")]),
						h("select", {
							className: "lit-input lit-filter-select lit-filter-wide", value: tableFilter, title: "按阅读模板 13 栏的填写情况筛选",
							"aria-label": "按阅读模板 13 栏的填写情况筛选", onChange: (e) => setTableFilter(e.target.value),
						}, [
							h("option", { key: "all", value: "" }, "表格全部"),
							h("option", { key: "missing", value: "missing" }, "有缺项"),
							h("option", { key: "complete", value: "complete" }, "已填完"),
						])),
					h("div", { className: "lit-autofill-batch-tools" },
						h("button", {
							className: "lit-btn" + (batchMode ? " lit-btn-primary" : ""),
							disabled: runningBatch,
							title: "选择多篇带 PDF 的文献，依次生成可逐篇审阅的填表草稿",
							onClick: () => { setBatchMode(!batchMode); if (batchMode) setSelectedIds([]); },
						}, batchMode ? "退出批量选择" : "批量自动填表"),
						batchMode ? h("span", { className: "lit-small" }, "已选 " + selectedIds.length + " 篇（仅含 PDF）；会逐篇发送正文到 DeepSeek，仅生成预览，不自动填表。预览暂存在当前运行中，退出应用前请处理。") : null,
						batchMode ? h("button", {
							className: "lit-btn lit-btn-primary",
							disabled: selectedIds.length === 0 || runningBatch || s.autoFillBusy,
							title: "按勾选顺序依次提取 PDF 并生成逐篇预览",
							onClick: () => { const ids = selectedIds.slice(); setSelectedIds([]); startAutoFillBatch(ids); },
						}, runningBatch ? "正在识别…" : "开始识别") : null),
					s.autoFillBatch ? h("div", { className: "lit-autofill-batch-panel" },
						s.autoFillBatch.stage === "running"
							? h("div", null, "批量识别进度：" + s.autoFillBatch.processed + "/" + s.autoFillBatch.ids.length + " 已完成；当前：" + (currentBatchPaper && currentBatchPaper.title || "正在处理文献"))
							: h("div", null, "批量识别完成：成功生成 " + s.autoFillBatch.successes.length + "/" + s.autoFillBatch.ids.length + " 篇预览，失败 " + s.autoFillBatch.failures.length + " 篇。每篇仍需单独核对并确认填入。"),
						s.autoFillBatch.failures.length > 0 ? h("ul", null, s.autoFillBatch.failures.map((failure) => h("li", { key: failure.paperId, className: "lit-autofill-batch-error" }, (failure.title || "文献") + "：" + failure.error))) : null,
						s.autoFillBatch.stage === "complete" ? h("div", { className: "lit-small", style: { marginTop: "4px" } }, "待审阅预览显示在对应文献的表格里；点「查看预览」即可逐篇确认。") : null) : null,
					s.loading ? h("div", { className: "lit-empty" }, "读取中…") : null,
					!s.loading && list.length === 0 ? h("div", { className: "lit-empty" }, listEmptyMessage) : null,
					list.map((paper) => {
						const progress = progressOf(paper);
						const segCount = Array.isArray(paper.translation && paper.translation.segments) ? paper.translation.segments.length : 0;
						return h("div", {
							key: paper.id,
							className: "lit-item" + (paper.id === s.activeId ? " is-active" : ""),
							onClick: () => set({ activeId: paper.id }),
						},
							h("button", {
								className: "lit-item-x" + (s.armedRemoveId === paper.id ? " is-armed" : ""),
								title: s.armedRemoveId === paper.id ? "再点一次确认移除这篇" : "移除这篇（会先让你确认一次）",
								onClick: (e) => {
									if (e && typeof e.stopPropagation === "function") e.stopPropagation();
									askRemovePaper(paper);
								},
							}, s.armedRemoveId === paper.id ? "确认移除" : "×"),
							batchMode && paper.pdf && paper.pdf.name ? h("input", {
								className: "lit-item-select", type: "checkbox", checked: selectedIds.indexOf(paper.id) >= 0,
								disabled: runningBatch || !!(s.autoFillBatchDrafts && s.autoFillBatchDrafts[paper.id]) || !!(s.autoFillDraft && s.autoFillDraft.paperId === paper.id),
								"aria-label": (s.autoFillBatchDrafts && s.autoFillBatchDrafts[paper.id]) || (s.autoFillDraft && s.autoFillDraft.paperId === paper.id)
									? "这篇已有待审阅的识别预览，请先处理后再加入批量识别"
									: "选择 " + (paper.title || "未命名文献") + " 加入批量自动填表",
								onClick: (e) => { if (e && typeof e.stopPropagation === "function") e.stopPropagation(); },
								onChange: (e) => setSelected(paper.id, e.target.checked),
							}) : null,
							h("div", { className: "lit-item-title" }, paper.title || "（未命名文献）"),
							h("div", { className: "lit-item-meta" }, [paper.journal || "—", paper.published, paper.rank].filter(Boolean).join(" · ")),
							h("div", { className: "lit-mini-bar" },
								h("div", { className: "lit-mini-bar-fill", style: { width: Math.max(0, Math.min(100, progress.percent)) + "%" } })),
							h("span", { className: "lit-pill " + statusClass(paper.status) }, paper.status),
							h("span", { className: "lit-pill", style: { marginLeft: "5px" } }, progress.percent + "%"),
							h("span", { className: "lit-pill", style: { marginLeft: "5px" } }, filledCount(paper) + "/13"),
							progress.minutes > 0 ? h("span", { className: "lit-pill", style: { marginLeft: "5px" } }, fmtDuration(progress.minutes * 60000)) : null,
							paper.pdf ? h("span", { className: "lit-pill lit-pill-doing", style: { marginLeft: "5px" } }, "PDF") : null,
							segCount > 0 ? h("span", { className: "lit-pill lit-pill-doing", style: { marginLeft: "5px" } }, segCount + " 段") : null,
							s.autoFillBatchDrafts && s.autoFillBatchDrafts[paper.id] ? h("button", {
								className: "lit-mini lit-batch-review",
								onClick: (e) => { if (e && typeof e.stopPropagation === "function") e.stopPropagation(); set({ activeId: paper.id, tab: "entry" }); },
							}, "查看预览") : null);
					}));
			}

			/** 中间栏最小可用宽度：低于它宁可出横向滚动，也不让内容被挤没 */
			const MAIN_MIN = 320;
			const LEFT_W = 266;
			const RIGHT_W = 272;
			const RAIL_W = 30;
			/** 面板窄到这个宽度以下就自动收栏 */
			const HIDE_RIGHT_BELOW = 1000;
			const HIDE_LEFT_BELOW = 780;

			function toggleSide(which) {
				const ui = Object.assign({}, state.ui);
				ui[which] = !ui[which];
				const patch = { ui };
				// 手动操作过就不再受「自动收起」支配
				if (which === "left") patch.uiAutoLeft = false; else patch.uiAutoRight = false;
				set(patch);
				scheduleSave();
			}

			/** 面板变窄先收右栏再收左栏，变宽把「被自动收起的」还回去 */
			function applyResponsive(width) {
				if (!(width > 0)) return;
				let ui = Object.assign({}, state.ui);
				let autoLeft = state.uiAutoLeft;
				let autoRight = state.uiAutoRight;
				let changed = false;
				if (width < HIDE_RIGHT_BELOW && ui.right !== false) { ui.right = false; autoRight = true; changed = true; }
				if (width < HIDE_LEFT_BELOW && ui.left !== false) { ui.left = false; autoLeft = true; changed = true; }
				if (width >= HIDE_RIGHT_BELOW && autoRight === true) { ui.right = true; autoRight = false; changed = true; }
				if (width >= HIDE_LEFT_BELOW && autoLeft === true) { ui.left = true; autoLeft = false; changed = true; }
				if (changed) { set({ ui, uiAutoLeft: autoLeft, uiAutoRight: autoRight }); scheduleSave(); }
			}

			/** 中文框高度档位，默认自适应剩余阅读空间。 */
			const TX_HEIGHTS = { s: 200, m: 360, l: 560, full: "calc(100vh - 220px)" };
			const SEG_HEIGHTS = { s: 70, m: 130, l: 200, full: 300 };
			function txHeightValue(ui) {
				const key = ui && typeof ui.txHeight === "string" ? ui.txHeight : "m";
				return TX_HEIGHTS[key] === undefined ? TX_HEIGHTS.m : TX_HEIGHTS[key];
			}
			function segHeightValue(ui) {
				const key = ui && typeof ui.txHeight === "string" ? ui.txHeight : "m";
				return SEG_HEIGHTS[key] === undefined ? SEG_HEIGHTS.m : SEG_HEIGHTS[key];
			}
			function setTxHeight(key) {
				setReaderUi(key === "auto" ? { readerAutoSize: true } : { readerAutoSize: false, txHeight: key });
			}
			function setReaderUi(patch) {
				set({ ui: Object.assign({}, state.ui, patch) });
				scheduleSave();
			}

			/** 自动高度优先；手动档位保留，记住用户选择。 */
			function HeightPicker() {
				const s = useStore();
				const cur = !s.ui || s.ui.readerAutoSize !== false ? "auto" : typeof s.ui.txHeight === "string" ? s.ui.txHeight : "m";
				const opts = [["auto", "自适应"], ["s", "小"], ["m", "中"], ["l", "大"], ["full", "满屏"]];
				return h("span", { className: "lit-hset" },
					h("span", { className: "lit-small" }, "译文高度"),
					opts.map((pair) => h("button", {
						key: pair[0],
						className: cur === pair[0] ? "is-on" : "",
						title: "中文显示区高度：" + pair[1],
						onClick: () => setTxHeight(pair[0]),
					}, pair[1])));
			}

			function dismissTask(id) {
				const task = state.taskFeed.find((item) => item.id === id);
				if (taskIsActive(task)) return;
				set({ taskFeed: state.taskFeed.filter((item) => item.id !== id) });
			}
			function setTaskPanelOpen(open) {
				const taskPanelOpen = open === true;
				set({ taskPanelOpen, ui: Object.assign({}, state.ui, { taskPanelOpen }) });
				scheduleSave();
			}
			function TaskCenter() {
				const s = useStore();
				const tasks = Array.isArray(s.taskFeed) ? s.taskFeed : [];
				if (tasks.length === 0) return null;
				const activeCount = tasks.filter(taskIsActive).length;
				const newest = tasks[0];
				const statusText = newest.status === "running" ? "进行中" : newest.status === "stopping" ? "等待停止" : newest.status === "success" ? "完成" : newest.status === "error" ? "失败" : "已停止";
				return h("div", { className: "lit-task-center" },
					h("div", { className: "lit-task-summary" },
						h("span", { className: "lit-task-summary-label" }, "任务 · " + (activeCount > 0 ? activeCount + " 项进行中" : statusText + "：" + (newest.title || "最近任务"))),
						h("span", { className: newest.error ? "lit-task-error lit-task-summary-stage" : "lit-small lit-task-summary-stage" }, newest.error || newest.stage || ""),
						h("span", { className: "lit-grow" }),
						activeCount > 0 ? h("span", { className: "lit-warn" }, "任务状态实时更新") : null,
						h("button", {
							type: "button", className: "lit-task-toggle", "aria-expanded": s.taskPanelOpen,
							"aria-label": s.taskPanelOpen ? "收起任务详情" : "展开任务详情",
							title: s.taskPanelOpen ? "收起任务详情" : "展开任务详情",
							onClick: () => setTaskPanelOpen(!s.taskPanelOpen),
						}, s.taskPanelOpen ? "收起" : "展开", h("span", { "aria-hidden": "true" }, s.taskPanelOpen ? "⌃" : "⌄"))),
					s.taskPanelOpen ? h("div", { className: "lit-task-list" }, tasks.map((task) => {
						const taskStatus = task.status === "running" ? "进行中" : task.status === "stopping" ? "等待停止" : task.status === "success" ? "完成" : task.status === "error" ? "失败" : "已停止";
						const statusClass = task.status === "error" ? "lit-err" : task.status === "success" ? "lit-ok" : taskIsActive(task) ? "lit-warn" : "lit-small";
						return h("div", { key: task.id, className: "lit-task-row" },
							h("div", { className: "lit-task-main" },
								h("div", { className: "lit-task-title" }, task.title || "任务", "　", h("span", { className: statusClass }, taskStatus)),
								h("div", { className: task.error ? "lit-task-error" : "lit-task-stage" }, task.error || task.stage || "处理中"),
								typeof task.progress === "number" ? h("div", { className: "lit-task-progress" }, h("span", { style: { width: Math.max(0, Math.min(100, task.progress)) + "%" } })) : null),
							task.canCancel === true && task.status === "running"
								? h("button", { className: "lit-mini", onClick: () => stopTask(task.id) }, task.cancelLabel || "停止等待")
								: null,
							!taskIsActive(task) ? h("button", { className: "lit-mini", title: "从任务列表移除", onClick: () => dismissTask(task.id) }, "×") : null);
					})) : null);
			}

			function Workbench() {
				const s = useStore();
				React.useEffect(() => { ensureLoaded(); }, []);
				// 整页工作台挂载着就算「在读」：不在浮动画板里、直接翻整页也会计时
				React.useEffect(() => {
					set({ onMainPanel: true });
					return () => { flushReadingTime(); set({ onMainPanel: false }); };
				}, []);
				const rootRef = React.useRef(null);
				// 量的是「面板自己的宽度」，不是窗口宽度：右侧可能还有别的栏
				React.useEffect(() => {
					const el = rootRef.current;
					if (!el) return;
					let last = 0;
					const measure = () => {
						const w = el.clientWidth;
						if (w === 0 || Math.abs(w - last) < 16) return;
						last = w;
						applyResponsive(w);
					};
					measure();
					if (typeof ResizeObserver !== "undefined") {
						const ro = new ResizeObserver(measure);
						ro.observe(el);
						return () => ro.disconnect();
					}
					window.addEventListener("resize", measure);
					return () => window.removeEventListener("resize", measure);
				}, []);
				const queryPair = React.useState("");
				const query = queryPair[0];
				const setQuery = queryPair[1];
				const paper = activePaper();
				const resumePaper = s.papers.filter((item) => item && progressOf(item).lastReadAt > 0)
					.sort((a, b) => progressOf(b).lastReadAt - progressOf(a).lastReadAt)[0] || null;
				const resumeLastReading = () => {
					if (!resumePaper) return;
					flushReadingTime();
					set({ activeId: resumePaper.id, tab: resumePaper.pdf ? "translate" : "entry", readerView: null, mindTab: false });
				};
				const showList = s.tab === "entry" || s.tab === "translate";
				let main = null;
				if (s.tab === "table") main = h(TableView, null);
				else if (s.tab === "drafts") main = h(DraftsView, null);
				else if (s.tab === "translate") main = h(ReaderView, null);
				else main = h(EntryView, null);
				let sideContent = null;
				if (s.tab === "entry" && paper !== null) sideContent = h(SidePanel, { paper });
				const leftOpen = s.ui.left !== false;
				const rightOpen = s.ui.right !== false;
				const side = sideContent === null ? null : h("div", { className: "lit-col-side" },
					h("div", { className: "lit-side-h" },
						h("span", { className: "lit-small" }, "辅助信息"),
						h("span", { className: "lit-grow" }),
						h("button", { className: "lit-collapse", title: "收起右侧栏", onClick: () => toggleSide("right") }, "»")),
					sideContent);
				let rightCol = null;
				if (side !== null) {
					rightCol = rightOpen ? side : h("div", { className: "lit-rail is-right" },
						h("button", { className: "lit-collapse", title: "展开右侧栏（面板太窄时会自动收起）", onClick: () => toggleSide("right") }, "‹"));
				}
				return h("div", {
					className: "lit-page", ref: rootRef,
					onDragOver: (e) => e.preventDefault(),
					onDrop: (e) => {
						e.preventDefault();
						const dt = e.dataTransfer;
						if (dt && dt.files && dt.files.length > 0) importPdfFile(dt.files[0]);
					},
				},
					h("div", { className: "lit-head" },
						h("div", null,
							h("div", { className: "lit-h1" }, "文献阅读工作台"),
							h("div", { className: "lit-h2" }, "按模板 13 栏拆文献　·　" + s.papers.length + " 篇 / " + s.drafts.length + " 条泛读　·　PDF 可直接拖进来")),
						h("span", { className: "lit-grow" }),
						resumePaper ? h("button", { className: "lit-btn", title: "继续阅读：" + (resumePaper.title || "未命名文献"), onClick: resumeLastReading }, "继续上次阅读") : null,
						h(PdfPicker, { label: "导入 PDF" }),
						h("button", { className: "lit-btn lit-btn-primary", onClick: addPaper }, "+ 新建文献"),
						h("div", { className: "lit-save" },
							s.error ? h("span", { className: "lit-err", title: s.error }, s.loadBroken ? "数据异常" : "保存异常")
								: (s.dirty ? "保存中…" : (s.savedAt ? "已保存" : "就绪")))),
					h("nav", { className: "lit-workflow-nav", role: "tablist", "aria-label": "工作区" }, [
						{ id: "entry", label: "阅读与笔记" }, { id: "table", label: "表格总览" },
						{ id: "translate", label: "对照精读" }, { id: "drafts", label: "泛读速记" },
					].map((item) => h("button", {
						key: item.id, type: "button", role: "tab", "aria-selected": s.tab === item.id,
						className: "lit-workflow-tab" + (s.tab === item.id ? " is-on" : ""),
						onClick: () => set({ tab: item.id }),
					}, item.label))),
					h(TaskCenter, null),
					s.backendDown === true
						? h("div", { className: "lit-backend-down" },
							"⚠ 本地桌面服务暂时不可用：翻译、思维导图、导入 PDF 和保存可能无法完成。",
							"请重启应用后重试；恢复前请先复制尚未保存的重要内容。")
						: null,
					h("div", { className: "lit-body" },
						leftOpen
						? h("div", { className: "lit-col-list" },
							h("div", { className: "lit-library-head" },
								h("span", null, s.tab === "drafts" ? "泛读速记" : "文献库"),
								h("span", { className: "lit-grow" }),
								h("button", { className: "lit-collapse", title: "收起左侧栏", onClick: () => toggleSide("left") }, "«")),
							showList
								? h("div", { className: "lit-search" }, h(Input, { value: query, placeholder: "搜索标题 / 期刊 / 标签", onChange: setQuery }))
								: null,
							s.tab === "drafts"
								? h("div", { className: "lit-list" },
									h("button", { className: "lit-btn", style: { width: "100%", marginBottom: "6px" }, onClick: addDraft }, "+ 记一条泛读"),
									s.drafts.map((draft) => h("div", { key: draft.id, className: "lit-item" },
										h("div", { className: "lit-item-title" }, draft.title || "（未命名）"),
										h("div", { className: "lit-item-meta" }, (draft.source || "—") + (draft.date ? " · " + draft.date : "")))))
								: h(PaperList, { state: s, query }))
						: h("div", { className: "lit-rail" },
							h("button", { className: "lit-collapse", title: "展开左侧栏（面板太窄时会自动收起）", onClick: () => toggleSide("left") }, "›")),
						main,
						rightCol));
			}

			function FloatPanel() {
				const s = useStore();
				React.useEffect(() => { ensureLoaded(); }, []);
				if (!s.panelOpen) return null;
				const paper = activePaper();
				const progress = paper === null ? blankProgress() : progressOf(paper);
				const filled = filledCount(paper);
				const missing = paper === null ? [] : COLUMNS.filter((c) => !isFilled(paper, c.id));
				return h("div", { className: "lit-float" },
					h("div", { className: "lit-float-head" },
						h(BookIcon, { size: 14 }),
						h("span", { className: "lit-float-title" }, "文献阅读"),
						s.readingSince > 0 && s.readingPaperId === s.activeId ? h("span", { className: "lit-batch" }, fmtClock(Date.now() - s.readingSince)) : null,
						h("span", { className: "lit-grow" }),
						h("button", { className: "lit-mini", onClick: openFullPage }, "整页"),
						h("button", { className: "lit-mini", onClick: togglePanel }, "收起")),
					paper === null
						? h("div", { className: "lit-float-body" },
							h("div", { className: "lit-small" }, "还没有文献。"),
							h("button", { className: "lit-btn lit-btn-primary", onClick: addPaper }, "+ 新建文献"))
						: h("div", { className: "lit-float-body" },
							h("select", {
								className: "lit-input", value: paper.id,
								onChange: (e) => { flushReadingTime(); set({ activeId: e.target.value, readingPaperId: null, readingSince: 0 }); },
							}, s.papers.map((p) => h("option", { key: p.id, value: p.id }, p.title || "（未命名文献）"))),
							h("div", { className: "lit-bar" },
								h("div", { className: "lit-bar-fill", style: { width: Math.max(0, Math.min(100, progress.percent)) + "%" } })),
							h("div", { className: "lit-progress-line" }, "进度 " + progress.percent + "%　·　累计 " + fmtDuration(progress.minutes * 60000) + "　·　已填 " + filled + "/" + COLUMNS.length),
							missing.length > 0
								? h("div", { className: "lit-chips" }, missing.map((c) => h("span", { key: c.id, className: "lit-chip" }, c.label)))
								: h("div", { className: "lit-ok" }, "13 栏都填好了 ✅"),
							h("div", { className: "lit-float-steptitle" }, "速记 · 思考"),
							h(Area, {
								value: paper.thoughts || "",
								placeholder: "读到什么先记一句，回头再整理到对应栏…",
								onChange: (v) => patchPaper(paper.id, { thoughts: v }),
							}),
							h("div", { className: "lit-float-foot" },
								h("button", { className: "lit-btn", onClick: () => setProgress(paper.id, { percent: Math.min(100, progress.percent + 10) }) }, "+10%"),
								h("button", { className: "lit-btn", onClick: () => { set({ tab: "translate", panelOpen: false }); openFullPage(); } }, "分段翻译"),
								h("button", { className: "lit-btn", onClick: () => { set({ tab: "entry", panelOpen: false }); openFullPage(); } }, "逐篇填写"))));
			}

			function PanelIcon(props) {
				const active = !!(props && props.active);
				const size = props && props.size ? props.size : 18;
				return h("span", { className: "lit-icon-wrap" + (active ? " is-on" : "") }, h(BookIcon, { size }));
			}

			function HeaderButton() {
				const s = useStore();
				return h("button", {
					className: "lit-hbtn" + (s.panelOpen ? " is-on" : ""),
					title: "文献阅读面板",
					onClick: togglePanel,
				}, h(BookIcon, { size: 14 }), h("span", null, "文献"));
			}

			/** 渲染兜底：面板自己出错时把错误显示出来，而不是留一片空白 */
			class LitBoundary extends React.Component {
				constructor(props) {
					super(props);
					this.state = { error: null };
				}
				static getDerivedStateFromError(error) {
					return { error };
				}
				componentDidCatch(error, info) {
					try { console.error("[dsh-literature-reading] render failed:", error, info); } catch { /* ignore */ }
				}
				render() {
					if (this.state.error) {
						const error = this.state.error;
						return h("div", { className: "lit-crash" },
							h("div", { className: "lit-crash-h" }, "文献阅读面板渲染出错（已拦下，界面其它部分不受影响）"),
							h("pre", { className: "lit-crash-body" }, String((error && error.stack) || error)),
							h("div", { className: "lit-small" }, "把上面这段发给我就能定位。"));
					}
					return this.props.children;
				}
			}

			function WorkbenchSafe() {
				return h(LitBoundary, null, h(Workbench, null));
			}
			function FloatPanelSafe() {
				return h(LitBoundary, null, h(FloatPanel, null));
			}
			function HeaderButtonSafe() {
				return h(LitBoundary, null, h(HeaderButton, null));
			}

			// ── 注册进各个 slot ──

			ctx.effect(() => ctx.slots.inject("main", () => ctx.slots.register(
				{ name: "main", key: "litread" }, WorkbenchSafe)), "literature-reading: main panel");
			ctx.effect(() => ctx.slots.inject("sidebar.panellist", () => ctx.slots.register(
				{ name: "sidebar.panellist", id: "litread", order: 40, label: "文献阅读" }, PanelIcon)), "literature-reading: sidebar entry");
			ctx.effect(() => ctx.slots.inject("conversation.session.header.utilities", () => ctx.slots.register(
				{ name: "conversation.session.header.utilities", id: "litread-toggle", order: 20, label: "文献" }, HeaderButtonSafe)), "literature-reading: header toggle");
			ctx.effect(() => ctx.slots.inject("shell.overlay", () => ctx.slots.register(
				{ name: "shell.overlay", id: "litread-float", order: 50 }, FloatPanelSafe)), "literature-reading: float panel");

			// 测试钩子（只在冒烟测试里用；转一手是因为闭包状态在这里面）
			testHooks.setScrollBox = (mode, box) => {
				if (mode === "text") scrollMemory.textBox = box || null;
				else pdfState.stack = box || null;
			};
			testHooks.rememberScroll = (mode, force) => rememberScroll(mode, force === true);
			testHooks.restoreScroll = (mode) => restoreScroll(mode);

			// Publish last: the host can safely treat an absent hook as "plugin not ready".
			if (typeof window !== "undefined") {
				const hostWindow = window;
				ctx.effect(() => {
					hostWindow.__literatureReaderFlushBeforeClose = flushBeforeClose;
					return () => {
						if (hostWindow.__literatureReaderFlushBeforeClose === flushBeforeClose) {
							delete hostWindow.__literatureReaderFlushBeforeClose;
						}
					};
				}, "literature-reading: flush before close");
			}
		}

		/**
		 * 面板自己的错误不该连累整个界面：apply 里抛出去会让控制台一直报错，
		 * 这里兜住并记录，其余界面照常。
		 */
		exports.apply = function apply(ctx) {
			try {
				applyInner(ctx);
			} catch (error) {
				try { console.error("[dsh-literature-reading] apply failed:", error); } catch { /* ignore */ }
			}
		};
		// 给冒烟测试用的一点点内部钩子（纯函数，没有副作用；正式界面不会用到）
		/** applyInner 里的状态通过它转出来（避免把闭包变量提到工厂作用域） */
		const testHooks = {};
		exports.__test = {
			textItemBox: (item, viewport) => textItemBox(item, viewport),
			readerTextRoot: (node) => readerTextRoot(node),
			normText: (value) => normText(value),
			mindLayout: (tree) => mindLayout(tree),
			mindTextWidth: (text) => mindTextWidth(text),
			mindOutlineText: (tree) => mindOutlineText(tree),
			normalizeScroll: (raw) => normalizeScroll(raw),
			scrollIndexAt: (boxes, top) => scrollIndexAt(boxes, top),
			scrollTopFor: (boxes, saved) => scrollTopFor(boxes, saved),
			// 下面三个要碰 applyInner 里的状态，所以通过 testHooks 转一手
			needsWordSpace: (prevText, prev, nextText, next) => needsWordSpace(prevText, prev, nextText, next),
			setScrollBox: (mode, box) => testHooks.setScrollBox(mode, box),
			rememberScroll: (mode, force) => testHooks.rememberScroll(mode, force),
			restoreScroll: (mode) => testHooks.restoreScroll(mode),
		};

		return module.exports;
	},
});
