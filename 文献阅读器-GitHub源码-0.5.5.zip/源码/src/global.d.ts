interface ImportMeta {
  readonly env: { readonly MODE: string }
}

interface Window {
  literatureApp: {
    rpc: (op: string, args: Record<string, unknown>) => Promise<Record<string, unknown>>
    getAssetUrl: (fileName: string) => Promise<string>
    getSettings: () => Promise<{ apiKey: string; setupComplete: boolean }>
    saveSettings: (settings: { apiKey?: string; setupComplete?: boolean }) => Promise<{ ok: boolean; setupComplete?: boolean }>
    openDataFolder: () => Promise<string>
    importLegacyData: () => Promise<{
      ok: boolean
      canceled?: boolean
      error?: string
      papersImported?: number
      pdfsCopied?: number
      pdfsMissing?: number
      path?: string
    }>
    baiduStatus: () => Promise<{ ok: boolean; configured: boolean; connected: boolean; publicBuild?: boolean; account?: string; expiresAt?: number; error?: string; code?: string }>
    baiduOpenAuth: () => Promise<{ ok: boolean }>
    baiduConnect: (code: string) => Promise<{ ok: boolean; account?: string; error?: string }>
    baiduDisconnect: () => Promise<{ ok: boolean }>
    baiduLatestBackup: () => Promise<{ ok: boolean; backup: null | { snapshotId: string; createdAt: string; files: number; bytes: number }; error?: string; code?: string }>
    baiduRestorePreview: () => Promise<{
      ok: boolean
      backup?: null | { snapshotId: string; createdAt: string; files: number; bytes: number; papers: number | null; pdfs: number }
      local?: { papers: number | null; pdfs: number | null }
      error?: string
      code?: string
    }>
    baiduUpload: (taskId?: string) => Promise<{ ok: boolean; snapshotId?: string; files?: number; bytes?: number; error?: string; code?: string }>
    baiduRestore: (taskId?: string) => Promise<{ ok: boolean; snapshotId?: string; files?: number; papers?: number; localBackupPath?: string; error?: string; code?: string }>
    onPrepareClose: (callback: () => Promise<boolean>) => () => void
  }
}
