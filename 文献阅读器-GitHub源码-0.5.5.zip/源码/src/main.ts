import React from 'react'
import { createRoot } from 'react-dom/client'
import './style.css'
import './baidu-sync.css'

const publicBuild = import.meta.env.MODE === 'public'

type ClientModule = { apply: (ctx: Record<string, unknown>) => void }
let plugin: ClientModule | null = null
let unregisterTimer: number[] = []
let pluginStartupTimeout: number | null = null

function clearPluginStartupTimeout() {
  if (pluginStartupTimeout === null) return
  window.clearTimeout(pluginStartupTimeout)
  pluginStartupTimeout = null
}

declare global {
  interface Window {
    __ModuleLoader__?: { load: (module: { id: string; factory: (require: (name: string) => unknown) => ClientModule }) => void }
    __literatureReaderFlushBeforeClose?: () => Promise<boolean>
  }
}

function renderWorkbench() {
  const Component = (window as Window & { literatureWorkbench?: React.ComponentType }).literatureWorkbench
  if (Component) {
    clearPluginStartupTimeout()
    document.body.dataset.workbenchReady = 'true'
    root.render(React.createElement(Component))
  }
}

function installHostShim() {
  window.__ModuleLoader__ = {
    load: ({ factory }) => {
      plugin = factory((name) => {
        if (name === 'react') return React
        throw new Error(`Unsupported module requested by workbench: ${name}`)
      })
      const registrations = new Map<string, React.ComponentType>()
      const ctx = {
        slots: {
          inject: (_slot: string, register: () => unknown) => register(),
          register: (meta: { name?: string; key?: string; id?: string }, component: React.ComponentType) => {
            const key = meta.key || meta.id || meta.name || ''
            registrations.set(key, component)
            if (meta.name === 'main' && key === 'litread') {
              ;(window as Window & { literatureWorkbench?: React.ComponentType }).literatureWorkbench = component
              renderWorkbench()
            }
            return () => registrations.delete(key)
          },
        },
        layout: { selectPanel: () => renderWorkbench() },
        effect: (effect: () => void | (() => void)) => {
          const cleanup = effect()
          return typeof cleanup === 'function' ? cleanup : () => undefined
        },
        timeout: (callback: () => void, ms: number) => {
          const timer = window.setTimeout(callback, ms)
          return () => window.clearTimeout(timer)
        },
        interval: (callback: () => void, ms: number) => {
          const timer = window.setInterval(callback, ms)
          unregisterTimer.push(timer)
          return () => window.clearInterval(timer)
        },
      }
      plugin?.apply(ctx)
    },
  }
}

function installRpcBridge() {
  const nativeFetch = window.fetch.bind(window)
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const target = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url
    if (target.startsWith('/dsh-litread/rpc') || target.startsWith('http://127.0.0.1:5173/dsh-litread/rpc')) {
      let request: { op: string; args?: Record<string, unknown> }
      try { request = JSON.parse(String(init?.body || '{}')) as typeof request } catch { return Response.json({ ok: false, error: 'invalid request' }, { status: 400 }) }
      const response = await window.literatureApp.rpc(request.op, request.args || {})
      return Response.json(response)
    }
    return nativeFetch(input, init)
  }
}

async function loadPlugin() {
  installHostShim()
  installRpcBridge()
  const script = document.createElement('script')
  script.src = './dsh-client.js'
  script.onload = () => {
    document.body.dataset.workbenchScriptLoaded = 'true'
  }
  script.onerror = () => {
    clearPluginStartupTimeout()
    rootNode.textContent = '文献工作台脚本加载失败。请关闭应用并重新安装；如果仍出现，请把此画面截图发给开发者。'
  }
  pluginStartupTimeout = window.setTimeout(() => {
    pluginStartupTimeout = null
    if (!(window as Window & { literatureWorkbench?: React.ComponentType }).literatureWorkbench) {
      rootNode.textContent = '文献工作台在 15 秒内未能启动，可能是程序资源没有及时加载。请关闭应用后重新打开；如果仍出现，请把此画面截图发给开发者。'
    }
  }, 15_000)
  document.body.appendChild(script)
}

const shell = document.querySelector<HTMLDivElement>('#app')!
const firstRunIntro = publicBuild ? '配置模型并了解本机数据保护。完成后，这些入口会收进“设置”。' : '蓝色标出的顶部工具区可配置 DeepSeek、百度网盘、旧版数据导入和本机数据保护。完成后，这些入口会收进“设置”。'
const firstRunCloudItem = publicBuild ? '' : '<li><b>百度网盘同步</b>：需要跨设备备份时再连接，可稍后设置。</li>'
const settingsDescription = publicBuild ? '模型设置和本机数据保护。' : '模型、网盘同步、旧数据迁移和本地数据保护。'
const settingsDataTitle = publicBuild ? '本地数据' : '数据与账户'
const settingsDataDescription = publicBuild ? '导入旧版文献，管理本机快照、回收站和数据文件夹。' : '备份、迁移旧版文献，或管理本机数据。'
shell.innerHTML = `<header class="desktop-bar is-first-run"><div class="app-identity"><div class="app-mark">文</div><div><strong>文献阅读工作台</strong><small>独立桌面版</small></div></div><div class="desktop-actions"><span id="model-status">DeepSeek Key 未设置</span><button id="folder-open" class="bar-button setup-toolbar-action" type="button">本地数据</button><button id="settings-open" class="bar-button" type="button">模型设置</button></div></header><section class="first-run-guide" id="first-run-guide" hidden aria-labelledby="first-run-title"><div class="first-run-copy"><strong id="first-run-title">首次使用 · 快速设置</strong><p>${firstRunIntro}</p><ol><li><b>模型设置</b>：使用翻译和思维导图时填写 DeepSeek Key。</li>${firstRunCloudItem}<li><b>导入旧数据</b>：只有从旧版迁移文献时才需要。</li><li><b>本地数据</b>：管理本机快照、回收站和数据文件夹。</li></ol><small>可以先配置，也可以跳过；进入工作台后仍能从“设置”找到这些功能。</small></div><div class="first-run-actions"><button id="first-run-open-settings" class="bar-button" type="button">打开设置</button><button id="first-run-finish" class="bar-button primary" type="button">开始使用</button></div></section><main id="workbench"><div class="starting"><div class="loader"></div><span>正在打开文献工作台…</span></div></main><dialog id="settings"><form method="dialog" class="settings-box"><div class="settings-heading"><div><h2>设置</h2><p>${settingsDescription}</p></div><button class="close-button" value="cancel" aria-label="关闭">×</button></div><label>DeepSeek API Key<input id="deepseek-key" type="password" placeholder="sk-…" autocomplete="off" /></label><p class="settings-hint">Key 保存在这台电脑的应用数据目录，不包含在安装包中。保存不会验证 Key；首次翻译或生成导图时会显示请求结果。</p><div class="settings-model-status"><strong>模型状态</strong><span id="settings-status-slot"></span></div><section class="settings-tools-section"><div><h3>${settingsDataTitle}</h3><p>${settingsDataDescription}</p></div><div class="settings-tool-grid" id="settings-tools"></div></section><div class="settings-buttons"><button class="bar-button" value="cancel">关闭</button><button id="settings-save" class="bar-button primary" value="default">保存模型设置</button></div></form></dialog>`

const baiduDialog = document.createElement('dialog')
if (!publicBuild) {
baiduDialog.id = 'baidu-sync-dialog'
baiduDialog.innerHTML = `<div class="cloud-sync-box"><div class="cloud-sync-heading"><div><h2>百度网盘同步</h2><p>把文献资料备份到你自己的百度网盘，并可在另一台电脑恢复。</p></div><button id="baidu-dialog-close" class="close-button" aria-label="关闭">×</button></div><p id="baidu-sync-status" class="cloud-sync-status">正在读取连接状态…</p><button id="baidu-connect" class="bar-button primary">连接百度网盘</button><div id="baidu-auth-code-panel" class="cloud-auth-code" hidden><p>在百度授权页面同意后，复制页面显示的授权码并粘贴到这里。</p><input id="baidu-auth-code" type="text" autocomplete="off" placeholder="粘贴授权码" /><button id="baidu-confirm-connect" class="bar-button primary">完成连接</button></div><div id="baidu-actions" class="cloud-sync-actions" hidden><div id="baidu-latest-backup" class="cloud-backup-info">正在检查云端备份…</div><div class="cloud-sync-buttons"><button id="baidu-upload" class="bar-button primary">备份到百度网盘</button><button id="baidu-restore" class="bar-button">恢复云端最新备份</button></div><section id="baidu-restore-preview" class="cloud-restore-preview" hidden><h3>恢复前预览</h3><p id="baidu-restore-preview-status" class="cloud-restore-preview-status">正在读取备份信息…</p><dl id="baidu-restore-preview-details" class="cloud-restore-grid" hidden><div><dt>云端快照时间</dt><dd id="baidu-preview-created-at">—</dd></div><div><dt>云端备份内容</dt><dd id="baidu-preview-cloud-content">—</dd></div><div><dt>云端文献 / PDF</dt><dd id="baidu-preview-cloud-counts">—</dd></div><div><dt>本机已保存文献 / PDF</dt><dd id="baidu-preview-local-counts">—</dd></div></dl><div class="cloud-restore-warning" role="alert"><strong>覆盖提醒</strong><span>恢复会用云端数据全量替换本机文献和 PDF，不会合并。确认前不会恢复或覆盖本机数据。确认后会先保存当前编辑，再保留一份本机备份，然后下载并校验云端文件。</span></div><p class="cloud-restore-fallback-note">如果这份快照校验失败，恢复会按现有规则继续尝试其他完整备份，最终使用的快照可能与预览不同。</p><div class="cloud-restore-preview-actions"><button id="baidu-restore-cancel" class="bar-button">取消</button><button id="baidu-restore-confirm" class="bar-button primary" disabled>确认恢复并替换本机数据</button></div></section><button id="baidu-disconnect" class="cloud-text-button">断开百度网盘</button></div><p class="cloud-sync-note">备份包含文献记录、译文、阅读进度和 PDF，不包含 DeepSeek Key。恢复前会保留一份本地备份。</p><p id="baidu-sync-error" class="cloud-sync-error" role="status"></p></div>`
shell.append(baiduDialog)
}

const localDataDialog = document.createElement('dialog')
localDataDialog.id = 'local-data-dialog'
localDataDialog.innerHTML = `<div class="local-data-box"><div class="local-data-heading"><div><h2>本地数据保护</h2><p>每日完整快照和回收站都保存在本机应用数据目录。</p></div><button id="local-data-close" class="close-button" aria-label="关闭">×</button></div><section class="local-data-section"><div class="local-data-section-heading"><div><h3>本机快照</h3><p>每天自动创建一份，最多保留最近 10 份。恢复前会先保留当前完整数据。</p></div><button id="local-snapshot-create" class="bar-button">检查 / 创建今日本机快照</button></div><p id="local-snapshot-status" class="local-data-status"></p><ul id="local-snapshot-list" class="local-data-list"></ul></section><section class="local-data-section"><div class="local-data-section-heading"><div><h3>回收站</h3><p>恢复文献可取回记录；永久清除只移除记录，相关 PDF 会继续留在本机。</p></div><button id="local-folder-open" class="bar-button">打开数据文件夹</button></div><p id="local-trash-status" class="local-data-status"></p><ul id="local-trash-list" class="local-data-list"></ul></section></div>`
shell.append(localDataDialog)

let baiduOpenButton: HTMLButtonElement | undefined
if (!publicBuild) {
  baiduOpenButton = document.createElement('button')
  baiduOpenButton.id = 'baidu-sync-open'
  baiduOpenButton.className = 'bar-button setup-toolbar-action'
  baiduOpenButton.type = 'button'
  baiduOpenButton.textContent = '百度网盘同步'
  document.querySelector('.desktop-actions')!.insertBefore(baiduOpenButton, document.querySelector('#settings-open'))
}

const rootNode = document.querySelector<HTMLDivElement>('#workbench')!
const root = createRoot(rootNode)

const legacyImportButton = document.createElement('button')
legacyImportButton.id = 'legacy-import'
legacyImportButton.className = 'bar-button setup-toolbar-action'
legacyImportButton.type = 'button'
legacyImportButton.textContent = '导入旧数据'
legacyImportButton.title = '选择旧版 DSH 文献数据文件，继续使用已有文献'
document.querySelector('.desktop-actions')!.insertBefore(legacyImportButton, document.querySelector('#settings-open'))
legacyImportButton.onclick = async () => {
  legacyImportButton.disabled = true
  legacyImportButton.textContent = '导入中…'
  try {
    const result = await window.literatureApp.importLegacyData()
    if (result.canceled) return
    if (!result.ok) {
      window.alert('导入失败：' + (result.error || '未知错误'))
      return
    }
    const missing = result.pdfsMissing || 0
    const missingNote = missing > 0 ? `\n有 ${missing} 篇文献的 PDF 未找到，文献记录仍已导入。` : ''
    window.alert(`导入完成：${result.papersImported || 0} 篇文献，复制了 ${result.pdfsCopied || 0} 个 PDF。${missingNote}\n应用将重新加载数据。`)
    window.location.reload()
  } catch (error) {
    window.alert('导入失败：' + (error instanceof Error ? error.message : String(error)))
  } finally {
    legacyImportButton.disabled = false
    legacyImportButton.textContent = '导入旧数据'
  }
}

const desktopBar = document.querySelector<HTMLElement>('.desktop-bar')!
const firstRunGuide = document.querySelector<HTMLElement>('#first-run-guide')!
const settingsDialog = document.querySelector<HTMLDialogElement>('#settings')!
const settingsTools = document.querySelector<HTMLDivElement>('#settings-tools')!
const settingsStatusSlot = document.querySelector<HTMLSpanElement>('#settings-status-slot')!
const modelStatus = document.querySelector<HTMLElement>('#model-status')!
const folderOpenButton = document.querySelector<HTMLButtonElement>('#folder-open')!
const settingsOpenButton = document.querySelector<HTMLButtonElement>('#settings-open')!
if (publicBuild) {
  document.querySelector<HTMLElement>('.app-identity small')!.textContent = '公开版 · 数据保存在本机'
}

function showFirstRunGuide() {
  desktopBar.classList.add('is-first-run')
  firstRunGuide.hidden = false
}

function useSettingsToolbar() {
  desktopBar.classList.remove('is-first-run')
  firstRunGuide.hidden = true
  if (baiduOpenButton) settingsTools.append(baiduOpenButton)
  settingsTools.append(legacyImportButton, folderOpenButton)
  settingsStatusSlot.append(modelStatus)
  modelStatus.className = 'settings-status-value'
  settingsOpenButton.textContent = '设置'
  settingsOpenButton.title = publicBuild ? 'DeepSeek、旧数据迁移和本机数据设置' : 'DeepSeek、百度网盘、旧数据迁移和本地数据设置'
}

function updateModelStatus(apiKey: string) {
  modelStatus.textContent = apiKey ? 'DeepSeek Key 已保存（未验证）' : 'DeepSeek Key 未设置'
}

async function openSettings() {
  const settings = await window.literatureApp.getSettings()
  document.querySelector<HTMLInputElement>('#deepseek-key')!.value = settings.apiKey
  if (!settingsDialog.open) settingsDialog.showModal()
}
settingsOpenButton.onclick = () => { void openSettings() }
document.querySelector<HTMLButtonElement>('#first-run-open-settings')!.onclick = () => { void openSettings() }
document.querySelector<HTMLButtonElement>('#first-run-finish')!.onclick = async () => {
  const finishButton = document.querySelector<HTMLButtonElement>('#first-run-finish')!
  finishButton.disabled = true
  try {
    const result = await window.literatureApp.saveSettings({ setupComplete: true })
    if (!result.ok) throw new Error('初始设置状态保存失败。')
    useSettingsToolbar()
  } catch (error) {
    window.alert('无法完成首次设置：' + (error instanceof Error ? error.message : String(error)))
  } finally {
    finishButton.disabled = false
  }
}
document.querySelector<HTMLButtonElement>('#settings-save')!.onclick = async (event) => {
  event.preventDefault()
  const key = document.querySelector<HTMLInputElement>('#deepseek-key')!.value
  await window.literatureApp.saveSettings({ apiKey: key })
  settingsDialog.close()
  updateModelStatus(key.trim())
}
folderOpenButton.onclick = () => {
  localDataDialog.showModal()
  void refreshLocalData()
}
document.querySelector<HTMLButtonElement>('#local-data-close')!.onclick = () => localDataDialog.close()
document.querySelector<HTMLButtonElement>('#local-folder-open')!.onclick = () => { void window.literatureApp.openDataFolder() }

const snapshotList = document.querySelector<HTMLUListElement>('#local-snapshot-list')!
const trashList = document.querySelector<HTMLUListElement>('#local-trash-list')!
const snapshotStatus = document.querySelector<HTMLElement>('#local-snapshot-status')!
const trashStatus = document.querySelector<HTMLElement>('#local-trash-status')!

function createListMessage(list: HTMLUListElement, message: string) {
  list.replaceChildren()
  const item = document.createElement('li')
  item.className = 'local-data-empty'
  item.textContent = message
  list.append(item)
}

async function refreshLocalData() {
  snapshotStatus.textContent = '正在读取本机快照…'
  trashStatus.textContent = '正在读取回收站…'
  const [snapshotsResult, trashResult] = await Promise.all([
    window.literatureApp.rpc('listLocalSnapshots', {}),
    window.literatureApp.rpc('listTrash', {}),
  ])
  const snapshots = Array.isArray(snapshotsResult.snapshots) ? snapshotsResult.snapshots as Array<Record<string, unknown>> : []
  if (!snapshotsResult.ok) {
    snapshotStatus.textContent = String(snapshotsResult.error || '读取本机快照失败。')
    createListMessage(snapshotList, '暂时无法读取快照列表。')
  } else {
    snapshotStatus.textContent = snapshots.length ? `${snapshots.length} 份快照` : '尚无本机快照。'
    snapshotList.replaceChildren()
    if (!snapshots.length) createListMessage(snapshotList, '首次创建今日本机快照后会显示在这里。')
    for (const snapshot of snapshots) {
      const item = document.createElement('li')
      item.className = 'local-data-item'
      const summary = document.createElement('div')
      summary.className = 'local-data-item-summary'
      const title = document.createElement('strong')
      title.textContent = typeof snapshot.createdAt === 'string' && snapshot.createdAt ? new Date(snapshot.createdAt).toLocaleString() : `快照 ${String(snapshot.id || '')}`
      const details = document.createElement('span')
      details.textContent = snapshot.valid === false
        ? `无法校验：${String(snapshot.error || '快照无效')}`
        : `${String(snapshot.papers ?? 0)} 篇文献 · ${String(snapshot.pdfs ?? 0)} 个 PDF`
      summary.append(title, details)
      item.append(summary)
      if (snapshot.valid !== false && typeof snapshot.id === 'string') {
        const restore = document.createElement('button')
        restore.className = 'bar-button'
        restore.textContent = '恢复此快照'
        restore.onclick = async () => {
          if (!window.confirm(`将本机数据恢复到 ${title.textContent} 的状态。恢复前会保留当前数据快照。继续吗？`)) return
          const flush = window.__literatureReaderFlushBeforeClose
          if (flush && !(await flush())) { window.alert('当前文献数据尚未保存成功，请先处理保存提示。'); return }
          restore.disabled = true
          const result = await window.literatureApp.rpc('restoreLocalSnapshot', { snapshotId: snapshot.id as string })
          if (!result.ok) { window.alert('恢复失败：' + String(result.error || '未知错误')); restore.disabled = false; return }
          if (typeof result.warning === 'string') window.alert(result.warning)
          else window.alert(`恢复完成：${String(result.papers || 0)} 篇文献。`)
          window.location.reload()
        }
        item.append(restore)
      }
      snapshotList.append(item)
    }
  }

  const records = Array.isArray(trashResult.records) ? trashResult.records as Array<Record<string, unknown>> : []
  if (!trashResult.ok) {
    trashStatus.textContent = String(trashResult.error || '读取回收站失败。')
    createListMessage(trashList, '暂时无法读取回收站。')
  } else {
    trashStatus.textContent = records.length ? `${records.length} 条已删除文献` : '回收站为空。'
    trashList.replaceChildren()
    if (!records.length) createListMessage(trashList, '从文献列表删除的记录会暂存在这里。')
    for (const record of records) {
      const item = document.createElement('li')
      item.className = 'local-data-item'
      const paper = record.paper && typeof record.paper === 'object' ? record.paper as Record<string, unknown> : {}
      const summary = document.createElement('div')
      summary.className = 'local-data-item-summary'
      const title = document.createElement('strong')
      title.textContent = String(paper.title || paper.name || '未命名文献')
      const date = new Date(Number(record.deletedAt || 0))
      const details = document.createElement('span')
      details.textContent = `删除于 ${Number.isFinite(date.getTime()) ? date.toLocaleString() : '未知时间'}`
      summary.append(title, details)
      item.append(summary)
      const restore = document.createElement('button')
      restore.className = 'bar-button'
      restore.textContent = '恢复'
      restore.onclick = async () => {
        const flush = window.__literatureReaderFlushBeforeClose
        if (flush && !(await flush())) { window.alert('当前文献数据尚未保存成功，请先处理保存提示。'); return }
        const result = await window.literatureApp.rpc('restorePaperFromTrash', { paperId: record.paperId as string })
        if (!result.ok) { window.alert('恢复失败：' + String(result.error || '未知错误')); return }
        if (typeof result.warning === 'string') window.alert(result.warning)
        window.location.reload()
      }
      const clear = document.createElement('button')
      clear.className = 'bar-button danger'
      clear.textContent = '清除记录'
      clear.onclick = async () => {
        if (!window.confirm('永久移除这条回收站文献记录？关联 PDF 将保留在本机。')) return
        const result = await window.literatureApp.rpc('permanentlyDeleteFromTrash', { paperId: record.paperId as string })
        if (!result.ok) { window.alert('清除失败：' + String(result.error || '未知错误')); return }
        await refreshLocalData()
      }
      item.append(restore, clear)
      trashList.append(item)
    }
  }
}

document.querySelector<HTMLButtonElement>('#local-snapshot-create')!.onclick = async (event) => {
  const button = event.currentTarget as HTMLButtonElement
  button.disabled = true
  snapshotStatus.textContent = '正在检查 / 创建今日本机快照…'
  try {
    const result = await window.literatureApp.rpc('createLocalSnapshot', {})
    if (!result.ok) throw new Error(String(result.error || '本机快照创建失败。'))
    const snapshot = result.snapshot as Record<string, unknown> | undefined
    snapshotStatus.textContent = snapshot ? `已保存：${String(snapshot.papers || 0)} 篇文献 · ${String(snapshot.pdfs || 0)} 个 PDF` : '本机快照已保存。'
    await refreshLocalData()
  } catch (error) {
    snapshotStatus.textContent = error instanceof Error ? error.message : String(error)
  } finally { button.disabled = false }
}

if (!publicBuild) {
const baiduStatus = document.querySelector<HTMLElement>('#baidu-sync-status')!
const baiduError = document.querySelector<HTMLElement>('#baidu-sync-error')!
const baiduConnectButton = document.querySelector<HTMLButtonElement>('#baidu-connect')!
const baiduCodePanel = document.querySelector<HTMLElement>('#baidu-auth-code-panel')!
const baiduCodeInput = document.querySelector<HTMLInputElement>('#baidu-auth-code')!
const baiduActions = document.querySelector<HTMLElement>('#baidu-actions')!
const baiduBackupSummary = document.querySelector<HTMLElement>('#baidu-latest-backup')!
const baiduRestorePreview = document.querySelector<HTMLElement>('#baidu-restore-preview')!
const baiduRestorePreviewStatus = document.querySelector<HTMLElement>('#baidu-restore-preview-status')!
const baiduRestorePreviewDetails = document.querySelector<HTMLElement>('#baidu-restore-preview-details')!
const baiduRestoreConfirmButton = document.querySelector<HTMLButtonElement>('#baidu-restore-confirm')!
const baiduRestoreCancelButton = document.querySelector<HTMLButtonElement>('#baidu-restore-cancel')!
let restorePreviewSnapshotId: string | null = null
let activeBaiduTaskId: string | null = null
const baiduActionButtons = [
  baiduConnectButton,
  document.querySelector<HTMLButtonElement>('#baidu-confirm-connect')!,
  document.querySelector<HTMLButtonElement>('#baidu-upload')!,
  document.querySelector<HTMLButtonElement>('#baidu-restore')!,
  baiduRestoreConfirmButton,
  baiduRestoreCancelButton,
  document.querySelector<HTMLButtonElement>('#baidu-disconnect')!,
]
let baiduOperationBusy = false

window.addEventListener('literature-reader:task', (event) => {
  const task = (event as CustomEvent<{ id?: string; status?: string; stage?: string; progress?: number | null; error?: string }>).detail
  if (!task || task.id !== activeBaiduTaskId) return
  const percent = typeof task.progress === 'number' ? ` · ${Math.round(task.progress)}%` : ''
  if (task.stage) baiduStatus.textContent = `${task.stage}${percent}`
  if (task.status === 'error' && task.error) baiduError.textContent = task.error
})

function setBaiduBusy(busy: boolean) {
  baiduOperationBusy = busy
  baiduActionButtons.forEach((button) => { button.disabled = busy || (button === baiduRestoreConfirmButton && !restorePreviewSnapshotId) })
  document.querySelector<HTMLButtonElement>('#baidu-dialog-close')!.disabled = busy
}

function formatCloudBytes(value: number): string {
  if (value >= 1024 ** 3) return `${(value / 1024 ** 3).toFixed(1)} GB`
  if (value >= 1024 ** 2) return `${(value / 1024 ** 2).toFixed(1)} MB`
  if (value >= 1024) return `${(value / 1024).toFixed(0)} KB`
  return `${value} B`
}

function formatPreviewCount(value: number | null | undefined, unit: string): string {
  return typeof value === 'number' ? `${value} ${unit}` : '无法读取'
}

async function refreshBaiduStatus() {
  baiduError.textContent = ''
  baiduBackupSummary.textContent = '正在检查云端备份…'
  try {
    const status = await window.literatureApp.baiduStatus()
    if (!status.ok) {
      baiduStatus.textContent = '读取百度网盘连接状态失败。'
      baiduError.textContent = `${status.error || '请稍后重试。'}${status.code ? `（${status.code}）` : ''}`
      baiduActions.hidden = true
      return
    }
    if (publicBuild || status.publicBuild) {
      baiduStatus.textContent = '公开版未启用百度网盘同步，安装包不包含百度 SecretKey。'
      baiduConnectButton.hidden = true
      baiduActions.hidden = true
      baiduCodePanel.hidden = true
      return
    }
    if (!status.configured) {
      baiduStatus.textContent = '此安装包还没有配置百度开放平台应用。'
      baiduConnectButton.disabled = true
      baiduActions.hidden = true
      return
    }
    baiduConnectButton.disabled = false
    if (!status.connected) {
      baiduStatus.textContent = '尚未连接百度网盘账号。'
      baiduActions.hidden = true
      return
    }
    baiduStatus.textContent = `已连接：${status.account || '百度网盘账号'}`
    baiduConnectButton.hidden = true
    baiduActions.hidden = false
    const latest = await window.literatureApp.baiduLatestBackup()
    if (!latest.ok) {
      baiduBackupSummary.textContent = '读取云端备份失败。'
      baiduError.textContent = `${latest.error || '请检查百度应用是否已获文件读写权限。'}${latest.code ? `（${latest.code}）` : ''}`
    } else if (!latest.backup) {
      baiduBackupSummary.textContent = '云端还没有备份；首次手动备份时会初始化同步目录。'
    } else {
      const createdAt = new Date(latest.backup.createdAt).toLocaleString()
      baiduBackupSummary.textContent = `最新备份：${createdAt} · ${latest.backup.files} 个文件 · ${formatCloudBytes(latest.backup.bytes)}`
    }
  } catch (error) {
    baiduStatus.textContent = '读取百度网盘连接状态失败。'
    baiduError.textContent = error instanceof Error ? error.message : String(error)
    baiduActions.hidden = true
  }
}

baiduOpenButton!.onclick = async () => {
  baiduCodePanel.hidden = true
  baiduConnectButton.hidden = false
  baiduCodeInput.value = ''
  baiduRestorePreview.hidden = true
  baiduRestorePreviewDetails.hidden = true
  restorePreviewSnapshotId = null
  baiduDialog.showModal()
  await refreshBaiduStatus()
}
document.querySelector<HTMLButtonElement>('#baidu-dialog-close')!.onclick = () => {
  baiduRestorePreview.hidden = true
  restorePreviewSnapshotId = null
  baiduDialog.close()
}
baiduDialog.addEventListener('cancel', (event) => { if (baiduOperationBusy) event.preventDefault() })
baiduConnectButton.onclick = async () => {
  baiduError.textContent = ''
  try {
    await window.literatureApp.baiduOpenAuth()
    baiduCodePanel.hidden = false
    baiduCodeInput.focus()
    baiduStatus.textContent = '请在浏览器中完成授权，再把授权码粘贴到这里。'
  } catch (error) {
    baiduError.textContent = error instanceof Error ? error.message : String(error)
  }
}
document.querySelector<HTMLButtonElement>('#baidu-confirm-connect')!.onclick = async () => {
  baiduError.textContent = ''
  setBaiduBusy(true)
  try {
    const result = await window.literatureApp.baiduConnect(baiduCodeInput.value)
    if (!result.ok) throw new Error(result.error || '百度授权失败。')
    baiduCodePanel.hidden = true
    baiduConnectButton.hidden = true
    await refreshBaiduStatus()
  } catch (error) {
    baiduError.textContent = error instanceof Error ? error.message : String(error)
  } finally {
    setBaiduBusy(false)
  }
}
document.querySelector<HTMLButtonElement>('#baidu-upload')!.onclick = async () => {
  baiduError.textContent = ''
  setBaiduBusy(true)
  const taskId = `baidu-upload-${crypto.randomUUID()}`
  activeBaiduTaskId = taskId
  try {
    const flush = window.__literatureReaderFlushBeforeClose
    if (flush && !(await flush())) throw new Error('本机文献数据尚未保存成功，请先处理保存提示。')
    baiduStatus.textContent = '正在把文献和 PDF 备份到百度网盘…'
    const result = await window.literatureApp.baiduUpload(taskId)
    if (!result.ok) throw new Error(`${result.error || '上传云端备份失败。'}${result.code ? `（${result.code}）` : ''}`)
    baiduStatus.textContent = `备份完成：${result.files || 0} 个文件，${formatCloudBytes(result.bytes || 0)}。`
    await refreshBaiduStatus()
  } catch (error) {
    baiduError.textContent = error instanceof Error ? error.message : String(error)
  } finally {
    activeBaiduTaskId = null
    setBaiduBusy(false)
  }
}
document.querySelector<HTMLButtonElement>('#baidu-restore')!.onclick = async () => {
  baiduError.textContent = ''
  restorePreviewSnapshotId = null
  baiduRestorePreview.hidden = false
  baiduRestorePreviewDetails.hidden = true
  baiduRestoreConfirmButton.disabled = true
  baiduRestorePreviewStatus.textContent = '正在读取云端快照和本机已保存数据…'
  setBaiduBusy(true)
  try {
    const preview = await window.literatureApp.baiduRestorePreview()
    if (!preview.ok) throw new Error(`${preview.error || '读取恢复预览失败。'}${preview.code ? `（${preview.code}）` : ''}`)
    if (!preview.backup) throw new Error('百度网盘中还没有可恢复的备份。')

    const backup = preview.backup
    restorePreviewSnapshotId = backup.snapshotId
    document.querySelector<HTMLElement>('#baidu-preview-created-at')!.textContent = new Date(backup.createdAt).toLocaleString()
    document.querySelector<HTMLElement>('#baidu-preview-cloud-content')!.textContent = `${backup.files} 个文件 · ${formatCloudBytes(backup.bytes)}`
    document.querySelector<HTMLElement>('#baidu-preview-cloud-counts')!.textContent = `${formatPreviewCount(backup.papers, '篇')} / ${formatPreviewCount(backup.pdfs, '份')}`
    document.querySelector<HTMLElement>('#baidu-preview-local-counts')!.textContent = `${formatPreviewCount(preview.local?.papers, '篇')} / ${formatPreviewCount(preview.local?.pdfs, '份')}`
    baiduRestorePreviewStatus.textContent = `当前预览快照编号：${backup.snapshotId}`
    baiduRestorePreviewDetails.hidden = false
    baiduRestoreConfirmButton.disabled = false
  } catch (error) {
    baiduRestorePreviewStatus.textContent = '无法生成完整的恢复预览。'
    baiduError.textContent = error instanceof Error ? error.message : String(error)
  } finally {
    setBaiduBusy(false)
  }
}
baiduRestoreCancelButton.onclick = () => {
  restorePreviewSnapshotId = null
  baiduRestorePreview.hidden = true
  baiduError.textContent = ''
}
baiduRestoreConfirmButton.onclick = async () => {
  baiduError.textContent = ''
  if (!restorePreviewSnapshotId) {
    baiduError.textContent = '请先生成恢复预览，再确认恢复。'
    return
  }
  setBaiduBusy(true)
  const taskId = `baidu-restore-${crypto.randomUUID()}`
  activeBaiduTaskId = taskId
  try {
    const latest = await window.literatureApp.baiduLatestBackup()
    if (!latest.ok) throw new Error(`${latest.error || '确认时无法读取云端最新备份。'}${latest.code ? `（${latest.code}）` : ''}`)
    if (!latest.backup || latest.backup.snapshotId !== restorePreviewSnapshotId) {
      restorePreviewSnapshotId = null
      baiduRestorePreview.hidden = true
      throw new Error('云端最新备份已变化，请重新打开恢复预览后再确认。')
    }
    const flush = window.__literatureReaderFlushBeforeClose
    if (flush && !(await flush())) throw new Error('本机文献数据尚未保存成功，请先处理保存提示。')
    baiduStatus.textContent = '正在下载并校验云端备份…'
    const result = await window.literatureApp.baiduRestore(taskId)
    if (!result.ok) throw new Error(`${result.error || '恢复云端备份失败。'}${result.code ? `（${result.code}）` : ''}`)
    window.alert(`恢复完成：${result.papers || 0} 篇文献。恢复前的本机数据已保留在：\n${result.localBackupPath}`)
    window.location.reload()
  } catch (error) {
    baiduError.textContent = error instanceof Error ? error.message : String(error)
  } finally {
    activeBaiduTaskId = null
    setBaiduBusy(false)
  }
}
document.querySelector<HTMLButtonElement>('#baidu-disconnect')!.onclick = async () => {
  if (!window.confirm('断开后会从本机移除百度授权信息，云端备份不会删除。要继续吗？')) return
  await window.literatureApp.baiduDisconnect()
  baiduActions.hidden = true
  baiduConnectButton.hidden = false
  await refreshBaiduStatus()
}
}
window.literatureApp.onPrepareClose(async () => {
  const flush = window.__literatureReaderFlushBeforeClose
  return flush ? flush() : true
})
void window.literatureApp.getSettings().then((settings) => {
  updateModelStatus(settings.apiKey)
  if (settings.setupComplete) useSettingsToolbar()
  else showFirstRunGuide()
}).catch(() => {
  updateModelStatus('')
  showFirstRunGuide()
})
void loadPlugin()

window.addEventListener('beforeunload', () => unregisterTimer.forEach(window.clearInterval))
